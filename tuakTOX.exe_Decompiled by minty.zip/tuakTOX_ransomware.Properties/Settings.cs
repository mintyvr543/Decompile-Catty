using System.CodeDom.Compiler;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace tuakTOX_ransomware.Properties;

[CompilerGenerated]
[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "17.14.0.0")]
internal sealed class Settings : ApplicationSettingsBase
{
	private static Settings defaultInstance = (Settings)(object)SettingsBase.Synchronized((SettingsBase)(object)new Settings());

	public static Settings Default => defaultInstance;

	[UserScopedSetting]
	[DebuggerNonUserCode]
	[DefaultSettingValue("0")]
	public int SavedTime
	{
		get
		{
			return (int)((SettingsBase)this)["SavedTime"];
		}
		set
		{
			((SettingsBase)this)["SavedTime"] = value;
		}
	}

	[UserScopedSetting]
	[DebuggerNonUserCode]
	[DefaultSettingValue("0")]
	public int SavedSeconds
	{
		get
		{
			return (int)((SettingsBase)this)["SavedSeconds"];
		}
		set
		{
			((SettingsBase)this)["SavedSeconds"] = value;
		}
	}
}
