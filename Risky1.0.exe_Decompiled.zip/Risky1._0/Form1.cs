using System;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace Risky1._0;

public class Form1 : Form
{
	private IContainer components = null;

	private Button button1;

	private Button button2;

	private Label label1;

	private PictureBox pictureBox1;

	private PictureBox pictureBox2;

	private Label label2;

	private Label label3;

	private Label label4;

	private Label label5;

	private Label label6;

	public Form1()
	{
		InitializeComponent();
	}

	private void button2_Click(object sender, EventArgs e)
	{
		Environment.Exit(0);
	}

	private void button1_Click(object sender, EventArgs e)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Invalid comparison between Unknown and I4
		if ((int)MessageBox.Show("LAST WARNING!\nIf you click Yes, your system and data will be FUCKED and youll never recover it again\nonly run this in a VM.\nStill are you sure you want to execute this?\nIT WILL LAG YOUR PC UP!", "THIS IS YOUR FINAL WARNING!!!", (MessageBoxButtons)4, (MessageBoxIcon)48, (MessageBoxDefaultButton)256) == 6)
		{
			((Control)this).Hide();
			new Thread(Program.Threads).Start();
		}
		else
		{
			Environment.Exit(0);
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		((Form)this).Dispose(disposing);
	}

	private void InitializeComponent()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Expected O, but got Unknown
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Expected O, but got Unknown
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Expected O, but got Unknown
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Expected O, but got Unknown
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Expected O, but got Unknown
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Expected O, but got Unknown
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Expected O, but got Unknown
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Expected O, but got Unknown
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Expected O, but got Unknown
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Expected O, but got Unknown
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Expected O, but got Unknown
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_0190: Expected O, but got Unknown
		//IL_0249: Unknown result type (might be due to invalid IL or missing references)
		//IL_0253: Expected O, but got Unknown
		//IL_02dd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e7: Expected O, but got Unknown
		//IL_035e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0368: Expected O, but got Unknown
		//IL_03f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fb: Expected O, but got Unknown
		//IL_0492: Unknown result type (might be due to invalid IL or missing references)
		//IL_049c: Expected O, but got Unknown
		//IL_0591: Unknown result type (might be due to invalid IL or missing references)
		//IL_059b: Expected O, but got Unknown
		//IL_0637: Unknown result type (might be due to invalid IL or missing references)
		//IL_0641: Expected O, but got Unknown
		//IL_07c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d0: Expected O, but got Unknown
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(Form1));
		button1 = new Button();
		button2 = new Button();
		label1 = new Label();
		pictureBox1 = new PictureBox();
		pictureBox2 = new PictureBox();
		label2 = new Label();
		label3 = new Label();
		label4 = new Label();
		label5 = new Label();
		label6 = new Label();
		((ISupportInitialize)pictureBox1).BeginInit();
		((ISupportInitialize)pictureBox2).BeginInit();
		((Control)this).SuspendLayout();
		((Control)button1).BackColor = Color.Black;
		((Control)button1).Font = new Font("Microsoft Sans Serif", 16f, (FontStyle)0, (GraphicsUnit)3, (byte)0);
		((Control)button1).ForeColor = Color.Red;
		((Control)button1).Location = new Point(12, 567);
		((Control)button1).Name = "button1";
		((Control)button1).Size = new Size(410, 83);
		((Control)button1).TabIndex = 0;
		((Control)button1).Text = "EXECUTE";
		((ButtonBase)button1).UseVisualStyleBackColor = false;
		((Control)button1).Click += button1_Click;
		((Control)button2).BackColor = Color.Black;
		((Control)button2).Font = new Font("Microsoft Sans Serif", 16f, (FontStyle)0, (GraphicsUnit)3, (byte)0);
		((Control)button2).ForeColor = Color.Lime;
		((Control)button2).Location = new Point(475, 567);
		((Control)button2).Name = "button2";
		((Control)button2).Size = new Size(422, 83);
		((Control)button2).TabIndex = 1;
		((Control)button2).Text = "EXIT";
		((ButtonBase)button2).UseVisualStyleBackColor = false;
		((Control)button2).Click += button2_Click;
		((Control)label1).AutoSize = true;
		((Control)label1).Font = new Font("Microsoft Sans Serif", 12f, (FontStyle)1, (GraphicsUnit)3, (byte)0);
		((Control)label1).ForeColor = Color.Red;
		((Control)label1).Location = new Point(7, 129);
		((Control)label1).Name = "label1";
		((Control)label1).Size = new Size(867, 174);
		((Control)label1).TabIndex = 2;
		((Control)label1).Text = componentResourceManager.GetString("label1.Text");
		pictureBox1.Image = (Image)componentResourceManager.GetObject("pictureBox1.Image");
		((Control)pictureBox1).Location = new Point(12, 12);
		((Control)pictureBox1).Name = "pictureBox1";
		((Control)pictureBox1).Size = new Size(132, 114);
		pictureBox1.SizeMode = (PictureBoxSizeMode)1;
		pictureBox1.TabIndex = 3;
		pictureBox1.TabStop = false;
		pictureBox2.Image = (Image)componentResourceManager.GetObject("pictureBox2.Image");
		((Control)pictureBox2).Location = new Point(765, 12);
		((Control)pictureBox2).Name = "pictureBox2";
		((Control)pictureBox2).Size = new Size(132, 114);
		pictureBox2.SizeMode = (PictureBoxSizeMode)1;
		pictureBox2.TabIndex = 4;
		pictureBox2.TabStop = false;
		((Control)label2).AutoSize = true;
		((Control)label2).Font = new Font("Microsoft Sans Serif", 10f, (FontStyle)0, (GraphicsUnit)3, (byte)0);
		((Control)label2).ForeColor = Color.Yellow;
		((Control)label2).Location = new Point(12, 330);
		((Control)label2).Name = "label2";
		((Control)label2).Size = new Size(875, 100);
		((Control)label2).TabIndex = 5;
		((Control)label2).Text = componentResourceManager.GetString("label2.Text");
		((Control)label3).AutoSize = true;
		((Control)label3).Font = new Font("Microsoft Sans Serif", 9f, (FontStyle)0, (GraphicsUnit)3, (byte)0);
		((Control)label3).ForeColor = Color.Navy;
		((Control)label3).Location = new Point(13, 447);
		((Control)label3).Name = "label3";
		((Control)label3).Size = new Size(714, 88);
		((Control)label3).TabIndex = 6;
		((Control)label3).Text = "more information: Credits to: Cactos/1_Cactos and IDKDUDE1THING/IDKDUDE1THING\r\nmore destruction: cannot click anything\r\nversion: XP 64x 32x\r\nMBR parts: Old-school plasma rainbow cycling text\r\n";
		((Control)label4).AutoSize = true;
		((Control)label4).Location = new Point(0, 0);
		((Control)label4).Name = "label4";
		((Control)label4).Size = new Size(51, 20);
		((Control)label4).TabIndex = 7;
		((Control)label4).Text = "label4";
		((Control)label5).AutoSize = true;
		((Control)label5).Font = new Font("Microsoft Sans Serif", 16f, (FontStyle)0, (GraphicsUnit)3, (byte)0);
		((Control)label5).ForeColor = Color.FromArgb(255, 128, 0);
		((Control)label5).Location = new Point(293, 12);
		((Control)label5).Name = "label5";
		((Control)label5).Size = new Size(335, 37);
		((Control)label5).TabIndex = 8;
		((Control)label5).Text = "Hold up wait a minute!";
		((Control)label6).AutoSize = true;
		((Control)label6).Font = new Font("Microsoft Sans Serif", 16f, (FontStyle)0, (GraphicsUnit)3, (byte)0);
		((Control)label6).ForeColor = Color.FromArgb(255, 128, 0);
		((Control)label6).Location = new Point(167, 67);
		((Control)label6).Name = "label6";
		((Control)label6).Size = new Size(583, 37);
		((Control)label6).TabIndex = 9;
		((Control)label6).Text = "THIS IS A MALWARE LIKE SHITWARE\r\n";
		((ContainerControl)this).AutoScaleDimensions = new SizeF(9f, 20f);
		((ContainerControl)this).AutoScaleMode = (AutoScaleMode)1;
		((Control)this).BackColor = Color.Black;
		((Form)this).ClientSize = new Size(909, 662);
		((Form)this).ControlBox = false;
		((Control)this).Controls.Add((Control)(object)label6);
		((Control)this).Controls.Add((Control)(object)label5);
		((Control)this).Controls.Add((Control)(object)label4);
		((Control)this).Controls.Add((Control)(object)label3);
		((Control)this).Controls.Add((Control)(object)label2);
		((Control)this).Controls.Add((Control)(object)pictureBox2);
		((Control)this).Controls.Add((Control)(object)pictureBox1);
		((Control)this).Controls.Add((Control)(object)label1);
		((Control)this).Controls.Add((Control)(object)button2);
		((Control)this).Controls.Add((Control)(object)button1);
		((Form)this).Icon = (Icon)componentResourceManager.GetObject("$this.Icon");
		((Control)this).Name = "Form1";
		((Control)this).Text = "time files you snooze.";
		((ISupportInitialize)pictureBox1).EndInit();
		((ISupportInitialize)pictureBox2).EndInit();
		((Control)this).ResumeLayout(false);
		((Control)this).PerformLayout();
	}
}
