using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace Risky1._0;

internal class GDI
{
	public delegate bool EnumWindowsProc(IntPtr hwnd, IntPtr lParam);

	private struct POINT
	{
		public int x;

		public int y;
	}

	private struct RECT
	{
		public int left;

		public int top;

		public int right;

		public int bottom;
	}

	public struct BLENDFUNCTION
	{
		private byte BlendOp;

		private byte BlendFlags;

		private byte SourceConstantAlpha;

		private byte AlphaFormat;

		public BLENDFUNCTION(byte op, byte flags, byte alpha, byte format)
		{
			BlendOp = op;
			BlendFlags = flags;
			SourceConstantAlpha = alpha;
			AlphaFormat = format;
		}
	}

	public const uint SRCCOPY = 13369376u;

	public const uint SRCPAINT = 15597702u;

	public const uint SRCAND = 8913094u;

	public const uint SRCINVERT = 6684742u;

	public const uint SRCERASE = 4457256u;

	public const uint NOTSRCCOPY = 3342344u;

	public const uint NOTSRCERASE = 1114278u;

	public const uint MERGECOPY = 12583114u;

	public const uint MERGEPAINT = 12255782u;

	public const uint PATCOPY = 15728673u;

	public const uint PATPAINT = 16452105u;

	public const uint PATINVERT = 5898313u;

	public const uint DSTINVERT = 5570569u;

	public const uint BLACKNESS = 66u;

	public const uint WHITENESS = 16711778u;

	public const uint CAPTUREBLT = 1073741824u;

	public const uint CUSTOM = 1051781u;

	public static Random rand = new Random();

	[DllImport("user32.dll")]
	public static extern IntPtr GetDC(IntPtr hWnd);

	[DllImport("gdi32.dll")]
	public static extern IntPtr DeleteDC(IntPtr hdc);

	[DllImport("gdi32.dll")]
	public static extern IntPtr CreateSolidBrush(uint color);

	[DllImport("gdi32.dll")]
	public static extern IntPtr CreateCompatibleDC(IntPtr hdc);

	[DllImport("gdi32.dll")]
	public static extern IntPtr CreateCompatibleBitmap(IntPtr hdc, int cx, int cy);

	[DllImport("gdi32.dll", EntryPoint = "GdiAlphaBlend", SetLastError = true)]
	public static extern bool AlphaBlend(IntPtr hdcDest, int xoriginDest, int yoriginDest, int wDest, int hDest, IntPtr hdcSrc, int xoriginSrc, int yoriginSrc, int wSrc, int hSrc, BLENDFUNCTION ftn);

	[DllImport("gdi32.dll", SetLastError = true)]
	public static extern bool BitBlt(IntPtr hdc, int x, int y, int cx, int cy, IntPtr hdcSrc, int x1, int y1, uint rop);

	[DllImport("user32.dll")]
	public static extern int ReleaseDC(IntPtr hwnd, IntPtr hdc);

	[DllImport("gdi32.dll", SetLastError = true)]
	public static extern bool Rectangle(IntPtr hdc, int left, int top, int right, int bottom);

	[DllImport("gdi32.dll", SetLastError = true)]
	public static extern IntPtr SelectObject(IntPtr hdc, IntPtr hgdiobj);

	[DllImport("gdi32.dll", SetLastError = true)]
	public static extern IntPtr DeleteObject(IntPtr ho);

	[DllImport("gdi32.dll")]
	public static extern bool PatBlt(IntPtr hdc, int x, int y, int width, int height, uint rop);

	[DllImport("user32.dll")]
	public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

	[DllImport("gdi32.dll")]
	private static extern bool Ellipse(IntPtr hdc, int left, int top, int right, int bottom);

	[DllImport("user32.dll")]
	private static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

	[DllImport("user32.dll")]
	private static extern IntPtr GetDesktopWindow();

	[DllImport("gdi32.dll")]
	private static extern bool PlgBlt(IntPtr hdcDest, POINT[] lpPoint, IntPtr hdcSrc, int xSrc, int ySrc, int wSrc, int hSrc, IntPtr hbmMask, int xMask, int yMask);

	[DllImport("user32.dll")]
	public static extern bool InvalidateRect(IntPtr hWnd, IntPtr lpRect, bool bErase);

	public static uint GetRandomHEXColor()
	{
		byte b = (byte)rand.Next(255);
		byte b2 = (byte)rand.Next(255);
		byte b3 = (byte)rand.Next(255);
		return (uint)((b << 16) | (b2 << 8) | b3);
	}

	public static void colors()
	{
		while (true)
		{
			int width = Screen.PrimaryScreen.Bounds.Width;
			int height = Screen.PrimaryScreen.Bounds.Height;
			IntPtr dC = GetDC(IntPtr.Zero);
			IntPtr intPtr = CreateCompatibleDC(dC);
			IntPtr intPtr2 = CreateCompatibleBitmap(dC, width, height);
			IntPtr ho = SelectObject(intPtr, intPtr2);
			BitBlt(intPtr, 0, 0, width, height, dC, 0, 0, 13369376u);
			double num = (double)Environment.TickCount * 0.003;
			double num2 = 40.0;
			double num3 = 0.02;
			for (int i = 0; i < height; i++)
			{
				int x = (int)(Math.Sin((double)i * num3 + num) * num2);
				BitBlt(intPtr, x, i, width, 1, intPtr, 0, i, 13369376u);
			}
			AlphaBlend(dC, 0, 0, width, height, intPtr, 0, 0, width, height, new BLENDFUNCTION(0, 0, 128, 0));
			Thread.Sleep(rand.Next(1, 1100));
			ReleaseDC(IntPtr.Zero, dC);
			DeleteDC(intPtr);
			DeleteObject(intPtr2);
			DeleteObject(ho);
		}
	}

	public static void blackout()
	{
		bool flag = true;
		int width = Screen.PrimaryScreen.Bounds.Width;
		int height = Screen.PrimaryScreen.Bounds.Height;
		int num = rand.Next(width);
		int num2 = rand.Next(height);
		int num3 = rand.Next(3, 8);
		int num4 = rand.Next(3, 8);
		int num5 = 95;
		while (true)
		{
			IntPtr dC = GetDC(IntPtr.Zero);
			IntPtr intPtr = CreateSolidBrush((uint)Color.Black.ToArgb());
			IntPtr hgdiobj = SelectObject(dC, intPtr);
			Ellipse(dC, num - num5, num2 - num5, num + num5, num2 + num5);
			SelectObject(dC, hgdiobj);
			DeleteObject(intPtr);
			ReleaseDC(IntPtr.Zero, dC);
			num += num3;
			num2 += num4;
			if (num < num5 || num > width - num5)
			{
				num3 = -num3;
			}
			if (num2 < num5 || num2 > height - num5)
			{
				num4 = -num4;
			}
			Thread.Sleep(10);
		}
	}

	public static void colors2()
	{
		while (true)
		{
			int width = Screen.PrimaryScreen.Bounds.Width;
			int height = Screen.PrimaryScreen.Bounds.Height;
			int num = rand.Next(height);
			IntPtr dC = GetDC(IntPtr.Zero);
			IntPtr hgdiobj = CreateSolidBrush(GetRandomHEXColor());
			SelectObject(dC, hgdiobj);
			uint[] array = new uint[3] { 5898313u, 12583114u, 3342344u };
			BitBlt(dC, 0, num, width, rand.Next(height), dC, 0, num, array[rand.Next(array.Length)]);
			Thread.Sleep(rand.Next(5, 1200));
			ReleaseDC(IntPtr.Zero, dC);
		}
	}

	public static void glitches()
	{
		while (true)
		{
			int width = Screen.PrimaryScreen.Bounds.Width;
			int height = Screen.PrimaryScreen.Bounds.Height;
			int num = rand.Next(height);
			IntPtr dC = GetDC(IntPtr.Zero);
			BitBlt(dC, rand.Next(-20, 20), num, width, rand.Next(500, height), dC, 0, num, 13369376u);
			Thread.Sleep(rand.Next(30, 1000));
			ReleaseDC(IntPtr.Zero, dC);
		}
	}

	public static void glitch2()
	{
		while (true)
		{
			IntPtr dC = GetDC(IntPtr.Zero);
			int width = Screen.PrimaryScreen.Bounds.Width;
			int height = Screen.PrimaryScreen.Bounds.Height;
			int num = rand.Next(50, 150);
			int num2 = rand.Next(20, 50);
			int num3 = rand.Next(0, width - num);
			int num4 = rand.Next(0, height - num2);
			int x = num3 + rand.Next(-100, 100);
			int y = num4 + rand.Next(-20, 20);
			BitBlt(dC, x, y, num, num2, dC, num3, num4, 13369376u);
			Thread.Sleep(12);
			DeleteDC(dC);
		}
	}

	public static void tearing()
	{
		while (true)
		{
			IntPtr dC = GetDC(IntPtr.Zero);
			int width = Screen.PrimaryScreen.Bounds.Width;
			int height = Screen.PrimaryScreen.Bounds.Height;
			int num = rand.Next(height);
			int cy = rand.Next(1, 3);
			BitBlt(dC, 0, num, width, cy, dC, rand.Next(-30, 30), num, 13369376u);
			Thread.Sleep(10);
			DeleteDC(dC);
		}
	}

	public static void flip()
	{
		bool flag = true;
		IntPtr dC = GetDC(IntPtr.Zero);
		POINT[] array = new POINT[3];
		bool flag2 = true;
		int num = 20;
		while (true)
		{
			GetWindowRect(GetDesktopWindow(), out var lpRect);
			int wSrc = lpRect.right - lpRect.left;
			int hSrc = lpRect.bottom - lpRect.top;
			int tickCount = Environment.TickCount;
			flag2 = !flag2;
			while (Environment.TickCount - tickCount < 500)
			{
				for (int i = 0; i < 80; i += num)
				{
					GetWindowRect(GetDesktopWindow(), out lpRect);
					if (flag2)
					{
						array[0].x = lpRect.left + i;
						array[0].y = lpRect.top - i;
						array[1].x = lpRect.right + i;
						array[1].y = lpRect.top + i;
						array[2].x = lpRect.left - i;
						array[2].y = lpRect.bottom - i;
					}
					else
					{
						array[0].x = lpRect.left - i;
						array[0].y = lpRect.top + i;
						array[1].x = lpRect.right - i;
						array[1].y = lpRect.top - i;
						array[2].x = lpRect.left + i;
						array[2].y = lpRect.bottom + i;
					}
					PlgBlt(dC, array, dC, 0, 0, wSrc, hSrc, IntPtr.Zero, 0, 0);
					Thread.Sleep(40);
				}
			}
		}
	}

	public static void clear()
	{
		while (true)
		{
			Thread.Sleep(rand.Next(1, 5000));
			InvalidateRect(IntPtr.Zero, IntPtr.Zero, bErase: true);
		}
	}
}
