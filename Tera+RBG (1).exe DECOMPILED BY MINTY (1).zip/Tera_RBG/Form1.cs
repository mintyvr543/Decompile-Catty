using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Tera_RBG;

public class Form1 : Form
{
	private double ti;

	private IContainer components = null;

	private Timer timer1;

	private PictureBox pictureBox1;

	private PictureBox pictureBox2;

	public Form1()
	{
		InitializeComponent();
	}

	private void Form1_FormClosing(object sender, FormClosingEventArgs e)
	{
		((CancelEventArgs)(object)e).Cancel = true;
	}

	private void pictureBox1_Click(object sender, EventArgs e)
	{
	}

	private void timer1_Tick(object sender, EventArgs e)
	{
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Expected O, but got Unknown
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random();
		int width = ((Control)this).Width;
		int height = ((Control)this).Height;
		int[] array = new int[width * height];
		for (int i = 0; i < array.Length; i++)
		{
			ti += 1.0;
			int num = (int)ti;
			array[i] = (int)((double)((num & (num / 1) & (num / 2)) * num) / 1000.0 % 2.0);
		}
		Bitmap val = new Bitmap(width, height, (PixelFormat)139273);
		BitmapData val2 = val.LockBits(new Rectangle(0, 0, ((Image)val).Width, ((Image)val).Height), (ImageLockMode)2, ((Image)val).PixelFormat);
		Marshal.Copy(array, 0, val2.Scan0, array.Length);
		val.UnlockBits(val2);
		pictureBox1.Image = (Image)(object)val;
	}

	private void pictureBox2_Click(object sender, EventArgs e)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		MessageBox.Show("Enter Text Here", "لKnKr₨₣₵Q₣∄∊∌∐∑≯≲ⅻↅ◀▲◢⧩⨞＄П.سKnK.سr₨₣₵Q₣∄∊∌∐∑≯≲ⅻↅ◀▲◢⧩⨞＄Пل.سKnKr₨₣₵Q₣∄∊∌∐∑≯≲ⅻↅ◀▲◢⧩⨞＄ПnKr₨₣₵Q₣∄∊∌∐∑≯≲ⅻↅ◀▲◢⧩⨞＄П", (MessageBoxButtons)0, (MessageBoxIcon)16);
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		((Form)this).Dispose(disposing);
	}

	private void InitializeComponent()
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Expected O, but got Unknown
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Expected O, but got Unknown
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Expected O, but got Unknown
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Expected O, but got Unknown
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Expected O, but got Unknown
		//IL_023f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0249: Expected O, but got Unknown
		components = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(Form1));
		timer1 = new Timer(components);
		pictureBox1 = new PictureBox();
		pictureBox2 = new PictureBox();
		((ISupportInitialize)pictureBox1).BeginInit();
		((ISupportInitialize)pictureBox2).BeginInit();
		((Control)this).SuspendLayout();
		timer1.Tick += timer1_Tick;
		pictureBox1.Image = (Image)componentResourceManager.GetObject("pictureBox1.Image");
		((Control)pictureBox1).Location = new Point(-11, 170);
		((Control)pictureBox1).Name = "pictureBox1";
		((Control)pictureBox1).Size = new Size(10, 10);
		pictureBox1.SizeMode = (PictureBoxSizeMode)1;
		pictureBox1.TabIndex = 0;
		pictureBox1.TabStop = false;
		((Control)pictureBox1).Click += pictureBox1_Click;
		pictureBox2.Image = (Image)componentResourceManager.GetObject("pictureBox2.Image");
		((Control)pictureBox2).Location = new Point(-44, -6);
		((Control)pictureBox2).Name = "pictureBox2";
		((Control)pictureBox2).Size = new Size(683, 195);
		pictureBox2.SizeMode = (PictureBoxSizeMode)1;
		pictureBox2.TabIndex = 1;
		pictureBox2.TabStop = false;
		((Control)pictureBox2).Click += pictureBox2_Click;
		((ContainerControl)this).AutoScaleDimensions = new SizeF(9f, 20f);
		((ContainerControl)this).AutoScaleMode = (AutoScaleMode)1;
		((Form)this).ClientSize = new Size(543, 166);
		((Form)this).ControlBox = false;
		((Control)this).Controls.Add((Control)(object)pictureBox2);
		((Control)this).Controls.Add((Control)(object)pictureBox1);
		((Control)this).Name = "Form1";
		((Form)this).ShowIcon = false;
		((Form)this).ShowInTaskbar = false;
		((Control)this).Text = "e?";
		((Form)this).FormClosing += new FormClosingEventHandler(Form1_FormClosing);
		((ISupportInitialize)pictureBox1).EndInit();
		((ISupportInitialize)pictureBox2).EndInit();
		((Control)this).ResumeLayout(false);
	}
}
