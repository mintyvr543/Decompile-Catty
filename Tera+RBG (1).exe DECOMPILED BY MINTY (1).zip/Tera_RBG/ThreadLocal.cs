using System;

namespace Tera_RBG;

internal class ThreadLocal<T>
{
	public object Value { get; internal set; }

	public ThreadLocal(Func<Random> value)
	{
		Value = value;
	}
}
