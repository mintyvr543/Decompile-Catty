namespace Tera_RBG;

internal class BITMAPINFO
{
	internal int biPlanes;

	internal int biSize;

	internal int biWidth;

	internal int biHeight;

	internal int biBitCount;

	internal int biCompression;
}
