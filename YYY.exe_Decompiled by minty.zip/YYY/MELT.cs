namespace YYY;

internal class MELT
{
}
