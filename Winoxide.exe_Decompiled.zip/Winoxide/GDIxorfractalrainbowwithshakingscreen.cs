using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using Winoxide.Properties;

namespace Winoxide;

internal class GDIxorfractalrainbowwithshakingscreen
{
	public delegate bool EnumWindowsProc(IntPtr hwnd, IntPtr lParam);

	public struct POINT
	{
		public int X;

		public int Y;
	}

	private struct Vector3
	{
		public float X;

		public float Y;

		public float Z;

		public Vector3(float x, float y, float z)
		{
			X = x;
			Y = y;
			Z = z;
		}
	}

	public struct BLENDFUNCTION
	{
		private byte BlendOp;

		private byte BlendFlags;

		private byte SourceConstantAlpha;

		private byte AlphaFormat;

		public BLENDFUNCTION(byte op, byte flags, byte alpha, byte format)
		{
			BlendOp = op;
			BlendFlags = flags;
			SourceConstantAlpha = alpha;
			AlphaFormat = format;
		}
	}

	public const uint SRCCOPY = 13369376u;

	public const uint SRCPAINT = 15597702u;

	public const uint SRCAND = 8913094u;

	public const uint SRCINVERT = 6684742u;

	public const uint SRCERASE = 4457256u;

	public const uint NOTSRCERASE = 1114278u;

	public const uint MERGECOPY = 12583114u;

	public const uint MERGEPAINT = 12255782u;

	public const uint PATCOPY = 15728673u;

	public const uint PATPAINT = 16452105u;

	public const uint PATINVERT = 5898313u;

	public const uint DSTINVERT = 5570569u;

	public const uint BLACKNESS = 66u;

	public const uint WHITENESS = 16711778u;

	public const uint CAPTUREBLT = 1073741824u;

	public const uint CUSTOM = 1051781u;

	public static int x = Screen.PrimaryScreen.Bounds.Width;

	public static int y = Screen.PrimaryScreen.Bounds.Height;

	public static Random rand = new Random();

	private static int s;

	private const int NOTSRCCOPY = 3342344;

	[DllImport("user32.dll")]
	public static extern IntPtr GetDC(IntPtr hWnd);

	[DllImport("gdi32.dll")]
	public static extern IntPtr DeleteDC(IntPtr hdc);

	[DllImport("gdi32.dll")]
	public static extern IntPtr CreateSolidBrush(uint color);

	[DllImport("gdi32.dll")]
	public static extern IntPtr CreateCompatibleDC(IntPtr hdc);

	[DllImport("gdi32.dll")]
	public static extern IntPtr CreateCompatibleBitmap(IntPtr hdc, int cx, int cy);

	[DllImport("gdi32.dll", EntryPoint = "GdiAlphaBlend", SetLastError = true)]
	public static extern bool AlphaBlend(IntPtr hdcDest, int xoriginDest, int yoriginDest, int wDest, int hDest, IntPtr hdcSrc, int xoriginSrc, int yoriginSrc, int wSrc, int hSrc, BLENDFUNCTION ftn);

	[DllImport("gdi32.dll", SetLastError = true)]
	public static extern bool BitBlt(IntPtr hdc, int x, int y, int cx, int cy, IntPtr hdcSrc, int x1, int y1, uint rop);

	[DllImport("user32.dll")]
	public static extern int ReleaseDC(IntPtr hwnd, IntPtr hdc);

	private static int XorYeet32()
	{
		s ^= s << 13;
		s ^= s >> 17;
		s ^= s << 5;
		return s & 0x7FFFFFFF;
	}

	private static int min(int a, int b)
	{
		return (a < b) ? a : b;
	}

	private static int max(int a, int b)
	{
		return (a > b) ? a : b;
	}

	private static IntPtr makeDC()
	{
		return GetDC(IntPtr.Zero);
	}

	private static IntPtr Mdc(IntPtr hdc)
	{
		return CreateCompatibleDC(hdc);
	}

	private static IntPtr bitmap(IntPtr hdc)
	{
		return CreateCompatibleBitmap(hdc, 1920, 1080);
	}

	private static void CopyToDC(IntPtr dst, IntPtr src)
	{
		BitBlt(dst, 0, 0, 1920, 1080, src, 0, 0, 13369376u);
	}

	private static void PolyBlt(IntPtr hdc, int side, int rx, int ry, int off, int rop, int z, int exp)
	{
		int num = 64;
		int num2 = 64;
		POINT[] array = new POINT[3];
		array[0].X = rx + ((z * exp) & 0x1F);
		array[0].Y = ry + off;
		array[1].X = array[0].X + num;
		array[1].Y = array[0].Y;
		array[2].X = array[0].X;
		array[2].Y = array[0].Y + num2;
		PlgBlt(hdc, array, hdc, rx, ry, num, num2, IntPtr.Zero, 0, 0);
	}

	[DllImport("gdi32.dll", SetLastError = true)]
	public static extern bool Rectangle(IntPtr hdc, int left, int top, int right, int bottom);

	[DllImport("gdi32.dll", SetLastError = true)]
	public static extern IntPtr SelectObject(IntPtr hdc, IntPtr hgdiobj);

	[DllImport("gdi32.dll", SetLastError = true)]
	public static extern IntPtr DeleteObject(IntPtr ho);

	[DllImport("gdi32.dll")]
	public static extern bool PatBlt(IntPtr hdc, int x, int y, int width, int height, uint rop);

	[DllImport("user32.dll")]
	public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

	[DllImport("gdi32.dll")]
	private static extern bool PlgBlt(IntPtr hdcDest, POINT[] lpPoint, IntPtr hdcSrc, int xSrc, int ySrc, int wSrc, int hSrc, IntPtr hbmMask, int xMask, int yMask);

	[DllImport("gdi32.dll")]
	private static extern int SelectClipRgn(IntPtr hdc, IntPtr hrgn);

	[DllImport("gdi32.dll", SetLastError = true)]
	public static extern IntPtr CreatePolygonRgn([In] POINT[] lppt, int cPoints, int fnPolyFillMode);

	[DllImport("user32.dll")]
	public static extern bool InvalidateRect(IntPtr hWnd, IntPtr lpRect, bool bErase);

	private static void RemoveDC(IntPtr hdc)
	{
		DeleteDC(hdc);
	}

	public static uint GetRandomHEXColor()
	{
		byte b = (byte)rand.Next(255);
		byte b2 = (byte)rand.Next(255);
		byte b3 = (byte)rand.Next(255);
		return (uint)((b << 16) | (b2 << 8) | b3);
	}

	public static void colors()
	{
		while (true)
		{
			int width = Screen.PrimaryScreen.Bounds.Width;
			int height = Screen.PrimaryScreen.Bounds.Height;
			IntPtr dC = GetDC(IntPtr.Zero);
			IntPtr intPtr = CreateCompatibleDC(dC);
			IntPtr intPtr2 = CreateCompatibleBitmap(dC, width, height);
			IntPtr ho = SelectObject(intPtr, intPtr2);
			IntPtr intPtr3 = CreateSolidBrush(GetRandomHEXColor());
			SelectObject(intPtr, intPtr3);
			BitBlt(intPtr, 0, 0, width, height, dC, 0, 0, 13369376u);
			BitBlt(intPtr, 0, rand.Next(-500, height), width, rand.Next(500, height), intPtr, 0, 0, 15728673u);
			AlphaBlend(dC, 0, 0, width, height, intPtr, 0, 0, width, height, new BLENDFUNCTION(0, 0, (byte)rand.Next(1, 128), 0));
			Thread.Sleep(rand.Next(1, 1100));
			ReleaseDC(IntPtr.Zero, dC);
			DeleteDC(intPtr);
			DeleteObject(intPtr2);
			DeleteObject(ho);
			DeleteObject(intPtr3);
		}
	}

	public static void blackout()
	{
		//IL_0329: Unknown result type (might be due to invalid IL or missing references)
		//IL_0330: Expected O, but got Unknown
		while (true)
		{
			Thread.Sleep(rand.Next(1000, 8000));
			IntPtr dC = GetDC(IntPtr.Zero);
			int width = Screen.PrimaryScreen.Bounds.Width;
			int height = Screen.PrimaryScreen.Bounds.Height;
			Graphics val = Graphics.FromHdc(dC);
			try
			{
				val.SmoothingMode = (SmoothingMode)3;
				val.InterpolationMode = (InterpolationMode)5;
				Bitmap face = Resources.face;
				int width2 = ((Image)face).Width;
				int height2 = ((Image)face).Height;
				double num = (double)Environment.TickCount * 8E-05;
				int cx2 = (int)((double)(width / 2) + Math.Sin(num * 0.7) * ((double)width * 0.3));
				int cy2 = (int)((double)(height / 2) + Math.Cos(num * 0.5) * ((double)height * 0.3));
				double r = 140.0;
				double num2 = num * 1.2;
				double num3 = num * 0.9;
				double num4 = num * 0.6;
				double sx2 = Math.Sin(num2);
				double cx3 = Math.Cos(num2);
				double sy2 = Math.Sin(num3);
				double cy3 = Math.Cos(num3);
				double sz2 = Math.Sin(num4);
				double cz2 = Math.Cos(num4);
				int num5 = 60;
				int num6 = 60;
				for (int i = 0; i < num5; i++)
				{
					double num7 = (double)i / (double)num5;
					double num8 = (double)(i + 1) / (double)num5;
					double lat2 = Math.PI * (num7 - 0.5);
					double lat3 = Math.PI * (num8 - 0.5);
					for (int j = 0; j < num6; j++)
					{
						double num9 = (double)j / (double)num6;
						double num10 = (double)(j + 1) / (double)num6;
						double lon2 = Math.PI * 2.0 * num9;
						double lon3 = Math.PI * 2.0 * num10;
						Vector3 p2 = SpherePoint(r, lat2, lon2);
						Vector3 p3 = SpherePoint(r, lat2, lon3);
						Vector3 p4 = SpherePoint(r, lat3, lon2);
						Vector3 p5 = SpherePoint(r, lat3, lon3);
						p2 = Rotate3D(p2, sx2, cx3, sy2, cy3, sz2, cz2);
						p3 = Rotate3D(p3, sx2, cx3, sy2, cy3, sz2, cz2);
						p4 = Rotate3D(p4, sx2, cx3, sy2, cy3, sz2, cz2);
						p5 = Rotate3D(p5, sx2, cx3, sy2, cy3, sz2, cz2);
						if (!(Normal(p2, p3, p4).Z <= 0f))
						{
							PointF pointF = Project(p2, cx2, cy2);
							PointF pointF2 = Project(p3, cx2, cy2);
							PointF pointF3 = Project(p4, cx2, cy2);
							PointF pointF4 = Project(p5, cx2, cy2);
							int num11 = (int)(num9 * (double)width2);
							int num12 = (int)(num7 * (double)height2);
							if (num11 < 0)
							{
								num11 = 0;
							}
							if (num11 >= width2)
							{
								num11 = width2 - 1;
							}
							if (num12 < 0)
							{
								num12 = 0;
							}
							if (num12 >= height2)
							{
								num12 = height2 - 1;
							}
							Color pixel = face.GetPixel(num11, num12);
							SolidBrush val2 = new SolidBrush(pixel);
							try
							{
								val.FillPolygon((Brush)(object)val2, new PointF[4] { pointF, pointF2, pointF4, pointF3 });
							}
							finally
							{
								((IDisposable)val2)?.Dispose();
							}
						}
					}
				}
			}
			finally
			{
				((IDisposable)val)?.Dispose();
			}
			DeleteDC(dC);
		}
		static Vector3 Normal(Vector3 a, Vector3 b, Vector3 c)
		{
			float num15 = b.X - a.X;
			float num16 = b.Y - a.Y;
			float num17 = b.Z - a.Z;
			float num18 = c.X - a.X;
			float num19 = c.Y - a.Y;
			float num20 = c.Z - a.Z;
			return new Vector3(num16 * num20 - num17 * num19, num17 * num18 - num15 * num20, num15 * num19 - num16 * num18);
		}
		static PointF Project(Vector3 p, int cx, int cy)
		{
			double num13 = 400.0;
			double num14 = num13 / (num13 - (double)p.Z);
			return new PointF((float)((double)cx + (double)p.X * num14), (float)((double)cy + (double)p.Y * num14));
		}
		static Vector3 Rotate3D(Vector3 p, double sx, double cx, double sy, double cy, double sz, double cz)
		{
			float num21 = (float)((double)p.Y * cx - (double)p.Z * sx);
			float z = (float)((double)p.Y * sx + (double)p.Z * cx);
			p.Y = num21;
			p.Z = z;
			float num22 = (float)((double)p.X * cy + (double)p.Z * sy);
			z = (float)((double)(0f - p.X) * sy + (double)p.Z * cy);
			p.X = num22;
			p.Z = z;
			num22 = (float)((double)p.X * cz - (double)p.Y * sz);
			num21 = (float)((double)p.X * sz + (double)p.Y * cz);
			p.X = num22;
			p.Y = num21;
			return p;
		}
		static Vector3 SpherePoint(double R, double lat, double lon)
		{
			double num23 = R * Math.Cos(lat) * Math.Cos(lon);
			double num24 = R * Math.Sin(lat);
			double num25 = R * Math.Cos(lat) * Math.Sin(lon);
			return new Vector3((float)num23, (float)num24, (float)num25);
		}
	}

	public static void colors2()
	{
		while (true)
		{
			int width = Screen.PrimaryScreen.Bounds.Width;
			int height = Screen.PrimaryScreen.Bounds.Height;
			int y = rand.Next(height);
			IntPtr dC = GetDC(IntPtr.Zero);
			IntPtr hgdiobj = CreateSolidBrush(GetRandomHEXColor());
			SelectObject(dC, hgdiobj);
			uint[] array = new uint[3] { 5898313u, 12583114u, 3342344u };
			BitBlt(dC, 0, y, width, rand.Next(height), dC, 0, y, array[rand.Next(array.Length)]);
			Thread.Sleep(rand.Next(5, 1200));
			ReleaseDC(IntPtr.Zero, dC);
		}
	}

	public static void glitches()
	{
		while (true)
		{
			int width = Screen.PrimaryScreen.Bounds.Width;
			int height = Screen.PrimaryScreen.Bounds.Height;
			int y = rand.Next(height);
			IntPtr dC = GetDC(IntPtr.Zero);
			BitBlt(dC, rand.Next(-20, 20), y, width, rand.Next(500, height), dC, 0, y, 13369376u);
			Thread.Sleep(rand.Next(30, 1000));
			ReleaseDC(IntPtr.Zero, dC);
		}
	}

	public static void glitch2()
	{
		while (true)
		{
			IntPtr dC = GetDC(IntPtr.Zero);
			int width = Screen.PrimaryScreen.Bounds.Width;
			int height = Screen.PrimaryScreen.Bounds.Height;
			int num = rand.Next(50, 150);
			int num2 = rand.Next(20, 50);
			int num3 = rand.Next(0, width - num);
			int num4 = rand.Next(0, height - num2);
			int num5 = num3 + rand.Next(-100, 100);
			int num6 = num4 + rand.Next(-20, 20);
			BitBlt(dC, num5, num6, num, num2, dC, num3, num4, 13369376u);
			Thread.Sleep(12);
			DeleteDC(dC);
		}
	}

	public static void tearing()
	{
		bool flag = true;
		Bitmap face = Resources.face;
		IntPtr hbitmap = face.GetHbitmap();
		Random random = new Random();
		while (true)
		{
			IntPtr dC = GetDC(IntPtr.Zero);
			IntPtr intPtr = CreateCompatibleDC(dC);
			SelectObject(intPtr, hbitmap);
			int width = ((Image)face).Width;
			int height = ((Image)face).Height;
			int num = random.Next(Screen.PrimaryScreen.Bounds.Width - width);
			int num2 = random.Next(Screen.PrimaryScreen.Bounds.Height - height);
			BitBlt(dC, num, num2, width, height, intPtr, 0, 0, 13369376u);
			DeleteDC(intPtr);
			ReleaseDC(IntPtr.Zero, dC);
			Thread.Sleep(500);
		}
	}

	public static void flip()
	{
		IntPtr dC = GetDC(IntPtr.Zero);
		int width = Screen.PrimaryScreen.Bounds.Width;
		int height = Screen.PrimaryScreen.Bounds.Height;
		int num = rand.Next(80, 200);
		int num2 = rand.Next(num, width - num);
		int num3 = rand.Next(num, height - num);
		int num4 = rand.Next(3, 7);
		double num5 = rand.NextDouble() * Math.PI * 2.0;
		POINT[] array = new POINT[num4];
		for (int i = 0; i < num4; i++)
		{
			double num6 = num5 + (double)i * (Math.PI * 2.0 / (double)num4);
			int num7 = num2 + (int)(Math.Cos(num6) * (double)num);
			int num8 = num3 + (int)(Math.Sin(num6) * (double)num);
			array[i].X = num7;
			array[i].Y = num8;
		}
		IntPtr intPtr = CreatePolygonRgn(array, array.Length, 1);
		SelectClipRgn(dC, intPtr);
		PatBlt(dC, 0, 0, width, height, 5570569u);
		SelectClipRgn(dC, IntPtr.Zero);
		DeleteObject(intPtr);
		Thread.Sleep(232);
		ReleaseDC(IntPtr.Zero, dC);
	}

	public static void clear()
	{
		while (true)
		{
			Thread.Sleep(rand.Next(1, 5000));
			InvalidateRect(IntPtr.Zero, IntPtr.Zero, bErase: true);
		}
	}
}
