using System;
using System.Runtime.InteropServices;
using System.Threading;

namespace Winoxide;

internal class audio
{
	private struct WAVEFORMATEX
	{
		public ushort wFormatTag;

		public ushort nChannels;

		public uint nSamplesPerSec;

		public uint nAvgBytesPerSec;

		public ushort nBlockAlign;

		public ushort wBitsPerSample;

		public ushort cbSize;
	}

	private struct WAVEHDR
	{
		public IntPtr lpData;

		public uint dwBufferLength;

		public uint dwBytesRecorded;

		public IntPtr dwUser;

		public uint dwFlags;

		public uint dwLoops;

		public IntPtr lpNext;

		public IntPtr reserved;
	}

	[DllImport("winmm.dll")]
	private static extern int waveOutOpen(out IntPtr hWaveOut, uint uDeviceID, ref WAVEFORMATEX lpFormat, IntPtr dwCallback, IntPtr dwInstance, uint dwFlags);

	[DllImport("winmm.dll")]
	private static extern int waveOutPrepareHeader(IntPtr hWaveOut, ref WAVEHDR lpWaveOutHdr, uint uSize);

	[DllImport("winmm.dll")]
	private static extern int waveOutWrite(IntPtr hWaveOut, ref WAVEHDR lpWaveOutHdr, uint uSize);

	[DllImport("winmm.dll")]
	private static extern int waveOutUnprepareHeader(IntPtr hWaveOut, ref WAVEHDR lpWaveOutHdr, uint uSize);

	[DllImport("winmm.dll")]
	private static extern int waveOutClose(IntPtr hWaveOut);

	public static void Audio()
	{
		int num = 110250000;
		byte[] array = new byte[num];
		for (int i = 0; i < num; i++)
		{
			long num2 = i;
			long num3 = ((i >> 4) * (i >> 6)) ^ ((i * 3) ^ (i >> 9)) ^ ((i >> 13) & i);
			array[i] = (byte)(num3 & 0xFF);
		}
		WAVEFORMATEX lpFormat = default(WAVEFORMATEX);
		lpFormat.wFormatTag = 1;
		lpFormat.nChannels = 1;
		lpFormat.nSamplesPerSec = 11025u;
		lpFormat.wBitsPerSample = 8;
		lpFormat.nBlockAlign = 1;
		lpFormat.nAvgBytesPerSec = 11025u;
		lpFormat.cbSize = 0;
		waveOutOpen(out var hWaveOut, 0u, ref lpFormat, IntPtr.Zero, IntPtr.Zero, 0u);
		GCHandle gCHandle = GCHandle.Alloc(array, GCHandleType.Pinned);
		WAVEHDR lpWaveOutHdr = default(WAVEHDR);
		lpWaveOutHdr.lpData = gCHandle.AddrOfPinnedObject();
		lpWaveOutHdr.dwBufferLength = (uint)array.Length;
		waveOutPrepareHeader(hWaveOut, ref lpWaveOutHdr, (uint)Marshal.SizeOf(typeof(WAVEHDR)));
		waveOutWrite(hWaveOut, ref lpWaveOutHdr, (uint)Marshal.SizeOf(typeof(WAVEHDR)));
		while ((lpWaveOutHdr.dwFlags & 1) != 1)
		{
			Thread.Sleep(10);
		}
		waveOutUnprepareHeader(hWaveOut, ref lpWaveOutHdr, (uint)Marshal.SizeOf(typeof(WAVEHDR)));
		waveOutClose(hWaveOut);
		gCHandle.Free();
	}
}
